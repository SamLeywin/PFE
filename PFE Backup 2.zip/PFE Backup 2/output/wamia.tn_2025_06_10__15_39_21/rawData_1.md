La boutique ne fonctionnera pas correctement dans le cas où les cookies sont
désactivés.

**Javascript est désactivé dans votre navigateur.** Pour une meilleure
expérience sur notre site, assurez-vous d’activer JavaScript dans votre
navigateur.

Menu

Compte

  * [Mon compte](https://www.wamia.tn/customer/account/)
  * [Ma liste d’envies ](https://www.wamia.tn/wishlist/)
  * [Connexion](https://www.wamia.tn/customer/account/login/referer/aHR0cHM6Ly93d3cud2FtaWEudG4vY2F0YWxvZ3NlYXJjaC9yZXN1bHQvaW5kZXgvP3E9TGFtcGUrZGUrdGFibGUrTEVE/)
  * Comparer 
  * Wamia La marketplace référente de confiance 
  * [Créer un compte](https://www.wamia.tn/customer/account/create/)
  * [Trouver nos magasins](https://www.wamia.tn/mw-store-locator/)

  * [Accueil](https://www.wamia.tn/ "Aller à la page d’accueil")
  * **Résultats de recherche pour : 'Lampe de table LED'**

# Résultats de recherche pour : 'Lampe de table LED'

**Afficher en** **Grille** Liste

Produits 1-48 sur 11480

**Page**

  * **Vous lisez actuellement la page 1**
  * [Page 2](https://www.wamia.tn/catalogsearch/result/index/?p=2&q=Lampe+de+table+LED)
  * [Page 3](https://www.wamia.tn/catalogsearch/result/index/?p=3&q=Lampe+de+table+LED)
  * [Page 4](https://www.wamia.tn/catalogsearch/result/index/?p=4&q=Lampe+de+table+LED)
  * [Page 5](https://www.wamia.tn/catalogsearch/result/index/?p=5&q=Lampe+de+table+LED)
  * [Page Suivant](https://www.wamia.tn/catalogsearch/result/index/?p=2&q=Lampe+de+table+LED "Suivant")

Afficher

122448Tous

par page

Trier par Nom du produitPrixPertinence Par ordre croissant

Vouliez-vous dire

    [lampe de taupe led](https://www.wamia.tn/catalogsearch/result/?q=lampe+de+taupe+led)
    [lampe de tableau led](https://www.wamia.tn/catalogsearch/result/?q=lampe+de+tableau+led)
    [lampe de toile led](https://www.wamia.tn/catalogsearch/result/?q=lampe+de+toile+led)
    [lampe de tasse led](https://www.wamia.tn/catalogsearch/result/?q=lampe+de+tasse+led)
    [lampe de tab97 led](https://www.wamia.tn/catalogsearch/result/?q=lampe+de+tab97+led)

Termes de recherche associés

    [Lampe de bure](https://www.wamia.tn/catalogsearch/result/?q=Lampe+de+bure)
    [Lampe De Bureau Rechargeable LED Motif cartoon](https://www.wamia.tn/catalogsearch/result/?q=Lampe+De+Bureau+Rechargeable+LED+Motif+cartoon)
    [led de phar](https://www.wamia.tn/catalogsearch/result/?q=led+de+phar)
    [Lampe De Bureau Flexible Avec Pince Et Interrupteur - Prise - Noir](https://www.wamia.tn/catalogsearch/result/?q=Lampe+De+Bureau+Flexible+Avec+Pince+Et+Interrupteur+-+Prise+-+Noir)
    [Lampeardin à LED avec télécommande et détecteur de mouvement](https://www.wamia.tn/catalogsearch/result/?q=Lampeardin+%C3%A0+LED+avec+t%C3%A9l%C3%A9commande+et+d%C3%A9tecteur+de+mouvement)

  1. [![Lampe de Table LED sans Fil Rechargeable Avec Tactile](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/711WSJg84XL._AC_SL1500__1.jpg)![Lampe de Table LED sans Fil Rechargeable Avec Tactile](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/711WSJg84XL._AC_SL1500__1.jpg)](https://www.wamia.tn/lampe-de-table-led-sans-fil-rechargeable-avec-tactile.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table LED sans Fil Rechargeable Avec
Tactile](https://www.wamia.tn/lampe-de-table-led-sans-fil-rechargeable-avec-
tactile.html)**

À partir de 49,900 DT

38% off

  2. [![Lampe Led de Table Aladin Old Style Marron](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/1/_/1_1__108_1.jpg)![Lampe Led de Table Aladin Old Style Marron](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/1/_/1_1__108_1.jpg)](https://www.wamia.tn/lampe-led-de-table-aladin-old-style-marron.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe Led de Table Aladin Old Style Marron](https://www.wamia.tn/lampe-led-
de-table-aladin-old-style-marron.html)**

Prix Spécial 58,000 DT Prix normal 99,000 DT

41% off

  3. [![Lampe De Table Led Sans Fil - Rechargeable - 3 Modes D'éclairage Avec Interrupteur Tactile - Portable ](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/i/m/img-20250104-wa0010_1_1.jpg)![Lampe De Table Led Sans Fil - Rechargeable - 3 Modes D'éclairage Avec Interrupteur Tactile - Portable ](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/i/m/img-20250104-wa0010_1_1.jpg)](https://www.wamia.tn/lampe-de-table-led-sans-fil-rechargeable-3-modes-d-eclairage-avec-interrupteur-tactile-portable.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Led Sans Fil - Rechargeable - 3 Modes D'éclairage Avec
Interrupteur Tactile - Portable](https://www.wamia.tn/lampe-de-table-led-sans-
fil-rechargeable-3-modes-d-eclairage-avec-interrupteur-tactile-
portable.html)**

Prix Spécial 38,000 DT Prix normal 55,000 DT

31% off

  4. [![Lampe de Table LED en Acrylique RGB Tactile & Télécommande](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/71WSQ1-xZBL._AC_SL1500__1.jpg)![Lampe de Table LED en Acrylique RGB Tactile & Télécommande](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/71WSQ1-xZBL._AC_SL1500__1.jpg)](https://www.wamia.tn/lampe-de-table-led-en-acrylique-sans-fil-rechargeable-rgb-tactile-telecommande.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table LED en Acrylique RGB Tactile&
Télécommande](https://www.wamia.tn/lampe-de-table-led-en-acrylique-sans-fil-
rechargeable-rgb-tactile-telecommande.html)**

Prix Spécial 23,900 DT Prix normal 35,000 DT

32% off

  5. [![Lampe De Table Portables Sans Fil Rechargeable Avec Tactile Motif 2 ](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/7/f/7f929863-b71f-4820-b3bb-01c46c2a04e6.jpeg)![Lampe De Table Portables Sans Fil Rechargeable Avec Tactile Motif 2 ](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/7/f/7f929863-b71f-4820-b3bb-01c46c2a04e6.jpeg)](https://www.wamia.tn/catalog/product/view/id/59119/s/lampe-de-table-portables-sans-fil-rechargeable-avec-tactile/category/2/)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Portables Sans Fil Rechargeable Avec Tactile Motif
2](https://www.wamia.tn/catalog/product/view/id/59119/s/lampe-de-table-
portables-sans-fil-rechargeable-avec-tactile/category/2/)**

À partir de 34,900 DT

56% off

  6. [![Lampe De Table Portables Sans Fil Rechargeable Avec Tactile Modèle 2](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/4/c/4ce52ed6-cfeb-49de-9cf4-9e4dc8806992_1.jpeg)![Lampe De Table Portables Sans Fil Rechargeable Avec Tactile Modèle 2](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/4/c/4ce52ed6-cfeb-49de-9cf4-9e4dc8806992_1.jpeg)](https://www.wamia.tn/lampe-de-table-portables-sans-fil-rechargeable-avec-tactile-modele-2.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Portables Sans Fil Rechargeable Avec Tactile Modèle
2](https://www.wamia.tn/lampe-de-table-portables-sans-fil-rechargeable-avec-
tactile-modele-2.html)**

À partir de 34,900 DT

56% off

  7. [![Lampe de Table à LED d'Astronaute](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/1000001594_1.jpg)![Lampe de Table à LED d'Astronaute](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/1000001594_1.jpg)](https://www.wamia.tn/lampe-de-table-a-led-d-astronaute.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table à LED d'Astronaute](https://www.wamia.tn/lampe-de-table-a-
led-d-astronaute.html)**

À partir de 22,000 DT

27% off

  8. [![Lampe de Table LED en Acrylique RGB Tactile & Télécommande](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/lampe_acrylique_-1_1.jpg)![Lampe de Table LED en Acrylique RGB Tactile & Télécommande](https://www.wamia.tn/media/catalog/product/cache/67b77c508effac656e7120c2771028d2/lampe_acrylique_-1_1.jpg)](https://www.wamia.tn/lampe-de-table-led-acrylique-sans-fil-rechargeable-rgb-tactile-telecommande.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table LED en Acrylique RGB Tactile&
Télécommande](https://www.wamia.tn/lampe-de-table-led-acrylique-sans-fil-
rechargeable-rgb-tactile-telecommande.html)**

Prix Spécial 23,900 DT Prix normal 35,000 DT

32% off

  9. [![Lampe de table portables sans fil rechargeable avec tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de table portables sans fil rechargeable avec tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/catalog/product/view/id/51745/s/lampe-de-table-portables-sans-fil-rechargeable-avec-tactile/category/2/)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de table portables sans fil rechargeable avec
tactile](https://www.wamia.tn/catalog/product/view/id/51745/s/lampe-de-table-
portables-sans-fil-rechargeable-avec-tactile/category/2/)**

À partir de 34,900 DT

56% off

  10. [![Lampe De Table Portable Sans Fil Rechargeable Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table Portable Sans Fil Rechargeable Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/catalog/product/view/id/66240/s/lampe-de-table-portables-sans-fil-rechargeable-avec-tactile/category/2/)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Portable Sans Fil Rechargeable Avec
Tactile](https://www.wamia.tn/catalog/product/view/id/66240/s/lampe-de-table-
portables-sans-fil-rechargeable-avec-tactile/category/2/)**

À partir de 34,900 DT

56% off

  11. [![Lampe de bureau de lecture LED Ajustable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de bureau de lecture LED Ajustable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-bureau-de-lecture-led-ajustable.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de bureau de lecture LED Ajustable](https://www.wamia.tn/lampe-de-
bureau-de-lecture-led-ajustable.html)**

À partir de 21,900 DT

27% off

  12. [![Lampe De Table En Cristal Romantique](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table En Cristal Romantique](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-en-cristal-romantique.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table En Cristal Romantique](https://www.wamia.tn/lampe-de-table-
en-cristal-romantique.html)**

Prix Spécial 29,900 DT Prix normal 45,000 DT

34% off

  13. [![Lampe De Table Portables Sans Fil Rechargeable Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table Portables Sans Fil Rechargeable Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-portable-sans-fil-rechargeable-avec-tactile.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Portables Sans Fil Rechargeable Avec
Tactile](https://www.wamia.tn/lampe-de-table-portable-sans-fil-rechargeable-
avec-tactile.html)**

À partir de 24,900 DT

69% off

  14. [![Lampe de table en acrylique 21.5 x 8 cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de table en acrylique 21.5 x 8 cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-en-acrylique-21-5-x-8-cm.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de table en acrylique 21.5 x 8 cm](https://www.wamia.tn/lampe-de-
table-en-acrylique-21-5-x-8-cm.html)**

Prix Spécial 19,900 DT Prix normal 60,000 DT

67% off

  15. [![Lampe de Table Portable en Bronze Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Table Portable en Bronze Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-portable-en-bronze-avec-tactile.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table Portable en Bronze Avec Tactile](https://www.wamia.tn/lampe-
de-table-portable-en-bronze-avec-tactile.html)**

Prix Spécial 25,900 DT Prix normal 40,000 DT

35% off

  16. [![Lampe de Table Sans Fil Rechargeable Tactile Bronze 21X9cm ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Table Sans Fil Rechargeable Tactile Bronze 21X9cm ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-sans-fil-rechargeable-et-tactile-avec-finition-bronze.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table Sans Fil Rechargeable Tactile Bronze
21X9cm](https://www.wamia.tn/lampe-de-table-sans-fil-rechargeable-et-tactile-
avec-finition-bronze.html)**

Prix Spécial 25,900 DT Prix normal 40,000 DT

35% off

  17. [![Lampe Luminaire Décorative de Table en Cristal ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe Luminaire Décorative de Table en Cristal ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-luminaire-decoratif-de-table-en-cristal-ideal-pour-chambre-a-coucher.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe Luminaire Décorative de Table en Cristal](https://www.wamia.tn/lampe-
luminaire-decoratif-de-table-en-cristal-ideal-pour-chambre-a-coucher.html)**

Prix Spécial 24,900 DT Prix normal 45,000 DT

45% off

  18. [![Lampe de Table Sans Fil Rechargeable et Tactile En Gris 21x9 cm ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Table Sans Fil Rechargeable et Tactile En Gris 21x9 cm ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-sans-fil-rechargeable-et-tactile-avec-finition-en-gris.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table Sans Fil Rechargeable et Tactile En Gris 21x9
cm](https://www.wamia.tn/lampe-de-table-sans-fil-rechargeable-et-tactile-avec-
finition-en-gris.html)**

Prix Spécial 25,900 DT Prix normal 40,000 DT

35% off

  19. [![Lampe De Table Portables Sans Fil Rechargeable Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table Portables Sans Fil Rechargeable Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-portables-sans-fil-rechargeable-avec-tactile.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Portables Sans Fil Rechargeable Avec
Tactile](https://www.wamia.tn/lampe-de-table-portables-sans-fil-rechargeable-
avec-tactile.html)**

À partir de 39,900 DT

50% off

  20. [![Lampe De Table En Acrylique RGB avec câble USB 26 x 8.5 cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table En Acrylique RGB avec câble USB 26 x 8.5 cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-en-acrylique-avec-cable-usb-26-x-8-5-cm-bpm0132.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table En Acrylique RGB avec câble USB 26 x 8.5
cm](https://www.wamia.tn/lampe-de-table-en-acrylique-avec-cable-
usb-26-x-8-5-cm-bpm0132.html)**

Évaluation:

80%

[1 Avis](https://www.wamia.tn/lampe-de-table-en-acrylique-avec-cable-
usb-26-x-8-5-cm-bpm0132.html#reviews)

Prix Spécial 24,900 DT Prix normal 40,000 DT

38% off

  21. [![Luminaire LED à piles forme Étoile 7.5 x 6 x 3.8 cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Luminaire LED à piles forme Étoile 7.5 x 6 x 3.8 cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-decorative-led-luminaire-led-a-piles-etoile-lampe-de-table-forme-etoile.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Luminaire LED à piles forme Étoile 7.5 x 6 x 3.8
cm](https://www.wamia.tn/lampe-decorative-led-luminaire-led-a-piles-etoile-
lampe-de-table-forme-etoile.html)**

À partir de 7,000 DT

  22. [![Lampe de Table Moderne Noir](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Table Moderne Noir](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-moderne-elegance-noir.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table Moderne Noir](https://www.wamia.tn/lampe-de-table-moderne-
elegance-noir.html)**

91,000 DT

  23. [![Lampe De Table Portable Sans Fil Rechargeable Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table Portable Sans Fil Rechargeable Avec Tactile](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-portables-sans-fil-rechargeable-tactile.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Portable Sans Fil Rechargeable Avec
Tactile](https://www.wamia.tn/lampe-de-table-portables-sans-fil-rechargeable-
tactile.html)**

À partir de 59,900 DT

33% off

  24. [![Lampe de Table Moderne Blanc](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Table Moderne Blanc](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-moderne-elegance-blanc.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table Moderne Blanc](https://www.wamia.tn/lampe-de-table-moderne-
elegance-blanc.html)**

91,000 DT

  25. [![Lampe De Table Portable Sans Fil Rechargeable Avec Tactile Doré](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table Portable Sans Fil Rechargeable Avec Tactile Doré](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-portable-en-dore-avec-tactile-21-x-9-x-13-cm.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Portable Sans Fil Rechargeable Avec Tactile
Doré](https://www.wamia.tn/lampe-de-table-portable-en-dore-avec-
tactile-21-x-9-x-13-cm.html)**

Prix Spécial 25,900 DT Prix normal 40,000 DT

35% off

  26. [![Lampe De Table En Cristal Romantique](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table En Cristal Romantique](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/catalog/product/view/id/68043/s/lampe-de-table-en-cristal-romantique/category/2/)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table En Cristal
Romantique](https://www.wamia.tn/catalog/product/view/id/68043/s/lampe-de-
table-en-cristal-romantique/category/2/)**

Prix Spécial 19,500 DT Prix normal 30,000 DT

35% off

  27. [![Lampe De Table Arbre Artificiel Avec Branches Réglables - Led - USB & Piles -Décoration](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Table Arbre Artificiel Avec Branches Réglables - Led - USB & Piles -Décoration](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/arbre-artificiel-avec-branches-reglables-led-usb-piles-decoration.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Table Arbre Artificiel Avec Branches Réglables - Led - USB& Piles
-Décoration](https://www.wamia.tn/arbre-artificiel-avec-branches-reglables-
led-usb-piles-decoration.html)**

Prix Spécial 42,000 DT Prix normal 74,000 DT

43% off

  28. [![Lampe forme  Arbre Lumineux Led](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe forme  Arbre Lumineux Led](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-forme-arbre-lumineux-led.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe forme Arbre Lumineux Led](https://www.wamia.tn/lampe-forme-arbre-
lumineux-led.html)**

Prix Spécial 59,000 DT Prix normal 70,000 DT

16% off

  29. [![Lampe De Bureau Rechargeable LED Motif Cartoon](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Bureau Rechargeable LED Motif Cartoon](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-bureau-rechargeable-led-motif-cartoon.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Bureau Rechargeable LED Motif Cartoon](https://www.wamia.tn/lampe-
de-bureau-rechargeable-led-motif-cartoon.html)**

À partir de 19,900 DT

43% off

  30. [![Lampe De Bureau De Table Avec Interrupteur Blanc](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Bureau De Table Avec Interrupteur Blanc](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-bureau-de-table-avec-interrupteur-blanc.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Bureau De Table Avec Interrupteur
Blanc](https://www.wamia.tn/lampe-de-bureau-de-table-avec-interrupteur-
blanc.html)**

Prix Spécial 38,000 DT Prix normal 55,000 DT

31% off

  31. [![Lampe de Bureau à LED Flexible Gris ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Bureau à LED Flexible Gris ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-bureau-a-led-flexible-gris.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Bureau à LED Flexible Gris](https://www.wamia.tn/lampe-de-bureau-
a-led-flexible-gris.html)**

Prix Spécial 42,000 DT Prix normal 61,000 DT

31% off

  32. [![Lampe de Table Fusée Astronaute](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Table Fusée Astronaute](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-table-fusee-astronaute.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Table Fusée Astronaute](https://www.wamia.tn/lampe-de-table-fusee-
astronaute.html)**

À partir de 22,000 DT

27% off

  33. [![Lampe de Bureau à LED Flexible Bleu](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Bureau à LED Flexible Bleu](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-bureau-a-led-flexible-avec-prise-multifonction-de-chargement-usb-portable-et-reglable-bleu.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Bureau à LED Flexible Bleu](https://www.wamia.tn/lampe-de-bureau-
a-led-flexible-avec-prise-multifonction-de-chargement-usb-portable-et-
reglable-bleu.html)**

Prix Spécial 43,000 DT Prix normal 61,000 DT

30% off

  34. [![Lampe De Bureau Rechargeable LED Motif cartoon](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Bureau Rechargeable LED Motif cartoon](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-bureau-rechargeable-led-motif-cartoon-1.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Bureau Rechargeable LED Motif cartoon](https://www.wamia.tn/lampe-
de-bureau-rechargeable-led-motif-cartoon-1.html)**

À partir de 19,900 DT

34% off

  35. [![Lampe De Bureau Rechargeable LED Forme D'astronaute](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Bureau Rechargeable LED Forme D'astronaute](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-bureau-rechargeable-led-forme-d-astronaute.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Bureau Rechargeable LED Forme
D'astronaute](https://www.wamia.tn/lampe-de-bureau-rechargeable-led-forme-d-
astronaute.html)**

À partir de 14,900 DT

50% off

  36. [![Lampe Flexible 28 Led ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe Flexible 28 Led ](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-flexible-28-led-noir.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe Flexible 28 Led](https://www.wamia.tn/lampe-flexible-28-led-
noir.html)**

À partir de 9,500 DT

  37. [![Lampe de Bureau Blanc Motif 1](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Bureau Blanc Motif 1](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-bureau-blanc-motif-1.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Bureau Blanc Motif 1](https://www.wamia.tn/lampe-de-bureau-blanc-
motif-1.html)**

38,000 DT

  38. [![Lampe De Poche LED Rechargeable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Poche LED Rechargeable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampes-de-poche-led-rechargeables-etanches-ultra-lumineuses-torche-d-urgence-pour-le-camping.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Poche LED Rechargeable](https://www.wamia.tn/lampes-de-poche-led-
rechargeables-etanches-ultra-lumineuses-torche-d-urgence-pour-le-
camping.html)**

Prix Spécial 26,000 DT Prix normal 55,000 DT

53% off

  39. [![Lampe LED UV de PocheTorche pour Camping](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe LED UV de PocheTorche pour Camping](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-led-uv-de-poche-blacklight-lampe-torche-pour-camping.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe LED UV de PocheTorche pour Camping](https://www.wamia.tn/lampe-led-
uv-de-poche-blacklight-lampe-torche-pour-camping.html)**

Prix Spécial 29,900 DT Prix normal 35,000 DT

15% off

  40. [![2 Lampes décoratives LED  forme lune et étoile 7.5 x 6 x 3.8 cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![2 Lampes décoratives LED  forme lune et étoile 7.5 x 6 x 3.8 cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/2-lampes-decorative-led-luminaire-led-a-piles-etoile-lune-2-lampes-de-table.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[2 Lampes décoratives LED forme lune et étoile 7.5 x 6 x 3.8
cm](https://www.wamia.tn/2-lampes-decorative-led-luminaire-led-a-piles-etoile-
lune-2-lampes-de-table.html)**

À partir de 14,000 DT

  41. [![Lampe de Poche LED avec Zoom 2en1 Rechargeable Câble Type-C](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Poche LED avec Zoom 2en1 Rechargeable Câble Type-C](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-poche-led-avec-zoom-2en1-rechargeable-cable-type-c.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Poche LED avec Zoom 2en1 Rechargeable Câble
Type-C](https://www.wamia.tn/lampe-de-poche-led-avec-zoom-2en1-rechargeable-
cable-type-c.html)**

Prix Spécial 24,000 DT Prix normal 39,000 DT

38% off

  42. [![ Lampe Led Lumière PC Flexible](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![ Lampe Led Lumière PC Flexible](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-led-lumiere-pc-flexible.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe Led Lumière PC Flexible](https://www.wamia.tn/lampe-led-lumiere-pc-
flexible.html)**

À partir de 6,000 DT

33% off

  43. [![2 lampes LED avec détecteur de mouvement IR et télécommande](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![2 lampes LED avec détecteur de mouvement IR et télécommande](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/2-lampes-led-avec-detecteur-de-mouvement-ir-et-telecommande.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[2 lampes LED avec détecteur de mouvement IR et
télécommande](https://www.wamia.tn/2-lampes-led-avec-detecteur-de-mouvement-
ir-et-telecommande.html)**

Prix Spécial 24,500 DT Prix normal 35,000 DT

30% off

  44. [![Lampe de Poche à lumière LED Rechargeable par USB Zoomable 4Modes](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe de Poche à lumière LED Rechargeable par USB Zoomable 4Modes](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-poche-rechargeable-a-led.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe de Poche à lumière LED Rechargeable par USB Zoomable
4Modes](https://www.wamia.tn/lampe-de-poche-rechargeable-a-led.html)**

Prix Spécial 29,000 DT Prix normal 45,000 DT

36% off

  45. [![ Lampe Baladeuse LED PRO Rechargeable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![ Lampe Baladeuse LED PRO Rechargeable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/generic-lampe-baladeuse-led-pro-rechargeable-garage-camping-lumieres-de-secours.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe Baladeuse LED PRO Rechargeable](https://www.wamia.tn/generic-lampe-
baladeuse-led-pro-rechargeable-garage-camping-lumieres-de-secours.html)**

À partir de 25,000 DT

29% off

  46. [![Lampe LED 4 ailes déformable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe LED 4 ailes déformable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-led-4-ailes-deformable-45w.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe LED 4 ailes déformable 45W](https://www.wamia.tn/lampe-led-4-ailes-
deformable-45w.html)**

Prix Spécial 29,500 DT Prix normal 40,000 DT

26% off

  47. [![Lampe Led & Haut Parleur & Chargeur Sans Fil 3 en 1 USB](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe Led & Haut Parleur & Chargeur Sans Fil 3 en 1 USB](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/chargeur-sans-fil-3-en-1-usb.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe Led& Haut Parleur & Chargeur Sans Fil 3 en 1
USB](https://www.wamia.tn/chargeur-sans-fil-3-en-1-usb.html)**

Prix Spécial 99,000 DT Prix normal 149,000 DT

34% off

  48. [![Lampe De Poche Portable Led Réglable Etanche Rechargeable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Lampe De Poche Portable Led Réglable Etanche Rechargeable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/lampe-de-poche-portable-haute-puissance-zoom-focus-mini-xp-g-q5-led-reglable-etanche-rechargeable.html)

Ajouter à ma liste d’envie Ajouter au comparateur [Aperçu
Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter au panier

**[Lampe De Poche Portable Led Réglable Etanche
Rechargeable](https://www.wamia.tn/lampe-de-poche-portable-haute-puissance-
zoom-focus-mini-xp-g-q5-led-reglable-etanche-rechargeable.html)**

Prix Spécial 24,000 DT Prix normal 35,000 DT

31% off

**Afficher en** **Grille** Liste

Produits 1-48 sur 11480

**Page**

  * **Vous lisez actuellement la page 1**
  * [Page 2](https://www.wamia.tn/catalogsearch/result/index/?p=2&q=Lampe+de+table+LED)
  * [Page 3](https://www.wamia.tn/catalogsearch/result/index/?p=3&q=Lampe+de+table+LED)
  * [Page 4](https://www.wamia.tn/catalogsearch/result/index/?p=4&q=Lampe+de+table+LED)
  * [Page 5](https://www.wamia.tn/catalogsearch/result/index/?p=5&q=Lampe+de+table+LED)
  * [Page Suivant](https://www.wamia.tn/catalogsearch/result/index/?p=2&q=Lampe+de+table+LED "Suivant")

Afficher

122448Tous

par page

Trier par Nom du produitPrixPertinence Par ordre croissant

**Filtrer par**

**Affiner les options**

Catégorie

  * Électroménager 509
  * Robot cuisine 153
  * Appareils de cuisson 94
  * Café & petit déjeuner 73
  * Gros Electroménager 83
  * Aspirateurs & nettoyeurs & entretien 29
  * Chauffage et Climatisation 65
  * Électroménager spécialisé 15
  * Cuisine 1343
  * Ustensiles de cuisine 141
  * Vaisselle 382
  * Casseroles et poêles 146
  * Ustensiles de pâtisserie 72
  * Couteaux et outils 178
  * Rangement cuisine 284
  * Produits de nettoyage et outils 102
  * Outils de mesure 45
  * Meuble et décoration 1939
  * Décoration maison 1415
  * Bougies et parfums d'ambiance 193
  * Rangement et organisation 53
  * Linge de maison 162
  * Accessoires de salle de bain 53
  * Meubles de chambre et salon 21
  * Article de décoration 23
  * Fournitures de loisirs créatifs et Couture 9
  * Mode 1157
  * Bagagerie 83
  * Vêtements Femme 146
  * Chaussures Femme 19
  * Tenue de sport Femme 21
  * Accessoires Femme 135
  * Vêtements Hommes 259
  * Chaussures Homme 49
  * Tenue de sport Homme 14
  * Accessoires Homme 71
  * Vêtements Fillettes 175
  * Chaussures Filles 9
  * Vêtements garçons 103
  * Bijoux 95
  * Beauté et Bien-être 1442
  * Parfums 135
  * Maquillage 240
  * Savons et hygiène corporelle 226
  * Rasage et Épilation 125
  * Soins capillaires 380
  * Soins pour la peau 270
  * Onglerie 119
  * Hygiène et Santé 501
  * Savons et hygiène corporelle 113
  * Massage et relaxation 168
  * Soins capillaires 67
  * Hygiène dentaire 33
  * Matériel et fournitures médicales 41
  * Rasage et épilation 56
  * Santé et premiers soins 13
  * Soin du bébé 11
  * Bricolage 680
  * Quincaillerie 170
  * Outillage à main 119
  * Outillage électroportatif 47
  * Électricité 70
  * Plomberie 69
  * Système de Sécurité 68
  * Équipement et matériel de sécurité 13
  * Peintures, outils et traitement des murs 31
  * Accessoires pour outillage électroportatif 8
  * Construction 15
  * Cuisines et salles de bain 9
  * Outillage de jardin 21
  * Tondeuses et outillage de jardin motorisé 45
  * Jeux et Jouets 230
  * Véhicules et Rails 15
  * Peluches et Puzzles 19
  * Loisirs créatifs 26
  * Jeux de plein air 9
  * Jeux d'eau et de plage 54
  * Jeux de société 44
  * Jeux éducatifs et scientifiques 22
  * Jouets d'éveil et 1er âge 8
  * Jeux d'imitation et déguisements 10
  * Systèmes de jeux vidéo portables 11
  * Sport et loisir 190
  * Activités de plein air 63
  * Matériel camping 32
  * Équipement et accessoires de sport 19
  * Fitness et musculation 34
  * Médecine du sport 35
  * Fournitures de bureau 106
  * Fournitures d'école 57
  * Écriture 11
  * Petites fournitures 31
  * High-Tech 2646
  * Téléphones portables et accessoires 1983
  * TV, vidéo et home cinéma 53
  * Alimentation et accessoires 435
  * Audio et vidéo portable 126
  * Photo et caméscopes 55
  * Univers Hi-Fi 8
  * Informatique 190
  * Accessoire et périphérique 142
  * Accessoires pour ordinateur 32
  * Reseaux 10
  * Jardin 219
  * Piscine et Spa 28
  * Barbecue et cuisine extérieur 21
  * Matériels d'arrosage 67
  * Mobilier de jardin 9
  * Outils pour jardins 51
  * Protection et anti-nuisibles pour jardin 37
  * Auto & moto 188
  * Électronique embarquée 80
  * Accessoires auto 67
  * Pièces Auto 10
  * Aménagements intérieurs 15
  * Epicerie 96
  * Café, thé et boissons 11
  * Entretien de la maison et nettoyage 54
  * Huiles, vinaigres et sauces salade 8
  * Ingrédients de cuisine et pâtisserie 9
  * Animalerie 247
  * Chats 130
  * Chiens 94
  * Habitats et accessoires 31
  * Disponible au showroom 141
  * Showroom Sousse 141
  * Nouveauté 782
  * Cuisine 74
  * Électroménager 39
  * Meuble et décoration 48
  * Mode 74
  * Beauté & Bien être 135
  * Promo 8026
  * Cuisine 1119
  * Électroménager 380
  * Meuble et décoration 1017
  * Superette 60
  * Mode 976
  * Beauté & Bien être 1410
  * Meilleures ventes 15
  * Livraison gratuite 1213
  * Bons plans 8090
  * Cuisine 1031
  * Électroménager 94
  * Meuble et décoration 1547
  * Superette 83
  * Mode 523
  * Beauté & Bien être 1407
  * Tout à moins 20 dinar 3194
  * Cuisine 510
  * Électroménager 20
  * Meuble et décoration 350
  * Superette 48
  * Mode 166
  * Beauté & Bien être 846
  * Fashion Make up 12
  * Valises 15
  * Ensembles de valises 8
  * Panneau mural 60
  * Panneaux 3D en PVC 18
  * Papier peint 28
  * Papier peint autocollant 8
  * Ramadan 2024 841
  * أفاريات الكوجينة 661
  * ديكور سبسيال رمضان 46
  * Jobba & Horka 19
  * Aïd al-Adha 212
  * Equipement de Cuisson 13
  * Outils de Préparation 172
  * Bakhoor 21
  * Vacances au bord de la mer 27
  * Sur la Plage 27
  * La Rentrée scolaire 118
  * Cartables et Sacs à dos 44
  * Repas Scolaire 38
  * Fournitures Scolaires 36
  * Expédié par Wamia 87

Prix

  1. [30000000,000 -DT \- 29999000,010 -DT2 article](https://www.wamia.tn/catalogsearch/result/index/?price=-30000000--29999000&q=Lampe+de+table+LED)
  2. [1000,000 -DT \- 0,010 -DT22 article](https://www.wamia.tn/catalogsearch/result/index/?price=-1000-0&q=Lampe+de+table+LED)
  3. [0,000 DT \- 999,990 DT11355 article](https://www.wamia.tn/catalogsearch/result/index/?price=0-1000&q=Lampe+de+table+LED)
  4. [1000,000 DT \- 1999,990 DT86 article](https://www.wamia.tn/catalogsearch/result/index/?price=1000-2000&q=Lampe+de+table+LED)
  5. [2000,000 DT \- 2999,990 DT10 article](https://www.wamia.tn/catalogsearch/result/index/?price=2000-3000&q=Lampe+de+table+LED)
  6. [3000,000 DT \- 3999,990 DT4 article](https://www.wamia.tn/catalogsearch/result/index/?price=3000-4000&q=Lampe+de+table+LED)
  7. [5000,000 DT \- 5999,990 DT1 article](https://www.wamia.tn/catalogsearch/result/index/?price=5000-6000&q=Lampe+de+table+LED)

Classe scolaire

  1. [1 ère année scolaire9 article](https://www.wamia.tn/catalogsearch/result/index/?classe_scolaire=16291&q=Lampe+de+table+LED)
  2. [2 ème année scolaire9 article](https://www.wamia.tn/catalogsearch/result/index/?classe_scolaire=16286&q=Lampe+de+table+LED)
  3. [4 ème année scolaire8 article](https://www.wamia.tn/catalogsearch/result/index/?classe_scolaire=16287&q=Lampe+de+table+LED)
  4. [4 ème année scolaire8 article](https://www.wamia.tn/catalogsearch/result/index/?classe_scolaire=16288&q=Lampe+de+table+LED)
  5. [5 ème année scolaire7 article](https://www.wamia.tn/catalogsearch/result/index/?classe_scolaire=16289&q=Lampe+de+table+LED)
  6. [6 ème année scolaire7 article](https://www.wamia.tn/catalogsearch/result/index/?classe_scolaire=16290&q=Lampe+de+table+LED)
  7. [Collège23 article](https://www.wamia.tn/catalogsearch/result/index/?classe_scolaire=18342&q=Lampe+de+table+LED)
  8. [Lycée17 article](https://www.wamia.tn/catalogsearch/result/index/?classe_scolaire=18343&q=Lampe+de+table+LED)

Smart Tv

  1. [Oui17 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&smart_tv=1)
  2. [Non2 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&smart_tv=0)

Taille

  1. [XS16 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10624)
  2. [S154 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10625)
  3. [M220 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10626)
  4. [L205 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10627)
  5. [XL196 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10628)
  6. [XXL146 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10629)
  7. [XXXL62 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10630)
  8. [4XL27 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=18407)
  9. [5XL4 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=18441)
  10. [6XL1 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=18442)
  11. [S-M5 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10639)
  12. [M-L2 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15509)
  13. [L-XL3 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10640)
  14. [XL-XXL2 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=16528)
  15. [Standard25 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10631)
  16. [296 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15502)
  17. [3010 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15500)
  18. [319 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15501)
  19. [3212 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15510)
  20. [3310 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15499)
  21. [3414 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15503)
  22. [3648 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10632)
  23. [3866 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10633)
  24. [4054 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10634)
  25. [4243 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10635)
  26. [4438 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10636)
  27. [4623 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10650)
  28. [4815 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15507)
  29. [503 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15508)
  30. [524 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10643)
  31. [541 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15514)
  32. [6 mois6 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15529)
  33. [1 an26 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=18410)
  34. [2 ans35 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10648)
  35. [3 ans26 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=18411)
  36. [4 ans117 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10645)
  37. [5 ans11 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=18412)
  38. [6 ans167 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10646)
  39. [8 ans156 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=12401)
  40. [10 ans136 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10647)
  41. [12 ans116 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10644)
  42. [14 ans120 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15950)
  43. [16 ans70 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=16556)
  44. [T115 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10637)
  45. [T218 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10638)
  46. [T36 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=10649)
  47. [T420 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15506)
  48. [T52 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=16529)
  49. [T67 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15530)
  50. [T85 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15531)
  51. [T109 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15532)
  52. [T124 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15533)
  53. [T141 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=15534)
  54. [181 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=18455)
  55. [191 article](https://www.wamia.tn/catalogsearch/result/index/?q=Lampe+de+table+LED&size=18456)

Évaluation

  * et plus 48
  * et plus 51
  * et plus 55
  * et plus 70

**Rechercher des marques** [All Brands](https://www.wamia.tn/brand)

**Top marque**

[![Acem](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/acme.png)](https://www.wamia.tn/brand/acem
"Acem")

[![Adidas](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/adidas_1.jpg)](https://www.wamia.tn/brand/adidas
"Adidas")

[![Arcopal](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/a.png)](https://www.wamia.tn/brand/arcopal
"Arcopal")

[![Babyliss](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/Sans_titre-1_1.jpg)](https://www.wamia.tn/brand/babyliss
"Babyliss")

[![BEKO](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/beko.jpg)](https://www.wamia.tn/brand/beko
"BEKO")

[![Bormioli
Rocco](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/bo.png)](https://www.wamia.tn/brand/bormioli-
rocco "Bormioli Rocco")

[![Bosch](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/bosch.jpg)](https://www.wamia.tn/brand/bosch
"Bosch")

[![Dell](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/sell.jpg)](https://www.wamia.tn/brand/dell
"Dell")

[![Delonghi
](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/delonghi.jpg)](https://www.wamia.tn/brand/delonghi
"Delonghi ")

[![Diager](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/di.png)](https://www.wamia.tn/brand/diager
"Diager")

[![Dsp](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/DSP.png)](https://www.wamia.tn/brand/dsp
"Dsp")

[![DUXXA](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/DUXXA.png)](https://www.wamia.tn/brand/duxxa
"DUXXA")

[![Epson](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/epson.jpg)](https://www.wamia.tn/brand/epson
"Epson")

[![Fasa](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/FASA.png)](https://www.wamia.tn/brand/fasa
"Fasa")

[![Filorga](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/FILORGA.png)](https://www.wamia.tn/brand/filorga
"Filorga")

[![Florence](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/dd.png)](https://www.wamia.tn/brand/florence
"Florence")

[![Goldenwings](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/golden-
wings.png)](https://www.wamia.tn/brand/goldenwings "Goldenwings")

[![Hascevher](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/hascevher.jpg)](https://www.wamia.tn/brand/hascevher
"Hascevher")

[![Hp](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/hp.jpg)](https://www.wamia.tn/brand/hp
"Hp")

[![Huawei](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/huawei.jpg)](https://www.wamia.tn/brand/huawei
"Huawei")

[![Lavor](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/lov.png)](https://www.wamia.tn/brand/lavor
"Lavor")

[![Lenovo](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/lrnovo.jpg)](https://www.wamia.tn/brand/lenovo
"Lenovo")

[![Luminarc](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/lim.png)](https://www.wamia.tn/brand/luminarc
"Luminarc")

[![Moulinex](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/moulinex.jpg)](https://www.wamia.tn/brand/moulinex
"Moulinex")

[![MSI](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/msi.jpg)](https://www.wamia.tn/brand/msi
"MSI")

[![Mustela](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/mpus.png)](https://www.wamia.tn/brand/mustela
"Mustela")

[![Nova](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/nova.png)](https://www.wamia.tn/brand/nova
"Nova")

[![Olina](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/olina.png)](https://www.wamia.tn/brand/olina
"Olina")

[![Philips](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/PHILIPS.png)](https://www.wamia.tn/brand/philips
"Philips")

[![Romoss](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/ROMOSS.png)](https://www.wamia.tn/brand/romoss
"Romoss")

[![Sandisk](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/s.png)](https://www.wamia.tn/brand/sandisk
"Sandisk")

[![Sifcol](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/SIFCOL.png)](https://www.wamia.tn/brand/sifcol
"Sifcol")

[![Sokany](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/sokany_1.jpg)](https://www.wamia.tn/brand/sokany
"Sokany")

[![Sumex](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/Sumex.png)](https://www.wamia.tn/brand/sumex
"Sumex")

[![Svr](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/svr_1.jpg)](https://www.wamia.tn/brand/svr
"Svr")

[![Tem](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/Tem.png)](https://www.wamia.tn/brand/tem
"Tem")

[![Wahl](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/whl.png)](https://www.wamia.tn/brand/wahl
"Wahl")

[![Wayscral
](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/w.png)](https://www.wamia.tn/brand/wayscral
"Wayscral ")

[![Winox](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/wamia/winox.png)](https://www.wamia.tn/brand/winox
"Winox")

[![X6](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/X6.png)](https://www.wamia.tn/brand/x6
"X6")

[![Zimota](https://www.wamia.tn/media/codazon_cache/brand/150x150/wysiwyg/Zitouma.png)](https://www.wamia.tn/brand/zimota
"Zimota")

prev

next

**Comparer des produits**

Vous n’avez pas d’articles à comparer.

**Ma liste d’envies**

**Derniers articles ajoutés**

Il n’y a aucun article dans votre liste d’envies.

  * [__](https://www.wamia.tn/) Home
  * [__](https://www.wamia.tn/marketplace/account/dashboard/) TB Vendeur
  * [__](javascript:void\(0\)) Cart
  * [__](https://www.wamia.tn/customer/account/) Account

  * [ __](https://www.wamia.tn/contact/) Contact
  * [__](https://www.wamia.tn/wishlist/) Wishlist
  * [__](https://www.wamia.tn/catalog/product_compare/) Compare
  * [__](javascript:void\(0\)) Menu

‹›

Plus

You have no items in your shopping cart

Top

**Commander en tant que nouveau client**

La création d’un compte possède de nombreux avantages :

  * Voir le statut de la commande et de l’expédition
  * Suivi de la commande
  * Commandez plus rapidement

[ Créer un compte ](https://www.wamia.tn/customer/account/create/)

**Commander en utilisant votre compte**

Adresse email

Mot de passe

Connexion

[ Mot de passe oublié ?
](https://www.wamia.tn/customer/account/forgotpassword/)

