from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from elasticsearch import Elasticsearch
import datetime
import uuid
import logging
import time
import os
import requests
import json
import pandas as pd
import io
from werkzeug.utils import secure_filename
import calendar
import tempfile
import math
import jwt
import bcrypt
from functools import wraps
from datetime import datetime, timedelta
import uuid

elasticsearch_host = os.environ.get('ELASTICSEARCH_HOST', 'localhost')

# Configuration du logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)
# Configuration plus précise pour CORS
CORS(app, origins="*", allow_headers=["Content-Type", "Authorization"])

# Variables pour la connexion à Elasticsearch avec retry
es = None
max_retries = 30
retry_count = 0
retry_delay = 5

# Répertoire temporaire pour les fichiers uploadés
UPLOAD_FOLDER = tempfile.gettempdir()
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Limite à 16 Mo

# Fonction pour se connecter à Elasticsearch avec des tentatives répétées
def connect_to_elasticsearch():
    global retry_count
    while retry_count < max_retries:
        try:
            es_client = Elasticsearch([f"http://{elasticsearch_host}:9200"])
            
            # Test de connexion
            if es_client.ping():
                logger.info("Connexion à Elasticsearch établie avec succès")
                return es_client
            else:
                logger.warning(f"Échec du ping Elasticsearch (tentative {retry_count+1}/{max_retries})")
                
        except Exception as e:
            logger.error(f"Erreur de connexion à Elasticsearch: {str(e)} (tentative {retry_count+1}/{max_retries})")
        
        retry_count += 1
        time.sleep(retry_delay)
        
    logger.error(f"Impossible de se connecter à Elasticsearch après {max_retries} tentatives")
    return None

# Tentative de connexion au démarrage
es = connect_to_elasticsearch()

def ensure_elasticsearch_indices():
    try:
        # Check if users index exists
        if not es.indices.exists(index="users"):
            logger.info("Creating 'users' index...")
            es.indices.create(
                index="users",
                body={
                    "mappings": {
                        "properties": {
                            "name": {"type": "text"},
                            "email": {"type": "keyword"},
                            "password": {"type": "keyword"},
                            "created_at": {"type": "date"}
                        }
                    }
                }
            )
            logger.info("'users' index created successfully")
    except Exception as e:
        logger.error(f"Error ensuring indices: {str(e)}")

# Call this function after establishing Elasticsearch connection
ensure_elasticsearch_indices()

# Clé secrète pour JWT
JWT_SECRET = os.environ.get('JWT_SECRET', 'votre_clé_secrète_à_modifier')
JWT_EXPIRATION = 24  # Heures

# Décorateur pour routes protégées par authentification
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]
        
        if not token:
            return jsonify({'error': 'Token manquant'}), 401
            
        try:
            data = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
            # Vérifier si l'utilisateur existe toujours
            user_response = es.get(index="users", id=data['user_id'], ignore=404)
            if user_response.get('found', False) is False:
                return jsonify({'error': 'Utilisateur non trouvé'}), 401
                
            current_user = user_response['_source']
            current_user['id'] = data['user_id']
        except Exception as e:
            return jsonify({'error': f'Token invalide: {str(e)}'}), 401
            
        return f(current_user, *args, **kwargs)
    return decorated

# Routes d'authentification
@app.route('/api/auth/signup', methods=['POST'])
def signup():
    try:
        data = request.json
        
        if not data or not data.get('email') or not data.get('password') or not data.get('name'):
            return jsonify({'error': 'Données incomplètes'}), 400
            
        email = data.get('email').lower()
        password = data.get('password')
        name = data.get('name')
        
        # Vérifier si l'email existe déjà
        search_response = es.search(
            index="users",
            body={
                "query": {
                    "term": {"email.keyword": email}
                }
            }
        )
        
        if search_response['hits']['total']['value'] > 0:
            return jsonify({'error': 'Email déjà utilisé'}), 400
            
        # Hasher le mot de passe
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        
        # Créer l'utilisateur
        user = {
            'email': email,
            'name': name,
            'password': hashed_password,
            'role': 'user',  # Par défaut
            'created_at': datetime.now().isoformat()
        }
        
        result = es.index(index="users", document=user)
        
        return jsonify({
            'message': 'Utilisateur créé avec succès',
            'user_id': result['_id']
        }), 201
        
    except Exception as e:
        logger.error(f"Erreur lors de l'inscription: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.json
        
        if not data or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email et mot de passe requis'}), 400
            
        email = data.get('email').lower()
        password = data.get('password')
        
        # Print the received password (for debugging)
        print(f"Received raw password: {password}")
        
        # Rechercher l'utilisateur
        search_response = es.search(
            index="users",
            body={
                "query": {
                    "term": {"email.keyword": email}
                }
            }
        )
        
        if search_response['hits']['total']['value'] == 0:
            return jsonify({'error': 'Email ou mot de passe incorrect'}), 401
            
        user = search_response['hits']['hits'][0]['_source']
        user_id = search_response['hits']['hits'][0]['_id']
        
        # Print the stored encrypted password
        print(f"Stored encrypted password: {user['password']}")
        
        # Vérifier le mot de passe
        if not bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
            return jsonify({'error': 'Email ou mot de passe incorrect'}), 401
            
        # Rest of your login logic...
        token = jwt.encode({
            'user_id': user_id,
            'email': email,
            'name': user['name'],
            'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRATION)
        }, JWT_SECRET)
        
        return jsonify({
            'token': token,
            'user': {
                'id': user_id,
                'name': user['name'],
                'email': email,
                'role': user.get('role', 'user')
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Erreur lors de la connexion: {str(e)}")
        return jsonify({'error': str(e)}), 500
        
@app.route('/api/auth/user', methods=['GET'])
@token_required
def get_user(current_user):
    # Obtenir les informations de l'utilisateur actuel
    return jsonify({
        'id': current_user['id'],
        'name': current_user['name'],
        'email': current_user['email'],
        'role': current_user.get('role', 'user')
    }), 200

# Route pour le dashboard
@app.route('/api/dashboard/<product_id>', methods=['GET'])
@token_required
def get_dashboard_data(current_user, product_id):
    """Récupère toutes les données pour le dashboard d'un produit"""
    try:
        # Récupérer le produit
        product = es.get(index="products", id=product_id, ignore=404)
        if not product.get('found', False):
            return jsonify({'error': 'Produit non trouvé'}), 404
            
        product_data = product['_source']
        product_data['id'] = product_id
        
        # Récupérer le KPI
        kpi_response = es.search(
            index="kpis",
            body={"query": {"term": {"product_id.keyword": product_id}}},
            size=1
        )
        kpi_data = {}
        if kpi_response['hits']['total']['value'] > 0:
            kpi_data = kpi_response['hits']['hits'][0]['_source']
        
        # Récupérer les résultats de scraping
        scrape_response = es.search(
            index="product_scraping_results",
            body={
                "query": {"term": {"product_id.keyword": product_id}},
                "sort": [{"timestamp": {"order": "desc"}}]
            },
            size=10
        )
        scraping_results = [hit['_source'] for hit in scrape_response['hits']['hits']]
        
        # Récupérer les données de vente
        orders_data = get_product_orders(product_id)
        
        # Nombre de concurrents
        competitor_count = 0
        price_distribution = []
        
        if scraping_results and len(scraping_results) > 0:
            latest_result = scraping_results[0]
            if 'scraping_data' in latest_result:
                # Extraire les sites concurrents
                competitors = set()
                
                # Extraire tous les prix pour la distribution
                all_prices = extract_prices_from_scraping(latest_result['scraping_data'])
                
                # Organiser les prix en tranches pour l'histogramme
                if all_prices:
                    min_price = min(all_prices)
                    max_price = max(all_prices)
                    
                    # Créer 10 tranches de prix équidistantes
                    step = (max_price - min_price) / 10 if max_price > min_price else 1
                    
                    price_ranges = []
                    for i in range(10):
                        lower_bound = min_price + i * step
                        upper_bound = min_price + (i + 1) * step
                        price_ranges.append({
                            'range': f"{lower_bound:.2f} - {upper_bound:.2f} TND",
                            'count': 0
                        })
                    
                    # Compter les prix dans chaque tranche
                    for price in all_prices:
                        index = min(int((price - min_price) / step), 9) if step > 0 else 0
                        price_ranges[index]['count'] += 1
                    
                    price_distribution = price_ranges
                
                # Si c'est un tableau, extraire les sources des listings
                if isinstance(latest_result['scraping_data'], list):
                    for item in latest_result['scraping_data']:
                        if 'source' in item:
                            competitors.add(item['source'])
                        elif 'url' in item and item['url']:
                            domain = item['url'].split('/')[2] if '//' in item['url'] else item['url'].split('/')[0]
                            competitors.add(domain)
                
                competitor_count = len(competitors)
        
        # Données de tendance des ventes sur 12 mois
        sales_trend = []
        best_periods = []
        
        if kpi_data and 'sales_analysis' in kpi_data and 'monthly_data' in kpi_data['sales_analysis']:
            monthly_data = kpi_data['sales_analysis']['monthly_data']
            
            # Transformer en format pour graphique en courbes
            months = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
                      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre']
            
            sales_by_month = [0] * 12
            for month_data in monthly_data:
                month_index = month_data.get('month', 0)
                if 0 <= month_index < 12:
                    sales_by_month[month_index] = month_data.get('count', 0)
            
            sales_trend = [
                {'month': months[i], 'sales': sales_by_month[i]} 
                for i in range(12)
            ]
            
            # Périodes pour le graphique en secteurs (top 5)
            sorted_months = sorted(monthly_data, key=lambda x: x.get('count', 0), reverse=True)
            top_months = sorted_months[:5]
            
            best_periods = [
                {'name': month.get('name', 'Inconnu'), 
                 'count': month.get('count', 0), 
                 'percentage': (month.get('count', 0) / sum(m.get('count', 0) for m in monthly_data) * 100) if sum(m.get('count', 0) for m in monthly_data) > 0 else 0
                } for month in top_months if month.get('count', 0) > 0
            ]
        
        # Information sur le prix idéal pour la jauge
        ideal_price_gauge = {
            'current': product_data.get('price', 0),
            'ideal': kpi_data.get('ideal_price', product_data.get('price', 0)),
            'min': 0,
            'max': product_data.get('price', 0) * 1.5  # 150% du prix actuel comme maximum
        }
        
        # Données de volume des ventes par période
        sales_volume = []
        
        if kpi_data and 'sales_analysis' in kpi_data and 'monthly_data' in kpi_data['sales_analysis']:
            monthly_data = kpi_data['sales_analysis']['monthly_data']
            
            # Transformer en format pour graphique en barres
            quarters = {
                'Q1': {'name': 'Premier Trimestre', 'months': [0, 1, 2], 'sales': 0},
                'Q2': {'name': 'Deuxième Trimestre', 'months': [3, 4, 5], 'sales': 0},
                'Q3': {'name': 'Troisième Trimestre', 'months': [6, 7, 8], 'sales': 0},
                'Q4': {'name': 'Quatrième Trimestre', 'months': [9, 10, 11], 'sales': 0}
            }
            
            for month_data in monthly_data:
                month_index = month_data.get('month', 0)
                month_sales = month_data.get('count', 0)
                
                for quarter, data in quarters.items():
                    if month_index in data['months']:
                        data['sales'] += month_sales
            
            sales_volume = [
                {'period': data['name'], 'sales': data['sales']}
                for _, data in quarters.items()
            ]
            
        # Assembler toutes les données
        dashboard_data = {
            'product': product_data,
            'sales_trend': sales_trend,
            'price_distribution': price_distribution,
            'ideal_price_gauge': ideal_price_gauge,
            'sales_volume': sales_volume,
            'best_periods': best_periods,
            'competitor_count': competitor_count,
            'recommendation': kpi_data.get('recommendation', "Aucune recommandation disponible")
        }
        
        return jsonify(dashboard_data), 200
    
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des données du dashboard: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Endpoint pour créer/ajouter des produits
@app.route('/api/products', methods=['POST'])
def create_products():
    try:
        # Vérifier si Elasticsearch est disponible
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
        
        data = request.json
        
        if not data or 'products' not in data:
            return jsonify({'error': 'Données invalides'}), 400
        
        products = data['products']
        
        if not products:
            return jsonify({'error': 'Aucun produit fourni'}), 400
        
        # Validation rapide des produits
        for product in products:
            if 'name' not in product:
                return jsonify({'error': 'Nom du produit manquant'}), 400
            if 'price' not in product:
                return jsonify({'error': 'Prix du produit manquant'}), 400
        
        # Ajouter les produits à Elasticsearch
        results = []
        for product in products:
            # Ajouter la date de création
            product['created_at'] = datetime.datetime.now().isoformat()
            
            # Indexer dans Elasticsearch
            result = es.index(index="products", document=product)
            results.append({
                'id': result['_id'],
                'name': product['name'],
                'status': 'created'
            })
        
        return jsonify({
            'message': f'{len(results)} produits ajoutés avec succès',
            'products': results
        }), 201
        
    except Exception as e:
        logger.error(f"Erreur lors de la création des produits: {str(e)}")
        return jsonify({'error': str(e)}), 500

def calculate_ideal_price(scrape_results):
    """Calcule le prix idéal basé sur les données scrapées"""
    prices = extract_prices_from_scraping(scrape_results)
    
    if not prices:
        return None
    
    # Trier les prix du plus bas au plus élevé
    prices.sort()
    
    # Éliminer les valeurs aberrantes (10% les plus bas et 10% les plus élevés)
    if len(prices) > 5:
        cutoff_low = int(len(prices) * 0.1)
        cutoff_high = int(len(prices) * 0.9)
        filtered_prices = prices[cutoff_low:cutoff_high]
    else:
        filtered_prices = prices
    
    # Calculer la moyenne
    if filtered_prices:
        avg_price = sum(filtered_prices) / len(filtered_prices)
        # 5% en dessous du prix moyen
        return avg_price * 0.95
    else:
        return None

def extract_prices_from_scraping(scrape_results):
    """Extrait les prix des résultats de scraping"""
    prices = []
    
    if not scrape_results or 'results' not in scrape_results:
        return prices
    
    # Parcourir les résultats de chaque site
    for result in scrape_results['results']:
        for data_item in result.get('data', []):
            # Extraire les prix des listings
            if 'listings' in data_item and isinstance(data_item['listings'], list):
                for listing in data_item['listings']:
                    if 'price' in listing:
                        # Convertir en float en supprimant les caractères non-numériques
                        try:
                            price_str = str(listing['price']).replace('TND', '').replace('€', '').strip()
                            price_str = ''.join(c for c in price_str if c.isdigit() or c in '.,')
                            price_str = price_str.replace(',', '.')
                            price = float(price_str)
                            prices.append(price)
                        except (ValueError, TypeError):
                            pass
    return prices

def generate_price_recommendation(current_price, ideal_price):
    """Génère une recommandation de prix"""
    if current_price is None or ideal_price is None:
        return "Impossible de générer une recommandation sans prix"
    
    diff = current_price - ideal_price
    diff_percent = (diff / ideal_price) * 100 if ideal_price else 0
    
    if abs(diff_percent) < 5:
        return "Le prix actuel est optimal par rapport au marché"
    elif diff_percent > 10:
        return f"Le prix est élevé par rapport au marché (+{diff_percent:.1f}%). Envisagez une réduction pour améliorer la compétitivité."
    elif diff_percent > 0:
        return f"Le prix est légèrement supérieur au marché (+{diff_percent:.1f}%). Une petite réduction pourrait augmenter les ventes."
    elif diff_percent < -10:
        return f"Le prix est très compétitif (-{abs(diff_percent):.1f}%). Envisagez une légère augmentation pour maximiser la marge."
    else:
        return f"Le prix est en dessous du marché (-{abs(diff_percent):.1f}%). Une légère augmentation est possible."

@app.route('/api/test', methods=['GET'])
def test_api():
    return jsonify({'status': 'API fonctionnelle', 'elasticsearch': es is not None})

@app.route('/api/products', methods=['GET'])
def get_products():
    try:
        # Vérifier si Elasticsearch est disponible
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
        
        # Récupérer l'ID du produit s'il est spécifié
        product_id = request.args.get('id')
        
        if product_id:
            # Rechercher un produit spécifique
            try:
                response = es.get(index="products", id=product_id)
                product = response['_source']
                product['id'] = response['_id']
                return jsonify([product]), 200
            except Exception as e:
                logger.error(f"Erreur lors de la récupération du produit {product_id}: {str(e)}")
                return jsonify({'error': f'Produit non trouvé: {str(e)}'}), 404
        
        # Récupérer le paramètre size (par défaut 100)
        size = request.args.get('size', default=100, type=int)
        
        # Recherche simple retournant tous les produits avec le paramètre size
        response = es.search(
            index="products",
            body={
                "query": {"match_all": {}},
                "size": size  # Ajout du paramètre size ici
            }
        )
        
        # Ajouter l'ID à chaque produit
        products = []
        for hit in response['hits']['hits']:
            product = hit['_source']
            product['id'] = hit['_id']  # Ajouter l'ID pour référence
            products.append(product)
            
        return jsonify(products), 200
    
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des produits: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Nouvel endpoint pour récupérer les catégories uniques
@app.route('/api/categories', methods=['GET'])
def get_categories():
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
        
        # Agrégation pour récupérer les catégories uniques
        response = es.search(
            index="products",
            body={
                "size": 0,
                "aggs": {
                    "categories": {
                        "terms": {
                            "field": "category.keyword",
                            "size": 100
                        }
                    }
                }
            }
        )
        
        # Extraire les catégories des résultats d'agrégation
        categories = []
        for bucket in response['aggregations']['categories']['buckets']:
            if bucket['key']:  # Ignorer les catégories vides
                categories.append(bucket['key'])
                
        return jsonify(categories), 200
    
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des catégories: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Endpoint pour rechercher des produits avec filtres
@app.route('/api/products/search', methods=['GET'])
def search_products():
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
        
        # Récupérer les paramètres de recherche
        query = request.args.get('q', '')
        category = request.args.get('category', '')
        min_price = request.args.get('min_price', '')
        max_price = request.args.get('max_price', '')
        
        # Construire la requête Elasticsearch
        should_clauses = []
        must_clauses = []
        filter_clauses = []
        
        if query:
            # Rechercher dans le nom et la description
            should_clauses.extend([
                {"match": {"name": {"query": query, "boost": 2}}},
                {"match": {"description": query}}
            ])
        
        if category:
            # Filtrer par catégorie
            filter_clauses.append({"term": {"category.keyword": category}})
        
        # Filtrer par plage de prix
        price_range = {}
        if min_price:
            price_range["gte"] = float(min_price)
        if max_price:
            price_range["lte"] = float(max_price)
        
        if price_range:
            filter_clauses.append({"range": {"price": price_range}})
        
        # Assembler la requête finale
        if should_clauses:
            must_clauses.append({"bool": {"should": should_clauses}})
            
        body = {
            "query": {
                "bool": {
                    "must": must_clauses if must_clauses else [{"match_all": {}}],
                    "filter": filter_clauses
                }
            }
        }
        
        # Exécuter la recherche
        response = es.search(index="products", body=body)
        
        # Formater les résultats
        products = []
        for hit in response['hits']['hits']:
            product = hit['_source']
            product['id'] = hit['_id']
            products.append(product)
            
        return jsonify(products), 200
    
    except Exception as e:
        logger.error(f"Erreur lors de la recherche: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Endpoint pour récupérer les résultats de scraping
@app.route('/api/scraping-results', methods=['GET'])
def get_scraping_results():
    try:
        # Vérifier si l'index existe
        if not es.indices.exists(index="product_scraping_results"):
            logger.info("L'index 'product_scraping_results' n'existe pas")
            return jsonify([])
            
        # Paramètres de filtre
        product_id = request.args.get('product_id')
        status = request.args.get('status')
        result_id = request.args.get('id')
        
        if result_id:
            # Si un ID spécifique est demandé
            try:
                result = es.get(index="product_scraping_results", id=result_id)
                
                # Enrichir avec le nom du produit s'il est manquant
                if 'product_id' in result['_source'] and ('product_name' not in result['_source'] or not result['_source']['product_name']):
                    try:
                        product = es.get(index="products", id=result['_source']['product_id'])
                        result['_source']['product_name'] = product['_source'].get('name', 'Produit sans nom')
                    except:
                        result['_source']['product_name'] = 'Produit non trouvé'
                
                return jsonify(result['_source'] | {'id': result['_id']})
            except:
                return jsonify({'error': f'Résultat avec ID {result_id} non trouvé'}), 404
        
        # Construire la requête (code existant)...
        query = {"bool": {"must": []}}
        if product_id:
            query["bool"]["must"].append({"term": {"product_id.keyword": product_id}})
        if status:
            query["bool"]["must"].append({"term": {"status.keyword": status}})
        
        # Exécuter la requête
        results = es.search(
            index="product_scraping_results",
            body={
                "query": query,
                "sort": [{"timestamp": {"order": "desc"}}],
                "size": 100
            }
        )
        
        # Formater les résultats
        formatted_results = []
        for hit in results['hits']['hits']:
            product_id = hit['_source'].get('product_id')
            product_name = hit['_source'].get('product_name')
            
            # Si le nom du produit est manquant, essayer de le récupérer depuis l'index products
            if product_id and not product_name:
                try:
                    product = es.get(index="products", id=product_id)
                    product_name = product['_source'].get('name', 'Produit sans nom')
                except:
                    product_name = 'Produit non trouvé'
            
            formatted_results.append({
                'id': hit['_id'],
                'product_id': product_id,
                'product_name': product_name,
                'search_query': hit['_source'].get('search_query', product_name),
                'timestamp': hit['_source'].get('timestamp'),
                'scraping_data': hit['_source'].get('scraping_data'),
                'status': hit['_source'].get('status', 'completed'),
                'ideal_price': hit['_source'].get('ideal_price')
            })
        
        return jsonify(formatted_results)
        
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des résultats de scraping: {str(e)}")
        return jsonify({"error": str(e)}), 500


@app.route('/api/save-scraping', methods=['POST'])
def save_scraping():
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
        
        data = request.json
        product_name = data.get('productName')
        scraping_data = data.get('scrapingData')
        
        if not product_name or not scraping_data:
            return jsonify({'error': 'Données manquantes'}), 400
        
        # Find product ID based on name
        search_response = es.search(
            index="products",
            body={
                "query": {
                    "match": {
                        "name": product_name
                    }
                }
            }
        )
        
        # Check if product exists
        if search_response['hits']['total']['value'] == 0:
            return jsonify({'error': f'Produit "{product_name}" introuvable'}), 404
            
        product_id = search_response['hits']['hits'][0]['_id']
        product = search_response['hits']['hits'][0]['_source']
        current_price = product.get('price', 0)
        timestamp = datetime.datetime.now().isoformat()
        
        # Calculer le prix idéal
        ideal_price = calculate_ideal_price(scraping_data)
        
        # Calculer la différence de prix
        price_difference = None
        if ideal_price is not None and current_price is not None:
            price_difference = ideal_price - current_price
            
        # Générer une recommandation
        recommendation = generate_price_recommendation(current_price, ideal_price)
        
        # Vérifier s'il existe déjà un résultat pour ce produit
        existing_result = es.search(
            index="product_scraping_results",
            body={
                "query": {
                    "term": {"product_id.keyword": product_id}
                },
                "sort": [{"timestamp": {"order": "desc"}}],
                "size": 1
            }
        )
        
        # Si un résultat existe déjà, mettre à jour ce document
        if existing_result['hits']['hits']:
            existing_id = existing_result['hits']['hits'][0]['_id']
            
            # Mettre à jour le document existant
            es.update(
                index="product_scraping_results",
                id=existing_id,
                body={
                    'doc': {
                        'search_query': product_name,
                        'timestamp': timestamp,
                        'scraping_data': scraping_data,
                        'status': 'completed',
                        'ideal_price': ideal_price
                    }
                }
            )
            
            result_id = existing_id
        else:
            # Créer un nouveau document
            scraping_doc = {
                'product_id': product_id,
                'product_name': product_name,
                'search_query': product_name,
                'timestamp': timestamp,
                'scraping_data': scraping_data,
                'status': 'completed',
                'ideal_price': ideal_price
            }
            
            # Enregistrer dans Elasticsearch
            result = es.index(
                index='product_scraping_results',
                document=scraping_doc
            )
            
            result_id = result['_id']
        
        # Mettre à jour la date de dernière analyse et le prix idéal du produit
        es.update(
            index='products',
            id=product_id,
            body={
                'doc': {
                    'last_analysis_date': timestamp,
                    'ideal_price': ideal_price
                }
            }
        )
        
        # AJOUT: Créer ou mettre à jour le document KPI pour ce produit
        # Extraire tous les prix des résultats de scraping pour les sauvegarder
        scraped_prices = extract_prices_from_scraping(scraping_data)
        
        # Vérifier s'il existe déjà un KPI pour ce produit
        kpi_response = es.search(
            index="kpis",
            body={
                "query": {
                    "term": {"product_id.keyword": product_id}
                }
            },
            size=1
        )
        
        # Récupérer les données d'analyse des ventes
        sales_analysis = {}
        try:
            orders_data = get_product_orders(product_id)
            if orders_data:
                sales_analysis = analyze_orders_by_month(orders_data)
        except Exception as e:
            logger.error(f"Erreur lors de l'analyse des ventes: {str(e)}")
        
        # Créer ou mettre à jour le KPI
        kpi_doc = {
            'product_id': product_id,
            'product_name': product_name,
            'current_price': current_price,
            'ideal_price': ideal_price,
            'price_difference': price_difference,
            'market_analysis_date': timestamp,
            'recommendation': recommendation,
            'scraped_prices': scraped_prices,
            'sales_analysis': sales_analysis,
            'updated_at': timestamp
        }
        
        # Si un KPI existe, le mettre à jour, sinon en créer un nouveau
        if kpi_response['hits']['hits']:
            kpi_id = kpi_response['hits']['hits'][0]['_id']
            es.update(
                index='kpis',
                id=kpi_id,
                body={
                    'doc': kpi_doc
                }
            )
        else:
            es.index(
                index='kpis',
                document=kpi_doc
            )
        
        return jsonify({
            'success': True,
            'message': 'Résultats de scraping sauvegardés avec succès',
            'id': result_id
        }), 200
        
    except Exception as e:
        logger.error(f"Erreur lors de l'enregistrement des résultats: {str(e)}")
        return jsonify({"error": str(e)}), 500
    

# Endpoint pour récupérer les KPIs
@app.route('/api/kpis', methods=['GET'])
def get_kpis():
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
        
        product_id = request.args.get('product_id')
        
        if product_id:
            # Rechercher les KPIs pour un produit spécifique
            query = {"term": {"product_id.keyword": product_id}}
        else:
            # Retourner tous les KPIs
            query = {"match_all": {}}
        
        response = es.search(
            index="kpis",
            body={
                "query": query,
                "sort": [{"market_analysis_date": {"order": "desc"}}],
                "size": 100
            }
        )
        
        kpis = []
        for hit in response['hits']['hits']:
            kpi = hit['_source']
            kpi['id'] = hit['_id']
            kpis.append(kpi)
            
        return jsonify(kpis), 200
    
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des KPIs: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Endpoint pour supprimer un produit
@app.route('/api/products/<product_id>', methods=['DELETE'])
def delete_product(product_id):
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
            
        # Vérifier si le produit existe
        try:
            es.get(index="products", id=product_id)
        except Exception:
            return jsonify({'error': f'Produit avec ID {product_id} non trouvé'}), 404
            
        # Supprimer le produit
        es.delete(index="products", id=product_id)
        
        return jsonify({
            'success': True,
            'message': f'Produit avec ID {product_id} supprimé avec succès'
        }), 200
        
    except Exception as e:
        logger.error(f"Erreur lors de la suppression du produit: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Nouvel endpoint pour l'importation CSV des produits
@app.route('/api/products/import/csv', methods=['POST'])
def import_products_csv():
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
            
        # Vérifier si un fichier a été envoyé
        if 'file' not in request.files:
            return jsonify({'error': 'Aucun fichier envoyé'}), 400
            
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'Aucun fichier sélectionné'}), 400
            
        if not file.filename.endswith('.csv'):
            return jsonify({'error': 'Le fichier doit être au format CSV'}), 400
        
        # Sauvegarder temporairement le fichier
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Obtenir les mappages de colonnes depuis la requête
        name_column = request.form.get('name_column')
        price_column = request.form.get('price_column')
        description_column = request.form.get('description_column', None)
        category_column = request.form.get('category_column', None)
        stock_column = request.form.get('stock_column', None)
        
        if not name_column or not price_column:
            return jsonify({'error': 'Les colonnes pour le nom et le prix sont obligatoires'}), 400
        
        # Lire le fichier CSV
        try:
            df = pd.read_csv(filepath, encoding='utf-8')
        except UnicodeDecodeError:
            try:
                df = pd.read_csv(filepath, encoding='latin1')
            except Exception as e:
                return jsonify({'error': f'Impossible de lire le fichier CSV: {str(e)}'}), 400
        
        # Vérifier que les colonnes existent
        required_columns = [name_column, price_column]
        optional_columns = [col for col in [description_column, category_column, stock_column] if col]
        
        for column in required_columns + optional_columns:
            if column not in df.columns:
                return jsonify({'error': f'Colonne "{column}" non trouvée dans le fichier CSV'}), 400
        
        # Préparer les produits
        products = []
        for _, row in df.iterrows():
            try:
                # Convertir le prix en float
                price_value = row[price_column]
                if isinstance(price_value, str):
                    price_value = price_value.replace('TND', '').replace('€', '').strip()
                    price_value = ''.join(c for c in price_value if c.isdigit() or c in '.,')
                    price_value = float(price_value.replace(',', '.'))
                
                # Créer le produit
                product = {
                    'name': row[name_column],
                    'price': price_value,
                    'created_at': datetime.datetime.now().isoformat()
                }
                
                # Ajouter les champs optionnels
                if description_column and not pd.isna(row[description_column]):
                    product['description'] = row[description_column]
                
                if category_column and not pd.isna(row[category_column]):
                    product['category'] = row[category_column]
                
                if stock_column and not pd.isna(row[stock_column]):
                    product['stock'] = int(row[stock_column])
                
                products.append(product)
            except Exception as e:
                logger.warning(f"Erreur lors du traitement de la ligne {_}: {str(e)}")
                continue
        
        if not products:
            return jsonify({'error': 'Aucun produit valide trouvé dans le fichier CSV'}), 400
        
        # Ajouter les produits à Elasticsearch
        results = []
        for product in products:
            result = es.index(index="products", document=product)
            results.append({
                'id': result['_id'],
                'name': product['name'],
                'status': 'created'
            })
        
        # Supprimer le fichier temporaire
        os.remove(filepath)
        
        return jsonify({
            'message': f'{len(results)} produits importés avec succès',
            'products': results
        }), 201
        
    except Exception as e:
        logger.error(f"Erreur lors de l'importation CSV: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Fonction utilitaire pour l'analyse des périodes par mois
def analyze_orders_by_month(orders_data):
    """Analyse les commandes par mois pour déterminer la meilleure période de vente"""
    monthly_counts = {}
    best_month = None
    max_count = 0
    
    for order in orders_data:
        order_date = order.get('order_date')
        if not order_date:
            continue
            
        try:
            date_obj = datetime.datetime.fromisoformat(order_date)
            month_name = date_obj.strftime("%B")
            month_number = date_obj.month
            
            if month_number not in monthly_counts:
                monthly_counts[month_number] = {
                    'name': month_name,
                    'count': 0,
                    'total_sales': 0
                }
                
            monthly_counts[month_number]['count'] += 1
            monthly_counts[month_number]['total_sales'] += order.get('total_amount', 0)
            
            if monthly_counts[month_number]['count'] > max_count:
                max_count = monthly_counts[month_number]['count']
                best_month = month_number
        except Exception as e:
            logger.warning(f"Erreur lors de l'analyse de la date {order_date}: {str(e)}")
    
    # Formater le résultat
    all_months = []
    for month_num in sorted(monthly_counts.keys()):
        all_months.append({
            'month': month_num,
            'name': monthly_counts[month_num]['name'],
            'count': monthly_counts[month_num]['count'],
            'total_sales': monthly_counts[month_num]['total_sales']
        })
    
    best_period = None
    if best_month:
        best_period = {
            'month': best_month,
            'name': monthly_counts[best_month]['name'],
            'count': monthly_counts[best_month]['count'],
            'total_sales': monthly_counts[best_month]['total_sales']
        }
    
    return {
        'best_period': best_period,
        'monthly_data': all_months
    }

# Nouvel endpoint pour l'importation des commandes
@app.route('/api/orders/import', methods=['POST'])
def import_orders():
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
            
        # Vérifier si un fichier a été envoyé
        if 'file' not in request.files:
            return jsonify({'error': 'Aucun fichier envoyé'}), 400
            
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'Aucun fichier sélectionné'}), 400
            
        if not file.filename.endswith('.csv'):
            return jsonify({'error': 'Le fichier doit être au format CSV'}), 400
        
        # Sauvegarder temporairement le fichier
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Obtenir les mappages de colonnes depuis la requête
        order_id_column = request.form.get('order_id_column')
        product_id_column = request.form.get('product_id_column')
        product_name_column = request.form.get('product_name_column')
        quantity_column = request.form.get('quantity_column')
        price_column = request.form.get('price_column')
        date_column = request.form.get('date_column')
        
        required_columns = [order_id_column, product_name_column, quantity_column]
        if not all(required_columns):
            return jsonify({'error': 'Les colonnes pour l\'ID de commande, le nom du produit et la quantité sont obligatoires'}), 400
        
        # Lire le fichier CSV
        try:
            df = pd.read_csv(filepath, encoding='utf-8')
        except UnicodeDecodeError:
            try:
                df = pd.read_csv(filepath, encoding='latin1')
            except Exception as e:
                return jsonify({'error': f'Impossible de lire le fichier CSV: {str(e)}'}), 400
        
        # Vérifier que les colonnes existent
        all_columns = [col for col in [order_id_column, product_id_column, product_name_column, quantity_column, price_column, date_column] if col]
        for column in all_columns:
            if column not in df.columns:
                return jsonify({'error': f'Colonne "{column}" non trouvée dans le fichier CSV'}), 400
        
        # Grouper les commandes par ID de commande
        order_groups = df.groupby(order_id_column)
        
        orders = []
        for order_id, group in order_groups:
            order_items = []
            total_amount = 0
            
            for _, row in group.iterrows():
                # Récupérer ou rechercher l'ID du produit
                product_id = None
                if product_id_column and not pd.isna(row[product_id_column]):
                    product_id = row[product_id_column]
                else:
                    # Rechercher l'ID du produit par son nom
                    try:
                        search_response = es.search(
                            index="products",
                            body={
                                "query": {
                                    "match_phrase": {
                                        "name": row[product_name_column]
                                    }
                                }
                            }
                        )
                        if search_response['hits']['hits']:
                            product_id = search_response['hits']['hits'][0]['_id']
                    except Exception as e:
                        logger.warning(f"Erreur lors de la recherche du produit {row[product_name_column]}: {str(e)}")
                
                # Récupérer le prix
                price = 0
                if price_column and not pd.isna(row[price_column]):
                    try:
                        price_str = str(row[price_column]).replace('TND', '').replace('€', '').strip()
                        price = float(price_str.replace(',', '.'))
                    except:
                        price = 0
                
                # Récupérer la quantité
                quantity = 1
                if not pd.isna(row[quantity_column]):
                    try:
                        quantity = int(row[quantity_column])
                    except:
                        quantity = 1
                
                # Calculer le sous-total
                item_total = price * quantity
                total_amount += item_total
                
                # Ajouter l'élément à la commande
                order_item = {
                    'product_id': product_id,
                    'product_name': row[product_name_column],
                    'quantity': quantity,
                    'price': price,
                    'total': item_total
                }
                order_items.append(order_item)
            
            # Récupérer la date de commande
            order_date = datetime.datetime.now().isoformat()
            if date_column and not pd.isna(group.iloc[0][date_column]):
                try:
                    date_value = group.iloc[0][date_column]
                    if isinstance(date_value, str):
                        # Essayer différents formats de date
                        for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%m/%d/%Y', '%d-%m-%Y', '%Y/%m/%d']:
                            try:
                                order_date = datetime.datetime.strptime(date_value, fmt).isoformat()
                                break
                            except:
                                continue
                except Exception as e:
                    logger.warning(f"Impossible de parser la date {group.iloc[0][date_column]}: {str(e)}")
            
            # Créer la commande
            order = {
                'order_id': order_id,
                'order_date': order_date,
                'total_amount': total_amount,
                'items': order_items,
                'imported_at': datetime.datetime.now().isoformat()
            }
            orders.append(order)
        
        if not orders:
            return jsonify({'error': 'Aucune commande valide trouvée dans le fichier CSV'}), 400
        
        # Ajouter les commandes à Elasticsearch
        results = []
        for order in orders:
            result = es.index(index="orders", document=order)
            results.append({
                'id': result['_id'],
                'order_id': order['order_id'],
                'status': 'created'
            })
            
            # Mettre à jour les KPIs pour chaque produit dans la commande
            for item in order['items']:
                if not item['product_id']:
                    continue
                
                # Récupérer toutes les commandes pour ce produit
                try:
                    product_orders = es.search(
                        index="orders",
                        body={
                            "query": {
                                "nested": {
                                    "path": "items",
                                    "query": {
                                        "bool": {
                                            "must": [
                                                {"match": {"items.product_id": item['product_id']}}
                                            ]
                                        }
                                    }
                                }
                            }
                        },
                        size=1000
                    )
                    
                    # Extraire les données de commande
                    orders_data = []
                    for hit in product_orders['hits']['hits']:
                        order_data = hit['_source']
                        orders_data.append(order_data)
                    
                    # Analyser les périodes de vente
                    sales_analysis = analyze_orders_by_month(orders_data)
                    
                    # Récupérer les données du produit
                    product = es.get(index="products", id=item['product_id'])
                    product_source = product['_source']
                    
                    # Récupérer l'analyse de marché la plus récente
                    market_analysis = None
                    scraping_results = es.search(
                        index="analyze_results",
                        body={
                            "query": {
                                "term": {"product_id.keyword": item['product_id']}
                            },
                            "sort": [{"timestamp": {"order": "desc"}}],
                            "size": 1
                        }
                    )
                    
                    ideal_price = None
                    scraping_data = None
                    if scraping_results['hits']['hits']:
                        market_analysis = scraping_results['hits']['hits'][0]['_source']
                        ideal_price = market_analysis.get('ideal_price')
                        scraping_data = market_analysis.get('scraping_data')
                    
                    # Calculer l'écart de prix
                    price_diff = None
                    current_price = product_source.get('price', 0)
                    if ideal_price:
                        price_diff = current_price - ideal_price
                    
                    # Générer une recommandation de prix
                    recommendation = generate_price_recommendation(current_price, ideal_price)
                    
                    # Créer ou mettre à jour le KPI
                    timestamp = datetime.datetime.now().isoformat()
                    kpi_doc = {
                        'product_id': item['product_id'],
                        'product_name': product_source.get('name', 'Produit inconnu'),
                        'current_price': current_price,
                        'ideal_price': ideal_price,
                        'price_difference': price_diff,
                        'market_analysis_date': timestamp,
                        'recommendation': recommendation,
                        'sales_analysis': sales_analysis,
                        'updated_at': timestamp
                    }
                    
                    # Sauvegarder le KPI
                    es.index(index="kpis", document=kpi_doc)
                    
                except Exception as e:
                    logger.warning(f"Erreur lors de la mise à jour des KPIs pour le produit {item['product_id']}: {str(e)}")
        
        # Supprimer le fichier temporaire
        os.remove(filepath)
        
        return jsonify({
            'message': f'{len(results)} commandes importées avec succès',
            'orders': results
        }), 201
        
    except Exception as e:
        logger.error(f"Erreur lors de l'importation des commandes: {str(e)}")
        return jsonify({'error': str(e)}), 500

# Endpoint pour obtenir les détails d'analyse d'un produit spécifique
@app.route('/api/kpis/product/<product_id>', methods=['GET'])
@app.route('/api/kpis/product/<product_id>', methods=['GET'])
def get_product_kpis(product_id):
    try:
        # Récupérer le produit
        try:
            product_response = es.search(
                index="products",
                body={
                    "query": {
                        "term": {"_id": product_id}
                    }
                },
                size=1
            )
            
            if product_response['hits']['hits']:
                product = product_response['hits']['hits'][0]['_source']
                product['id'] = product_response['hits']['hits'][0]['_id']
            else:
                return jsonify({"error": "Produit non trouvé"}), 404
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du produit: {str(e)}")
            return jsonify({"error": "Erreur lors de la récupération du produit"}), 500
        
        # Récupérer les KPIs du produit
        try:
            kpi_response = es.search(
                index="kpis",
                body={
                    "query": {
                        "term": {"product_id.keyword": product_id}
                    },
                    "sort": [{"market_analysis_date": {"order": "desc"}}]
                },
                size=1
            )
            
            if kpi_response['hits']['hits']:
                kpi = kpi_response['hits']['hits'][0]['_source']
                kpi['id'] = kpi_response['hits']['hits'][0]['_id']
            else:
                # Générer un KPI basique si aucun n'existe
                kpi = generate_basic_kpi(product_id, product)
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des KPIs: {str(e)}")
            kpi = generate_basic_kpi(product_id, product)
        
        # Récupérer les commandes du produit
        orders_data = get_product_orders(product_id)
        
        # Récupérer les résultats de scraping
        scraping_results = get_product_scraping_results(product_id)
        
        # Construire la réponse complète
        response_data = {
            "product": product,
            "kpi": kpi,
            "orders": orders_data,
            "scraping_results": scraping_results
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des données produit: {str(e)}")
        return jsonify({"error": str(e)}), 500

def generate_basic_kpi(product_id, product):
    """Génère un KPI basique pour un produit qui n'en a pas"""
    current_price = product.get('price', 0)
    scraped_prices = []
    ideal_price = None  # Initialiser à None pour détection plus facile
    
    # Essayer de récupérer des prix scrapés et le prix idéal des résultats de scraping
    try:
        scrape_response = es.search(
            index="product_scraping_results",
            body={
                "query": {
                    "term": {"product_id.keyword": product_id}
                },
                "sort": [{"timestamp": {"order": "desc"}}]
            },
            size=10
        )
        
        if scrape_response['hits']['hits']:
            # Essayer d'abord d'obtenir l'ideal_price du résultat le plus récent
            latest_result = scrape_response['hits']['hits'][0]['_source']
            if 'ideal_price' in latest_result and latest_result['ideal_price'] is not None:
                ideal_price = latest_result['ideal_price']
                logger.info(f"Prix idéal trouvé dans les résultats de scraping: {ideal_price}")
            
            # Collecter les prix scrapés en cas de besoin
            if ideal_price is None:
                for hit in scrape_response['hits']['hits']:
                    source = hit['_source']
                    if 'scraping_data' in source and source['scraping_data']:
                        scraped_prices.extend(extract_prices_from_scraping(source['scraping_data']))
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des prix scrapés: {str(e)}")
    
    # Si aucun prix idéal n'a été trouvé, le calculer à partir des prix scrapés
    if ideal_price is None:
        ideal_price = current_price
        if scraped_prices and len(scraped_prices) > 0:
            # Calculer la moyenne des prix scrapés
            valid_prices = [float(p) for p in scraped_prices if p and not math.isnan(float(p))]
            if valid_prices:
                ideal_price = sum(valid_prices) / len(valid_prices)
                logger.info(f"Prix idéal calculé à partir des prix scrapés: {ideal_price}")
    
    # Calculer la différence de prix
    price_difference = ideal_price - current_price
    
    # Générer une recommandation
    recommendation = ""
    if abs(price_difference) < current_price * 0.05:  # différence de moins de 5%
        recommendation = "Votre prix est très compétitif et proche de l'optimal."
    elif price_difference > 0:
        recommendation = f"Considérez une augmentation de prix de {abs(price_difference):.3f} TND pour optimiser votre marge."
    else:
        recommendation = f"Considérez une réduction de prix de {abs(price_difference):.3f} TND pour être plus compétitif."
    
    return {
        "product_id": product_id,
        "product_name": product.get('name'),
        "current_price": current_price,
        "ideal_price": ideal_price,
        "price_difference": price_difference,
        "market_analysis_date": datetime.datetime.now().isoformat(),
        "recommendation": recommendation,
        "scraped_prices": scraped_prices,
        "is_generated": True  # Indicateur que ce KPI est généré automatiquement
    }

def get_product_orders(product_id):
    """Récupère les commandes d'un produit"""
    try:
        order_response = es.search(
            index="orders",
            body={
                "query": {
                    "nested": {
                        "path": "items",
                        "query": {
                            "term": {"items.product_id": product_id}
                        }
                    }
                }
            },
            size=1000
        )
        
        orders_data = []
        for hit in order_response['hits']['hits']:
            order = hit['_source']
            # Filtrer pour n'inclure que les éléments concernant ce produit
            filtered_items = []
            for item in order.get('items', []):
                if item.get('product_id') == product_id:
                    filtered_items.append(item)
            order['items'] = filtered_items
            orders_data.append(order)
        
        return orders_data
    except:
        return []

def get_product_scraping_results(product_id):
    """Récupère les résultats de scraping d'un produit"""
    try:
        # Récupérer tous les résultats pour ce produit, triés par date (plus récent d'abord)
        scraping_response = es.search(
            index="product_scraping_results",
            body={
                "query": {
                    "term": {"product_id.keyword": product_id}
                },
                "sort": [{"timestamp": {"order": "desc"}}]
            },
            size=10  # Récupérer plusieurs résultats pour chercher des données valides
        )
        
        result_count = len(scraping_response['hits']['hits'])
        logger.info(f"Trouvé {result_count} résultats de scraping pour le produit {product_id}")
        
        if result_count == 0:
            return []
        
        # Parcourir les résultats pour trouver le premier avec des listings non vides
        for hit in scraping_response['hits']['hits']:
            result = hit['_source']
            result['id'] = hit['_id']
            
            # Vérifier si ce résultat contient des données valides
            has_valid_listings = False
            
            if 'scraping_data' in result:
                # Format d'array avec scraping_data[0].listings
                if isinstance(result['scraping_data'], list):
                    for item in result['scraping_data']:
                        if isinstance(item, dict) and 'listings' in item and isinstance(item['listings'], list) and len(item['listings']) > 0:
                            has_valid_listings = True
                            break
                # Format avec listings directement dans scraping_data
                elif isinstance(result['scraping_data'], dict) and 'listings' in result['scraping_data'] and len(result['scraping_data']['listings']) > 0:
                    has_valid_listings = True
            
            # Dès qu'on trouve un résultat avec des listings, on le retourne
            if has_valid_listings:
                logger.info(f"Trouvé un résultat valide avec ID {result['id']}")
                
                # Calculer un prix idéal si nécessaire
                if result.get('ideal_price') is None:
                    prices = extract_all_prices_from_result(result)
                    if prices:
                        result['ideal_price'] = calculate_ideal_price_from_list(prices)
                
                return [result]  # Retourner uniquement ce résultat valide
        
        # Si aucun résultat valide n'est trouvé, retourner le plus récent quand même
        most_recent = scraping_response['hits']['hits'][0]['_source']
        most_recent['id'] = scraping_response['hits']['hits'][0]['_id']
        logger.warning(f"Aucun résultat avec données valides trouvé, retour du plus récent (ID: {most_recent['id']})")
        return [most_recent]
        
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des résultats de scraping: {str(e)}")
        return []

def extract_all_prices_from_result(result):
    """Extrait tous les prix d'un résultat de scraping"""
    prices = []
    
    try:
        if isinstance(result['scraping_data'], list):
            for item in result['scraping_data']:
                if 'listings' in item and isinstance(item['listings'], list):
                    for listing in item['listings']:
                        if 'price' in listing and listing['price']:
                            try:
                                price_str = str(listing['price'])
                                price_str = price_str.replace('TND', '').replace('DT', '').strip()
                                price_str = ''.join(c for c in price_str if c.isdigit() or c in '.,')
                                price_str = price_str.replace(',', '.')
                                price = float(price_str)
                                if price > 0:
                                    prices.append(price)
                            except:
                                pass
    except:
        pass
    
    return prices

def calculate_ideal_price_from_list(prices):
    """Calcule un prix idéal à partir d'une liste de prix"""
    if not prices:
        return None
        
    # Trier les prix
    prices.sort()
    
    # Éliminer les valeurs aberrantes (10% plus bas et 10% plus élevés)
    if len(prices) > 5:
        cutoff_low = int(len(prices) * 0.1)
        cutoff_high = int(len(prices) * 0.9)
        filtered_prices = prices[cutoff_low:cutoff_high]
    else:
        filtered_prices = prices
        
    # Calculer la moyenne et recommander 5% en-dessous
    if filtered_prices:
        avg_price = sum(filtered_prices) / len(filtered_prices)
        return round(avg_price * 0.95, 3)
    else:
        return None

def extract_all_prices_from_result(result):
    """Extrait tous les prix d'un résultat de scraping"""
    prices = []
    
    try:
        if isinstance(result['scraping_data'], list):
            for item in result['scraping_data']:
                if 'listings' in item and isinstance(item['listings'], list):
                    for listing in item['listings']:
                        if 'price' in listing and listing['price']:
                            try:
                                price_str = str(listing['price'])
                                price_str = price_str.replace('TND', '').replace('DT', '').strip()
                                price_str = ''.join(c for c in price_str if c.isdigit() or c in '.,')
                                price_str = price_str.replace(',', '.')
                                price = float(price_str)
                                if price > 0:
                                    prices.append(price)
                            except:
                                pass
    except:
        pass
    
    return prices

def calculate_ideal_price_from_list(prices):
    """Calcule un prix idéal à partir d'une liste de prix"""
    if not prices:
        return None
        
    # Trier les prix
    prices.sort()
    
    # Éliminer les valeurs aberrantes (10% plus bas et 10% plus élevés)
    if len(prices) > 5:
        cutoff_low = int(len(prices) * 0.1)
        cutoff_high = int(len(prices) * 0.9)
        filtered_prices = prices[cutoff_low:cutoff_high]
    else:
        filtered_prices = prices
        
    # Calculer la moyenne et recommander 5% en-dessous
    if filtered_prices:
        avg_price = sum(filtered_prices) / len(filtered_prices)
        return round(avg_price * 0.95, 3)
    else:
        return None
    
    # Endpoint pour récupérer les commandes avec filtres
@app.route('/api/orders', methods=['GET'])
def get_orders():
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
            
        # Récupérer les paramètres de filtre
        date_from = request.args.get('date_from')
        date_to = request.args.get('date_to')
        product_id = request.args.get('product_id')
        
        # Construire la requête
        must_clauses = []
        
        # Filtre par date
        if date_from or date_to:
            date_range = {}
            if date_from:
                date_range["gte"] = date_from
            if date_to:
                date_range["lte"] = date_to
                
            if date_range:
                must_clauses.append({"range": {"order_date": date_range}})
        
        # Filtre par produit - VERSION CORRIGÉE
        if product_id and product_id.strip():
            must_clauses.append({
                "nested": {
                    "path": "items",
                    "query": {
                        "term": {"items.product_id": product_id}
                    },
                    "inner_hits": {}  # Pour retourner les éléments correspondants
                }
            })
        
        # Construire la requête complète
        if must_clauses:
            query = {"bool": {"must": must_clauses}}
        else:
            query = {"match_all": {}}
        
        logger.info(f"Requête orders: {query}")
        
        # Exécuter la recherche
        results = es.search(
            index="orders",
            body={
                "query": query,
                "sort": [{"order_date": {"order": "desc"}}],
                "size": 1000
            }
        )
        
        logger.info(f"Nombre de résultats: {results['hits']['total']['value']}")
        
        # Formater les résultats
        orders = []
        for hit in results['hits']['hits']:
            order = hit['_source']
            order['id'] = hit['_id']
            orders.append(order)
        
        return jsonify(orders)
        
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des commandes: {str(e)}")
        return jsonify({"error": str(e)}), 500
    

def get_product_scraping_results(product_id):
    """Récupère les résultats de scraping d'un produit"""
    try:
        scraping_response = es.search(
            index="product_scraping_results",
            body={
                "query": {
                    "term": {"product_id.keyword": product_id}
                },
                "sort": [{"timestamp": {"order": "desc"}}]
            },
            size=10  # Récupérer plusieurs résultats pour trouver un valide
        )
        
        # Ajouter des logs pour diagnostiquer
        result_count = len(scraping_response['hits']['hits'])
        logger.info(f"Trouvé {result_count} résultats de scraping pour le produit {product_id}")
        
        # S'il n'y a pas de résultats, retourner une liste vide
        if result_count == 0:
            return []
        
        # Parcourir tous les résultats pour trouver le premier avec des données valides
        valid_results = []
        
        for hit in scraping_response['hits']['hits']:
            result = hit['_source']
            result['id'] = hit['_id']
            
            # Vérifier si ce résultat contient des données valides
            has_valid_listings = False
            
            if 'scraping_data' in result:
                # Cas 1: Format array avec scraping_data[0].listings
                if isinstance(result['scraping_data'], list):
                    for item in result['scraping_data']:
                        if isinstance(item, dict) and 'listings' in item and isinstance(item['listings'], list) and len(item['listings']) > 0:
                            has_valid_listings = True
                            break
                # Cas 2: Format direct avec scraping_data.listings
                elif isinstance(result['scraping_data'], dict) and 'listings' in result['scraping_data'] and isinstance(result['scraping_data']['listings'], list) and len(result['scraping_data']['listings']) > 0:
                    has_valid_listings = True
            
            # Si ce résultat a des données valides, l'ajouter à la liste et arrêter la recherche
            if has_valid_listings:
                logger.info(f"Trouvé un résultat valide avec ID {result['id']}")
                
                # Calculer un prix idéal si nécessaire
                if result.get('ideal_price') is None:
                    prices = extract_all_prices_from_result(result)
                    if prices:
                        result['ideal_price'] = calculate_ideal_price_from_list(prices)
                        logger.info(f"Prix idéal calculé: {result['ideal_price']}")
                
                # Retourner uniquement ce résultat valide pour éviter la duplication
                return [result]
        
        # Si aucun résultat valide n'a été trouvé, on prend le plus récent quand même
        most_recent = scraping_response['hits']['hits'][0]['_source']
        most_recent['id'] = scraping_response['hits']['hits'][0]['_id']
        logger.warning(f"Aucun résultat valide trouvé, utilisation du plus récent (ID: {most_recent['id']})")
        return [most_recent]
        
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des résultats de scraping: {str(e)}")
        return []
        

# Endpoint pour obtenir les données pour le graphique
@app.route('/api/kpis/chart/<product_id>', methods=['GET'])
def get_product_chart_data(product_id):
    try:
        if es is None:
            return jsonify({'error': 'Elasticsearch non disponible'}), 503
        
        # Récupérer les commandes pour ce produit
        order_response = es.search(
            index="orders",
            body={
                "query": {
                    "nested": {
                        "path": "items",
                        "query": {
                            "bool": {
                                "must": [
                                    {"match": {"items.product_id": product_id}}
                                ]
                            }
                        }
                    }
                }
            },
            size=1000
        )
        
        # Analyser les données pour le graphique
        monthly_data = [0] * 12  # Un tableau pour chaque mois (0-11 pour janvier-décembre)
        for hit in order_response['hits']['hits']:
            order = hit['_source']
            try:
                order_date = datetime.datetime.fromisoformat(order.get('order_date'))
                month_index = order_date.month - 1  # 0-indexed
                
                # Ajouter les quantités vendues ce mois-là
                for item in order.get('items', []):
                    if item.get('product_id') == product_id:
                        monthly_data[month_index] += item.get('quantity', 0)
            except:
                continue
        
        # Créer les labels pour les mois en français
        month_names = [
            'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
            'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
        ]
        
        # Construire la réponse pour le graphique
        chart_data = {
            'labels': month_names,
            'datasets': [
                {
                    'label': 'Quantité vendue',
                    'data': monthly_data,
                    'backgroundColor': 'rgba(75, 192, 192, 0.2)',
                    'borderColor': 'rgba(75, 192, 192, 1)',
                    'borderWidth': 1
                }
            ]
        }
        
        return jsonify(chart_data), 200
    
    except Exception as e:
        logger.error(f"Erreur lors de la récupération des données de graphique pour le produit {product_id}: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Création des index seulement si Elasticsearch est disponible
    if es is not None:
        try:
            # Index pour les produits
            if not es.indices.exists(index="products"):
                logger.info("Création de l'index 'products'")
                es.indices.create(
                    index="products",
                    body={
                        "mappings": {
                            "properties": {
                                "name": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
                                "price": {"type": "float"},
                                "description": {"type": "text"},
                                "category": {"type": "text", "fields": {"keyword": {"type": "keyword"}}},
                                "stock": {"type": "integer"},
                                "created_at": {"type": "date"},
                                "last_analysis_date": {"type": "date"},
                                "scraping_result_id": {"type": "keyword"},
                                "kpi_id": {"type": "keyword"}
                            }
                        }
                    }
                )
            
            # Index pour les résultats de scraping
            if not es.indices.exists(index="scraping_results"):
                logger.info("Création de l'index 'scraping_results'")
                es.indices.create(
                    index="scraping_results",
                    body={
                        "mappings": {
                            "properties": {
                                "product_id": {"type": "keyword"},
                                "product_name": {"type": "text"},
                                "search_query": {"type": "text"},
                                "timestamp": {"type": "date"},
                                "scraping_data": {"type": "object"},
                                "status": {"type": "keyword"}
                            }
                        }
                    }
                )
            
            # Index pour les KPIs
            if not es.indices.exists(index="kpis"):
                logger.info("Création de l'index 'kpis'")
                es.indices.create(
                    index="kpis",
                    body={
                        "mappings": {
                            "properties": {
                                "product_id": {"type": "keyword"},
                                "product_name": {"type": "text"},
                                "current_price": {"type": "float"},
                                "ideal_price": {"type": "float"},
                                "price_difference": {"type": "float"},
                                "market_analysis_date": {"type": "date"},
                                "scraped_prices": {"type": "float"},
                                "recommendation": {"type": "text"},
                                "sales_analysis": {
                                    "properties": {
                                        "best_period": {"type": "object"},
                                        "monthly_data": {"type": "object"}
                                    }
                                },
                                "updated_at": {"type": "date"}
                            }
                        }
                    }
                )
            
            # Index pour les commandes
            if not es.indices.exists(index="orders"):
                logger.info("Création de l'index 'orders'")
                es.indices.create(
                    index="orders",
                    body={
                        "mappings": {
                            "properties": {
                                "order_id": {"type": "keyword"},
                                "order_date": {"type": "date"},
                                "customer": {
                                    "properties": {
                                        "name": {"type": "text"},
                                        "email": {"type": "keyword"}
                                    }
                                },
                                "items": {
                                    "type": "nested",
                                    "properties": {
                                        "product_id": {"type": "keyword"},
                                        "product_name": {"type": "text"},
                                        "quantity": {"type": "integer"},
                                        "price": {"type": "float"}
                                    }
                                },
                                "total_amount": {"type": "float"},
                                "status": {"type": "keyword"}
                            }
                        }
                    }
                )
            
            # Index pour les analyses détaillées
            if not es.indices.exists(index="analyze_results"):
                logger.info("Création de l'index 'analyze_results'")
                es.indices.create(
                    index="analyze_results",
                    body={
                        "mappings": {
                            "properties": {
                                "product_id": {"type": "keyword"},
                                "search_query": {"type": "text"},
                                "timestamp": {"type": "date"},
                                "scraping_data": {"type": "object"},
                                "ideal_price": {"type": "float"},
                                "status": {"type": "keyword"}
                            }
                        }
                    }
                )
                
            # Index pour les commandes
            if not es.indices.exists(index="orders"):
                logger.info("Création de l'index 'orders'")
                es.indices.create(
                    index="orders",
                    body={
                        "mappings": {
                            "properties": {
                                "order_id": {"type": "keyword"},
                                "order_date": {"type": "date"},
                                "total_amount": {"type": "float"},
                                "items": {
                                    "type": "nested",
                                    "properties": {
                                        "product_id": {"type": "keyword"},
                                        "product_name": {"type": "text"},
                                        "quantity": {"type": "integer"},
                                        "price": {"type": "float"},
                                        "total": {"type": "float"}
                                    }
                                },
                                "imported_at": {"type": "date"}
                            }
                        }
                    }
                )
                
        except Exception as e:
            logger.error(f"Erreur lors de la création des index: {str(e)}")
    
    logger.info("Démarrage du serveur Flask")
    app.run(host='0.0.0.0', port=5000, debug=True)