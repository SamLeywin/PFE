document.addEventListener('DOMContentLoaded', function() {
    const resultsContainer = document.getElementById('resultsContainer');
    const messageDiv = document.getElementById('message');
    const productFilter = document.getElementById('productFilter');
    const statusFilter = document.getElementById('statusFilter');
    const filterResultsBtn = document.getElementById('filterResults');
    const clearFiltersBtn = document.getElementById('clearFilters');
    
    // Charger les données au démarrage
    loadScrapingResults();
    loadProductsForFilter();
    
    // Ajouter les event listeners seulement si les boutons existent
    if (filterResultsBtn) {
        filterResultsBtn.addEventListener('click', applyFilters);
    }
    if (clearFiltersBtn) {
        clearFiltersBtn.addEventListener('click', clearFilters);
    }
    
    function showMessage(text, isError = false) {
        messageDiv.textContent = text;
        messageDiv.className = isError ? 'message error' : 'message success';
        setTimeout(() => {
            messageDiv.textContent = '';
            messageDiv.className = 'message';
        }, 5000);
    }
    
    function loadScrapingResults() {
        showMessage('Chargement des résultats de scraping...');
        
        // Ajouter un timestamp pour éviter la mise en cache
        fetch(`http://localhost:5000/api/scraping-results?_t=${Date.now()}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Erreur ${response.status}`);
                }
                return response.json();
            })
            .then(results => {
                // Grouper les résultats par produit
                const groupedResults = groupResultsByProduct(results);
                displayGroupedResults(groupedResults);
                showMessage(`${Object.keys(groupedResults).length} produits chargés`);
            })
            .catch(error => {
                console.error('Erreur:', error);
                showMessage(`Erreur: ${error.message}`, true);
                resultsContainer.innerHTML = '<p>Erreur lors du chargement des résultats</p>';
            });
    }
    
    function groupResultsByProduct(results) {
        const groupedResults = {};
        
        results.forEach(result => {
            const productId = result.product_id;
            if (!productId) return;
            
            if (!groupedResults[productId]) {
                groupedResults[productId] = {
                    productId: productId,
                    productName: result.product_name || 'Produit sans nom',
                    results: [],
                    allListings: [],
                    latestTimestamp: null,
                    latestStatus: 'completed',
                    searchQuery: result.search_query || result.product_name || ''
                };
            }
            
            // Ajouter le résultat au groupe
            groupedResults[productId].results.push(result);
            
            // Mettre à jour le timestamp le plus récent
            const timestamp = new Date(result.timestamp);
            if (!groupedResults[productId].latestTimestamp || 
                timestamp > new Date(groupedResults[productId].latestTimestamp)) {
                groupedResults[productId].latestTimestamp = result.timestamp;
                groupedResults[productId].latestStatus = result.status || 'completed';
            }
            
            // Collecter tous les listings
            const listings = extractListingsFromResult(result);
            if (listings.length > 0) {
                groupedResults[productId].allListings = groupedResults[productId].allListings.concat(listings);
            }
        });
        
        return groupedResults;
    }
    
    function extractListingsFromResult(result) {
        const scrapingData = result.scraping_data;
        let listings = [];
        
        if (!scrapingData) return listings;
        
        // Format array avec scraping_data[0].listings
        if (Array.isArray(scrapingData)) {
            for (const item of scrapingData) {
                if (item && item.listings && Array.isArray(item.listings)) {
                    listings = listings.concat(item.listings);
                }
            }
        }
        // Format avec listings directement dans scraping_data
        else if (scrapingData.listings && Array.isArray(scrapingData.listings)) {
            listings = scrapingData.listings;
        }
        
        return listings;
    }
    
    function displayGroupedResults(groupedResults) {
        resultsContainer.innerHTML = '';
        
        if (Object.keys(groupedResults).length === 0) {
            resultsContainer.innerHTML = '<p>Aucun résultat de scraping trouvé</p>';
            return;
        }
        
        // Pour chaque produit, créer une carte
        Object.values(groupedResults).forEach(productGroup => {
            // Ignorer les produits sans listings
            if (productGroup.allListings.length === 0) return;
            
            const resultCard = document.createElement('div');
            resultCard.className = 'result-card';
            
            const statusClass = getStatusClass(productGroup.latestStatus);
            const formattedDate = new Date(productGroup.latestTimestamp).toLocaleString('fr-FR');
            
            // En-tête du résultat
            let cardHtml = `
                <div class="result-header">
                    <div>
                        <div class="result-title">${productGroup.productName}</div>
                        <div class="result-date">Analysé le ${formattedDate}</div>
                    </div>
                    <span class="status-badge ${statusClass}">${productGroup.latestStatus}</span>
                </div>
                
                <div class="result-details">
                    <p><strong>Requête de recherche:</strong> ${productGroup.searchQuery}</p>
                    <p><strong>ID du produit:</strong> ${productGroup.productId}</p>
                `;
            
            cardHtml += `<h4 style="margin-top: 15px; margin-bottom: 10px;">Données de scraping:</h4>`;
            cardHtml += createCombinedScrapingTable(productGroup);
            
            cardHtml += `</div>`;
            
            resultCard.innerHTML = cardHtml;
            resultsContainer.appendChild(resultCard);
        });
    }
    
    function createCombinedScrapingTable(productGroup) {
    const listings = productGroup.allListings;
    
    if (listings.length === 0) {
        return '<p>Aucune donnée de scraping valide trouvée</p>';
    }
    
    // Extraire les sites (compétiteurs)
    const siteSources = extractSiteSources(listings);
    
    // Extraire et traiter les prix
    const allPrices = listings
        .filter(item => item.price)
        .map(item => extractNumericPrice(item.price))
        .filter(price => !isNaN(price) && price > 0);
    
    if (allPrices.length === 0) {
        return '<p>Aucun prix valide trouvé dans les résultats de scraping</p>';
    }
    
    // Calculer les statistiques de prix
    const avgPrice = allPrices.reduce((sum, price) => sum + price, 0) / allPrices.length;
    const minPrice = Math.min(...allPrices);
    const maxPrice = Math.max(...allPrices);
    
    // Utiliser le prix idéal stocké dans le résultat du backend si disponible
    // Sinon, calculer comme avant (95% du prix moyen)
    let idealPrice;
    
    // Chercher le prix idéal dans les résultats
    if (productGroup.results && productGroup.results.length > 0) {
        // Trier les résultats par date (plus récent d'abord)
        const sortedResults = [...productGroup.results].sort(
            (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
        );
        
        // Chercher le premier résultat avec un prix idéal
        const resultWithIdeal = sortedResults.find(result => 
            result.ideal_price !== null && result.ideal_price !== undefined
        );
        
        // Si on trouve un prix idéal, l'utiliser
        if (resultWithIdeal && resultWithIdeal.ideal_price) {
            idealPrice = resultWithIdeal.ideal_price;
        } else {
            // Calcul client comme fallback
            idealPrice = avgPrice * 0.95;
        }
    } else {
        // Calcul client si pas de résultats
        idealPrice = avgPrice * 0.95;
    }
    
    // Générer le HTML avec les sites
    let tablesHtml = `
        <div class="competitors-section">
            <h5>Compétiteur${siteSources.length > 1 ? 's' : ''}</h5>
            <div class="competitors-list">
                ${siteSources.map(site => `<span class="competitor-badge">${site}</span>`).join('')}
            </div>
        </div>
        
        <div class="price-summary">
            <h5>Résumé des prix</h5>
            <table class="scraping-table">
                <tr>
                    <th>Prix minimum</th>
                    <th>Prix moyen</th>
                    <th>Prix maximum</th>
                    <th>Prix idéal recommandé</th>
                </tr>
                <tr>
                    <td>${formatPrice(minPrice)}</td>
                    <td>${formatPrice(avgPrice)}</td>
                    <td>${formatPrice(maxPrice)}</td>
                    <td><strong>${formatPrice(idealPrice)}</strong></td>
                </tr>
            </table>
        </div>`;
        
        // Créer le tableau des produits trouvés
        const columns = getCommonColumns(listings);
        
        tablesHtml += `
            <div class="listings-table">
                <h5>Produits trouvés (${listings.length})</h5>
                <div class="table-responsive">
                    <table class="scraping-table">
                        <thead>
                            <tr>
                                ${columns.map(col => `<th>${formatColumnName(col)}</th>`).join('')}
                            </tr>
                        </thead>
                        <tbody>
                            ${listings.map(listing => `
                                <tr>
                                    ${columns.map(col => `
                                        <td>${formatCellValue(listing[col])}</td>
                                    `).join('')}
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>`;
            
        return tablesHtml;
    }
    
    function extractSiteSources(listings) {
        const siteSources = [];
        
        listings.forEach(listing => {
            if (listing.site && !siteSources.includes(listing.site)) {
                siteSources.push(listing.site);
            }
            if (listing.source && !siteSources.includes(listing.source)) {
                siteSources.push(listing.source);
            }
            if (listing.url) {
                const extractedSite = extractSiteName(listing.url);
                if (extractedSite && !siteSources.includes(extractedSite)) {
                    siteSources.push(extractedSite);
                }
            }
        });
        
        // Si aucun site trouvé, utiliser des valeurs par défaut
        if (siteSources.length === 0) {
            return ['Yousarssif', 'Vongo', 'TDiscount'];
        }
        
        return siteSources;
    }

    function loadProductsForFilter() {
        fetch('http://localhost:5000/api/products')
            .then(response => response.json())
            .then(products => {
                productFilter.innerHTML = '<option value="">Tous les produits</option>';
                products.forEach(product => {
                    const option = document.createElement('option');
                    option.value = product.id;
                    option.textContent = product.name;
                    productFilter.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Erreur lors du chargement des produits:', error);
            });
    }
    
    // Fonction auxiliaire pour extraire le nom du site à partir d'une URL
    function extractSiteName(url) {
        try {
            if (!url.startsWith('http')) {
                return null;
            }
            
            const hostname = new URL(url).hostname;
            const domain = hostname.replace(/^www\./i, '').split('.')[0];
            return domain.charAt(0).toUpperCase() + domain.slice(1);
        } catch (e) {
            return null;
        }
    }

    function formatPrice(price) {
        if (price === null || price === undefined || isNaN(price)) {
            return '-';
        }
        return price.toFixed(3) + ' TND';
    }
    
    // Fonction pour extraire un prix numérique à partir d'une chaîne
    function extractNumericPrice(priceStr) {
        if (!priceStr) return NaN;
        
        // Convertir en chaîne si ce n'est pas déjà le cas
        let price = String(priceStr);
        
        // Supprimer les symboles de devise et autres caractères non numériques
        price = price.replace(/TND|DT|€|\$|dinars?|dt/gi, '')
                    .replace(/\s+/g, '')
                    .replace(/\./g, 'X')  // Remplacer temporairement le point pour gérer les nombres décimaux
                    .replace(/,/g, '.')   // Remplacer la virgule par un point
                    .replace(/X/g, ',');  // Remettre les points d'origine en virgules
        
        // Convertir en nombre à virgule flottante
        return parseFloat(price);
    }
    
    // Fonction pour obtenir les colonnes communes à un ensemble de listings
    function getCommonColumns(listings) {
        // Collecter toutes les clés possibles
        const allKeys = new Set();
        listings.forEach(item => {
            Object.keys(item).forEach(key => allKeys.add(key));
        });
        
        // Ordonner les colonnes avec les plus importantes en premier
        const orderedColumns = ['title', 'price', 'description', 'rating', 'seller', 'url', 'image'];
        
        // Construire la liste finale de colonnes
        const finalColumns = [];
        
        // D'abord ajouter les colonnes importantes dans l'ordre
        orderedColumns.forEach(col => {
            if (allKeys.has(col)) {
                finalColumns.push(col);
                allKeys.delete(col);
            }
        });
        
        // Ensuite ajouter le reste des colonnes
        allKeys.forEach(col => finalColumns.push(col));
        
        return finalColumns;
    }
    
    // Formater le nom de la colonne (titre, prix, note, etc.)
    function formatColumnName(columnName) {
        // Traduction des colonnes communes
        const translations = {
            'title': 'Titre',
            'price': 'Prix',
            'rating': 'Note',
            'description': 'Description',
            'url': 'Lien',
            'seller': 'Vendeur',
            'image': 'Image'
        };
        
        if (translations[columnName]) {
            return translations[columnName];
        }
        
        // Première lettre en majuscule et supprimer les underscores
        return columnName.charAt(0).toUpperCase() + 
               columnName.slice(1).replace(/_/g, ' ');
    }
    
    // Formater la valeur d'une cellule du tableau
    function formatCellValue(value) {
        if (value === null || value === undefined) return '-';
        if (typeof value === 'object') {
            try {
                return JSON.stringify(value);
            } catch (e) {
                return '[Objet complexe]';
            }
        }
        if (typeof value === 'boolean') return value ? 'Oui' : 'Non';
        return String(value);
    }
    
    function getStatusClass(status) {
        switch (status) {
            case 'completed': return 'status-completed';
            case 'error': return 'status-error';
            case 'pending': return 'status-pending';
            default: return 'status-completed';
        }
    }
    
    function applyFilters() {
        const filters = {
            product_id: productFilter.value,
            status: statusFilter.value
        };
        
        let url = 'http://localhost:5000/api/scraping-results?';
        const params = [];
        
        Object.keys(filters).forEach(key => {
            if (filters[key]) {
                params.push(`${key}=${encodeURIComponent(filters[key])}`);
            }
        });
        
        url += params.join('&');
        
        showMessage('Application des filtres...');
        
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Erreur ${response.status}`);
                }
                return response.json();
            })
            .then(results => {
                // Grouper les résultats par produit
                const groupedResults = groupResultsByProduct(results);
                displayGroupedResults(groupedResults);
                showMessage(`${Object.keys(groupedResults).length} produits correspondent aux filtres`);
            })
            .catch(error => {
                console.error('Erreur:', error);
                showMessage(`Erreur: ${error.message}`, true);
            });
    }
    
    function clearFilters() {
        productFilter.value = '';
        statusFilter.value = '';
        loadScrapingResults();
    }
    
    // Fonctions globales pour les boutons dans le HTML
    window.viewDetails = function(resultId) {
        // Ouvrir une modal ou une nouvelle page avec les détails complets
        fetch(`http://localhost:5000/api/scraping-results?id=${resultId}`)
            .then(response => response.json())
            .then(data => {
                alert(`Détails complets disponibles dans la console du navigateur`);
                console.log("Détails du résultat de scraping:", data);
            })
            .catch(error => {
                console.error('Erreur:', error);
                showMessage(`Erreur: ${error.message}`, true);
            });
    };
    
    window.exportResult = function(resultId) {
        // Exporter le résultat en JSON ou CSV
        fetch(`http://localhost:5000/api/scraping-results?id=${resultId}`)
            .then(response => response.json())
            .then(data => {
                const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `scraping-result-${resultId}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                showMessage('Résultat exporté avec succès');
            })
            .catch(error => {
                console.error('Erreur lors de l\'export:', error);
                showMessage('Erreur lors de l\'export', true);
            });
    };
});