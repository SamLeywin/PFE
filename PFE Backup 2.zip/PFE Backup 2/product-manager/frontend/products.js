// Fonctions dans le scope global pour être accessibles depuis les attributs onclick
function formatPrice(price) {
    if (price === null || price === undefined) return '-';
    return parseFloat(price).toFixed(3) + ' TND';
}

function showMessage(text, isError = false) {
    const messageDiv = document.getElementById('message');
    messageDiv.textContent = text;
    messageDiv.className = isError ? 'message error' : 'message success';
    setTimeout(() => {
        messageDiv.textContent = '';
        messageDiv.className = 'message';
    }, 5000);
}

function analyzeProduct(productId, productName) {
    console.log('Analyse du produit:', productName, 'ID:', productId);
    showMessage(`Analyse du produit "${productName}" en cours...`);
    
    if (!productId) {
        showMessage("Erreur: ID du produit manquant", true);
        return;
    }
    
    const url = 'http://localhost:8000/scrape';
    
    const data = {
        urls: [
            "https://www.yousarssif.com",
            "https://vongo.tn",
            "https://tdiscount.tn"
        ],
        fields: ["title", "price", "rating"],
        model_selection: "llama-3.3-70b-versatile",
        use_pagination: true,
        max_pages: 3,
        product_id: productId
    };

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`HTTP error! Status: ${response.status}, Details: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        console.log('Scraping results:', data);
        showMessage(`Analyse terminée pour "${productName}"`);
        // Add a delay before refreshing to give Elasticsearch time to index
        setTimeout(() => fetchProducts(), 2000);
    })
    .catch(error => {
        console.error('Error:', error);
        showMessage(`Erreur lors de l'analyse: ${error.message}`, true);
    });
}

function editProduct(productId) {
    console.log('Édition du produit:', productId);
    showMessage('La fonctionnalité d\'édition sera bientôt disponible');
}

function deleteProduct(id) {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce produit?')) {
        return;
    }
    
    fetch(`http://localhost:5000/api/products/${id}`, {
        method: 'DELETE'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erreur ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        showMessage('Produit supprimé avec succès');
        fetchProducts();
    })
    .catch(error => {
        console.error('Erreur:', error);
        showMessage(`Erreur: ${error.message}`, true);
    });
}

// Fonctions internes au chargement du document
let fetchProducts; // Declared here so it can be used in the global functions

document.addEventListener('DOMContentLoaded', function() {
    const productsList = document.getElementById('productsList');
    const messageDiv = document.getElementById('message');
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const categoryFilter = document.getElementById('categoryFilter');
    const minPriceInput = document.getElementById('minPrice');
    const maxPriceInput = document.getElementById('maxPrice');
    const filterBtn = document.getElementById('filterBtn');

    // Définition de la fonction fetchProducts dans le scope global
    fetchProducts = function() {
        showMessage('Chargement des produits...');
        
        fetch('http://localhost:5000/api/products')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Erreur ${response.status}`);
                }
                return response.json();
            })
            .then(products => {
                displayProducts(products);
                showMessage(`${products.length} produits chargés`);
            })
            .catch(error => {
                console.error('Erreur:', error);
                showMessage(`Erreur: ${error.message}`, true);
            });
    };
    
    // Charger les produits et catégories au démarrage
    fetchProducts();
    fetchCategories();
    
    searchBtn.addEventListener('click', () => {
        const query = searchInput.value.trim();
        if (query) {
            searchProducts(query);
        } else {
            fetchProducts();
        }
    });
    
    filterBtn.addEventListener('click', applyFilters);
    
    function fetchCategories() {
        fetch('http://localhost:5000/api/categories')
            .then(response => {
                if (!response.ok) {
                    return [];
                }
                return response.json();
            })
            .then(categories => {
                populateCategoryFilter(categories);
            })
            .catch(error => {
                console.error('Erreur lors du chargement des catégories:', error);
            });
    }
    
    function populateCategoryFilter(categories) {
        categoryFilter.innerHTML = '<option value="">Toutes les catégories</option>';
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categoryFilter.appendChild(option);
        });
    }
    
    function searchProducts(query) {
        showMessage(`Recherche de "${query}"...`);
        
        // Add a timestamp parameter to prevent caching
        fetch(`http://localhost:5000/api/products/search?q=${encodeURIComponent(query)}&_t=${Date.now()}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Erreur ${response.status}`);
                }
                return response.json();
            })
            .then(products => {
                displayProducts(products);
                showMessage(`${products.length} produits trouvés`);
            })
            .catch(error => {
                console.error('Erreur:', error);
                showMessage(`Erreur: ${error.message}`, true);
            });
    }
    
    function applyFilters() {
        const category = categoryFilter.value;
        const minPrice = minPriceInput.value;
        const maxPrice = maxPriceInput.value;
        
        let url = 'http://localhost:5000/api/products/search?';
        let params = [];
        
        if (category) params.push(`category=${encodeURIComponent(category)}`);
        if (minPrice) params.push(`min_price=${minPrice}`);
        if (maxPrice) params.push(`max_price=${maxPrice}`);
        
        url += params.join('&');
        
        showMessage('Application des filtres...');
        
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Erreur ${response.status}`);
                }
                return response.json();
            })
            .then(products => {
                displayProducts(products);
                showMessage(`${products.length} produits correspondent aux filtres`);
            })
            .catch(error => {
                console.error('Erreur:', error);
                showMessage(`Erreur: ${error.message}`, true);
            });
    }
    
    function displayProducts(products) {
        productsList.innerHTML = '';
        
        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            
            // Store the product ID as a data attribute for easier access
            productCard.dataset.productId = product.id;
            
            // Ajouter la date d'analyse et le prix idéal s'ils existent
            const lastAnalysisDate = product.last_analysis_date ? 
                new Date(product.last_analysis_date).toLocaleDateString('fr-FR') : 'Jamais';
            
            // Formater le prix actuel et le prix idéal
            const currentPrice = formatPrice(product.price);
            const idealPrice = product.ideal_price ? formatPrice(product.ideal_price) : '-';
                
            productCard.innerHTML = `
                <h3>${product.name}</h3>
                <div class="product-info">
                    <p><strong>Prix actuel:</strong> ${currentPrice}</p>
                    <p><strong>Catégorie:</strong> ${product.category || '-'}</p>
                    <p><strong>Dernière analyse:</strong> ${lastAnalysisDate}</p>
                    <p><strong>Prix idéal:</strong> <span class="ideal-price">${idealPrice}</span></p>
                </div>
                <div class="product-actions">
                    <button onclick="editProduct('${product.id}')" class="edit-btn">Modifier</button>
                    <button onclick="analyzeProduct('${product.id}', '${product.name}')" class="analyze-btn">Analyser</button>
                    <button onclick="deleteProduct('${product.id}')" class="delete-btn">Supprimer</button>
                </div>
            `;
            
            // Ajouter une classe pour mettre en évidence si le prix actuel est différent du prix idéal
            if (product.ideal_price && Math.abs(product.price - product.ideal_price) > 1) {
                const priceComparison = document.createElement('div');
                
                if (product.price > product.ideal_price * 1.05) {
                    priceComparison.className = 'price-recommendation above';
                    priceComparison.textContent = `Prix supérieur de ${formatPrice(product.price - product.ideal_price)} au prix idéal`;
                } else if (product.price < product.ideal_price * 0.95) {
                    priceComparison.className = 'price-recommendation below';
                    priceComparison.textContent = `Prix inférieur de ${formatPrice(product.ideal_price - product.price)} au prix idéal`;
                } else {
                    priceComparison.className = 'price-recommendation optimal';
                    priceComparison.textContent = 'Prix optimal pour le marché';
                }
                
                productCard.querySelector('.product-info').appendChild(priceComparison);
            }
            
            productsList.appendChild(productCard);
        });
    }
});