document.addEventListener('DOMContentLoaded', function() {
    const signupForm = document.getElementById('signupForm');
    const messageDiv = document.getElementById('message');
    
    signupForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        
        // Validation
        if (!name || !email || !password || !confirmPassword) {
            showMessage('Veuillez remplir tous les champs', true);
            return;
        }
        
        if (password !== confirmPassword) {
            showMessage('Les mots de passe ne correspondent pas', true);
            return;
        }
        
        if (password.length < 6) {
            showMessage('Le mot de passe doit contenir au moins 6 caractères', true);
            return;
        }
        
        // Appel API pour l'inscription
        fetch('http://localhost:5000/api/auth/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: name,
                email: email,
                password: password
            })
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || "Erreur lors de l'inscription");
                });
            }
            return response.json();
        })
        .then(data => {
            showMessage('Compte créé avec succès ! Redirection vers la page de connexion...', false);
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        })
        .catch(error => {
            console.error('Erreur:', error);
            showMessage(error.message || "Erreur lors de l'inscription", true);
        });
    });
    
    function showMessage(text, isError = false) {
        if (!messageDiv) return;
        
        messageDiv.textContent = text;
        messageDiv.className = isError ? 'message error' : 'message success';
    }
});