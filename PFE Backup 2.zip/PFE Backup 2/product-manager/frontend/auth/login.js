document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const messageDiv = document.getElementById('message');
    
    // Vérifier si l'utilisateur est déjà connecté
    const token = localStorage.getItem('authToken');
    if (token) {
        // Redirection vers le dashboard
        window.location.href = '../dashboard/home.html';
        return;
    }
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        // Validation de base
        if (!email || !password) {
            showMessage('Veuillez remplir tous les champs', true);
            return;
        }
        
        // Appel API pour la connexion
        fetch('http://localhost:5000/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || 'Erreur de connexion');
                });
            }
            return response.json();
        })
        .then(data => {
            // Stocker le token et les infos utilisateur
            localStorage.setItem('authToken', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            
            // Redirection
            showMessage('Connexion réussie ! Redirection...', false);
            setTimeout(() => {
                window.location.href = '../dashboard/home.html';
            }, 1000);
        })
        .catch(error => {
            console.error('Erreur:', error);
            showMessage(error.message || 'Erreur de connexion', true);
        });
    });
    
    function showMessage(text, isError = false) {
        if (!messageDiv) return;
        
        messageDiv.textContent = text;
        messageDiv.className = isError ? 'message error' : 'message success';
    }
});