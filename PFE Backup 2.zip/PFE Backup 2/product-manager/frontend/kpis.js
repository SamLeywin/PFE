document.addEventListener('DOMContentLoaded', function() {
    // Éléments du tableau KPIs
    const kpiTableBody = document.getElementById('kpiTableBody');
    const messageDiv = document.getElementById('message');
    const productKpiFilter = document.getElementById('productKpiFilter');
    const sortBy = document.getElementById('sortBy');
    const refreshBtn = document.getElementById('refreshKpis');
    const exportBtn = document.getElementById('exportKpis');
    
    // Éléments de l'analyse détaillée
    const productSelect = document.getElementById('productSelect');
    const analyzeProductBtn = document.getElementById('analyzeProductBtn');
    const productAnalysisSection = document.getElementById('productAnalysisSection');
    const productTitle = document.getElementById('productTitle');
    const currentPrice = document.getElementById('currentPrice');
    const idealPrice = document.getElementById('idealPrice');
    const priceDifference = document.getElementById('priceDifference');
    const lastAnalysisDate = document.getElementById('lastAnalysisDate');
    const bestPeriodContainer = document.getElementById('bestPeriodContainer');
    const bestPeriodText = document.getElementById('bestPeriodText');
    const priceRecommendation = document.getElementById('priceRecommendation');
    
    // Éléments pour les onglets et graphiques
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    // Variables globales pour les données
    let allKpis = [];
    let salesChart = null;
    let priceChart = null;
    
    // Vérifier que Chart.js est bien chargé
    const isChartJsLoaded = typeof Chart !== 'undefined';
    if (!isChartJsLoaded) {
        console.error("Chart.js n'est pas correctement chargé");
    }
    
    // Initialisation des onglets
    tabButtons.forEach(button => {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Activer le bouton
            tabButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Afficher le contenu
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === tabId) {
                    content.classList.add('active');
                }
            });
        });
    });
    
    // Fonction pour formater les prix avec TND
    function formatPrice(price) {
        if (price === null || price === undefined || isNaN(parseFloat(price))) return '-';
        return parseFloat(price).toFixed(3) + ' TND';
    }
    
    // Fonction pour extraire un prix numérique à partir d'une chaîne
    // Identique à celle dans scraping-results.js pour assurer la cohérence
    function extractNumericPrice(priceStr) {
        if (!priceStr) return NaN;
        
        // Convertir en chaîne si ce n'est pas déjà le cas
        let price = String(priceStr);
        
        // Supprimer les symboles de devise et autres caractères non numériques
        price = price.replace(/TND|DT|€|\$|dinars?|dt/gi, '')
                    .replace(/\s+/g, '')
                    .replace(/\./g, 'X')  // Remplacer temporairement le point pour gérer les nombres décimaux
                    .replace(/,/g, '.')   // Remplacer la virgule par un point
                    .replace(/X/g, ',');  // Remettre les points d'origine en virgules
        
        // Convertir en nombre à virgule flottante
        return parseFloat(price);
    }
    
    // Charger les données au démarrage
    loadKpis();
    loadProductsForFilter();
    loadProductsForSelect();
    
    // Event listeners
    if (refreshBtn) refreshBtn.addEventListener('click', loadKpis);
    if (exportBtn) exportBtn.addEventListener('click', exportKpis);
    if (productKpiFilter) productKpiFilter.addEventListener('change', applyFilters);
    if (sortBy) sortBy.addEventListener('change', applyFilters);
    
    if (analyzeProductBtn) {
        analyzeProductBtn.addEventListener('click', function() {
            if (productSelect.value) {
                loadProductDetails(productSelect.value);
            } else {
                showMessage('Veuillez sélectionner un produit', true);
            }
        });
    }
    
    function showMessage(text, isError = false) {
        if (!messageDiv) return;
        
        messageDiv.textContent = text;
        messageDiv.className = isError ? 'message error' : 'message success';
        setTimeout(() => {
            messageDiv.textContent = '';
            messageDiv.className = 'message';
        }, 5000);
    }
    
    function loadKpis() {
        showMessage('Chargement des KPIs...');
        
        fetch('http://localhost:5000/api/kpis')
            .then(response => {
                console.log('Réponse API KPIs:', response.status);
                if (!response.ok) {
                    throw new Error(`Erreur ${response.status}`);
                }
                return response.json();
            })
            .then(kpis => {
                console.log('KPIs reçus:', kpis);
                allKpis = kpis || [];
                displayKpis(allKpis);
                updateDashboard(allKpis);
                showMessage(`${allKpis.length} KPIs chargés`);
            })
            .catch(error => {
                console.error('Erreur:', error);
                showMessage(`Erreur: ${error.message}`, true);
                if (kpiTableBody) {
                    kpiTableBody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Erreur lors du chargement des KPIs</td></tr>';
                }
            });
    }
    
    function loadProductsForFilter() {
        if (!productKpiFilter) return;
        
        fetch('http://localhost:5000/api/products')
            .then(response => response.json())
            .then(products => {
                productKpiFilter.innerHTML = '<option value="">Tous les produits</option>';
                products.forEach(product => {
                    const option = document.createElement('option');
                    option.value = product.id;
                    option.textContent = product.name;
                    productKpiFilter.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Erreur lors du chargement des produits:', error);
            });
    }
    
    function loadProductsForSelect() {
        if (!productSelect) return;
        
        fetch('http://localhost:5000/api/products')
            .then(response => response.json())
            .then(products => {
                productSelect.innerHTML = '<option value="">-- Sélectionnez un produit --</option>';
                products.forEach(product => {
                    const option = document.createElement('option');
                    option.value = product.id;
                    option.textContent = product.name;
                    productSelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Erreur lors du chargement des produits:', error);
            });
    }
    
    function loadProductDetails(productId) {
        showMessage('Chargement des détails du produit...');
        
        fetch(`http://localhost:5000/api/kpis/product/${productId}`)
            .then(response => {
                console.log('Réponse API détails produit:', response.status);
                if (!response.ok) {
                    if (response.status === 404) {
                        throw new Error('Aucun KPI trouvé pour ce produit');
                    }
                    throw new Error(`Erreur ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Détails produit reçus:', data);
                
                // Vérifier si les données necessaires sont présentes
                if (!data || (!data.product && !data.kpi)) {
                    throw new Error('Données produit incomplètes ou manquantes');
                }
                
                displayProductDetails(data);
                loadSalesChartData(productId);
                showMessage('Détails du produit chargés');
                if (productAnalysisSection) {
                    productAnalysisSection.style.display = 'block';
                }
            })
            .catch(error => {
                console.error('Erreur:', error);
                showMessage(`Erreur: ${error.message}`, true);
                if (error.message === 'Aucun KPI trouvé pour ce produit') {
                    initializeMissingKpi(productId);
                }
            });
    }
    
    function initializeMissingKpi(productId) {
        fetch(`http://localhost:5000/api/products?id=${productId}`)
            .then(response => response.json())
            .then(products => {
                if (products.length > 0) {
                    const product = products[0];
                    displayBasicProductDetails(product);
                    loadSalesChartData(productId);
                    if (productAnalysisSection) {
                        productAnalysisSection.style.display = 'block';
                    }
                    showMessage('Ce produit n\'a pas encore été analysé.');
                }
            })
            .catch(error => {
                console.error('Erreur lors du chargement du produit:', error);
                showMessage(`Erreur: ${error.message}`, true);
            });
    }
    
    function displayBasicProductDetails(product) {
        if (productTitle) productTitle.textContent = `Analyse: ${product.name || 'Produit inconnu'}`;
        if (currentPrice) currentPrice.textContent = formatPrice(product.price);
        if (idealPrice) idealPrice.textContent = '-';
        if (priceDifference) priceDifference.textContent = '-';
        if (lastAnalysisDate) {
            lastAnalysisDate.textContent = product.last_analysis_date ? 
                new Date(product.last_analysis_date).toLocaleDateString('fr-FR') : 'Jamais analysé';
        }
        
        if (bestPeriodText) bestPeriodText.textContent = 'Aucune donnée de vente disponible pour ce produit.';
        if (priceRecommendation) {
            priceRecommendation.textContent = 'Aucune recommandation disponible.';
            priceRecommendation.className = 'price-recommendation';
        }
    }
    
    function displayProductDetails(data) {
    const product = data.product || {};
    const kpi = data.kpi || {};
    const scrapingResults = data.scraping_results || [];
    
    // Mettre à jour les détails du produit
    if (productTitle) productTitle.textContent = `Analyse: ${product.name || 'Produit inconnu'}`;
    
    // Prix actuel
    if (currentPrice) {
        currentPrice.textContent = formatPrice(product.price);
    }
    
    // Chercher un prix idéal valide
    let idealPriceValue = null;
    
    // Prendre UNIQUEMENT le prix idéal du résultat de scraping le plus récent
    if (scrapingResults.length > 0) {
        // Trier les résultats par date (plus récent d'abord)
        const sortedResults = [...scrapingResults].sort(
            (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
        );
        
        // Utiliser le premier résultat qui a un prix idéal
        const resultWithIdeal = sortedResults.find(result => 
            result.ideal_price !== null && result.ideal_price !== undefined
        );
        
        if (resultWithIdeal && resultWithIdeal.ideal_price) {
            idealPriceValue = resultWithIdeal.ideal_price;
            console.log(`Prix idéal trouvé dans le scraping: ${idealPriceValue}`);
        }
    }
    
    // Si pas trouvé dans les résultats de scraping, utiliser celui du KPI
    if (idealPriceValue === null && kpi.ideal_price) {
        idealPriceValue = kpi.ideal_price;
        console.log(`Prix idéal trouvé dans le KPI: ${idealPriceValue}`);
    }
    
    // Si toujours pas trouvé, alors seulement recalculer
    if (idealPriceValue === null) {
        // Extraire les prix de tous les listings dans les résultats de scraping
        const allPrices = [];
        scrapingResults.forEach(result => {
            if (result.scraping_data) {
                // Format array avec scraping_data[0].listings
                if (Array.isArray(result.scraping_data)) {
                    for (const item of result.scraping_data) {
                        if (item && item.listings && Array.isArray(item.listings)) {
                            item.listings.forEach(listing => {
                                if (listing.price) {
                                    const price = extractNumericPrice(listing.price);
                                    if (!isNaN(price) && price > 0) {
                                        allPrices.push(price);
                                    }
                                }
                            });
                        }
                    }
                }
                // Format avec listings directement dans scraping_data
                else if (result.scraping_data.listings && Array.isArray(result.scraping_data.listings)) {
                    result.scraping_data.listings.forEach(listing => {
                        if (listing.price) {
                            const price = extractNumericPrice(listing.price);
                            if (!isNaN(price) && price > 0) {
                                allPrices.push(price);
                            }
                        }
                    });
                }
            }
        });
        
        // SECTION MODIFIÉE: Calculer le prix idéal avec filtrage des valeurs aberrantes
        if (allPrices.length > 0) {
            // Trier les prix
            allPrices.sort((a, b) => a - b);
            
            // Filtrer les valeurs aberrantes (10% plus bas et 10% plus élevés)
            let filteredPrices;
            if (allPrices.length > 5) {
                const cutoffLow = Math.floor(allPrices.length * 0.1);
                const cutoffHigh = Math.ceil(allPrices.length * 0.9);
                filteredPrices = allPrices.slice(cutoffLow, cutoffHigh);
            } else {
                filteredPrices = allPrices;
            }
            
            // Calculer la moyenne des prix filtrés
            const avgFilteredPrice = filteredPrices.reduce((sum, price) => sum + price, 0) / filteredPrices.length;
            idealPriceValue = avgFilteredPrice * 0.95;
        } else {
            // En dernier recours, utiliser le prix actuel
            idealPriceValue = product.price;
        }
    }

    // Afficher le prix idéal
     if (idealPrice) {
        idealPrice.textContent = formatPrice(idealPriceValue);
    }
        
        // Différence de prix
        const diff = idealPriceValue !== null ? 
            (idealPriceValue - product.price) : 0;
            
        if (priceDifference) {
            priceDifference.textContent = formatPrice(Math.abs(diff));
            priceDifference.className = diff > 0 ? 
                'detail-value price-diff-positive' : 
                diff < 0 ? 'detail-value price-diff-negative' : 'detail-value';
        }

        // Afficher la meilleure période de vente
    if (bestPeriodContainer && bestPeriodText) {
    // Vérifier si des données d'analyse de ventes sont disponibles
    if (kpi.sales_analysis && kpi.sales_analysis.best_period) {
        const bestPeriod = kpi.sales_analysis.best_period;
        
        if (bestPeriod && bestPeriod.name) {
            bestPeriodText.textContent = `${bestPeriod.name} est la meilleure période de vente avec ${bestPeriod.count} unité(s) vendue(s) pour un total de ${formatPrice(bestPeriod.total_sales)}.`;
            bestPeriodContainer.style.display = 'block';
        } else {
            bestPeriodText.textContent = 'Aucune donnée de vente disponible pour ce produit.';
            bestPeriodContainer.style.display = 'block';
        }
    } else {
        bestPeriodText.textContent = 'Aucune donnée de vente disponible pour ce produit.';
        bestPeriodContainer.style.display = 'block';
    }
}
        
        // Date d'analyse
        if (lastAnalysisDate) {
            const analysisDate = kpi.market_analysis_date || 
                               (scrapingResults.length > 0 ? scrapingResults[0].timestamp : null) ||
                               product.last_analysis_date;
                               
            if (analysisDate) {
                lastAnalysisDate.textContent = new Date(analysisDate).toLocaleDateString('fr-FR');
            } else {
                lastAnalysisDate.textContent = 'Jamais analysé';
            }
        }
        
        // Générer une recommandation
        if (priceRecommendation) {
            let recommendationText = kpi.recommendation;
            
            if (!recommendationText && idealPriceValue !== null) {
                const priceDiff = idealPriceValue - product.price;
                
                if (Math.abs(priceDiff) < product.price * 0.05) {
                    recommendationText = "Votre prix est très compétitif et proche de l'optimal.";
                } else if (priceDiff > 0) {
                    recommendationText = `Considérez une augmentation de prix de ${Math.abs(priceDiff).toFixed(3)} TND pour optimiser votre marge.`;
                } else {
                    recommendationText = `Considérez une réduction de prix de ${Math.abs(priceDiff).toFixed(3)} TND pour être plus compétitif.`;
                }
            } else if (!recommendationText) {
                recommendationText = "Aucune recommandation disponible. Lancez une analyse pour obtenir des recommandations.";
            }
            
            priceRecommendation.textContent = recommendationText;
            
            // Définir la classe CSS en fonction de la recommandation
            if (recommendationText.includes('très compétitif') || recommendationText.includes('optimal')) {
                priceRecommendation.className = 'price-recommendation optimal';
            } else if (recommendationText.includes('augmentation')) {
                priceRecommendation.className = 'price-recommendation below';
            } else if (recommendationText.includes('réduction')) {
                priceRecommendation.className = 'price-recommendation above';
            } else {
                priceRecommendation.className = 'price-recommendation';
            }
        }
        
        // Créer le graphique de comparaison de prix
        if (isChartJsLoaded) {
            createPriceComparisonChart(
                product.price, 
                idealPriceValue, // Utiliser la valeur calculée au lieu de kpi.ideal_price
                kpi.scraped_prices || []
            );
        }
    }

    // Fonction utilitaire pour analyser les commandes par mois
    function analyzeOrdersByMonth(orders) {
        if (!orders || orders.length === 0) return null;
        
        const monthData = {};
        const monthNames = [
            'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
            'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
        ];
        
        // Initialiser tous les mois à 0
        monthNames.forEach((name, index) => {
            monthData[index] = { name, count: 0, total: 0 };
        });
        
        // Compter les ventes par mois
        orders.forEach(order => {
            if (order.order_date) {
                const date = new Date(order.order_date);
                const month = date.getMonth();
                
                order.items.forEach(item => {
                    monthData[month].count += parseInt(item.quantity) || 0;
                    monthData[month].total += parseFloat(item.total || item.price * item.quantity) || 0;
                });
            }
        });
        
        // Trouver le meilleur mois
        let bestMonth = null;
        let maxCount = 0;
        
        for (const month in monthData) {
            if (monthData[month].count > maxCount) {
                maxCount = monthData[month].count;
                bestMonth = monthData[month];
            }
        }
        
        return {
            months: monthData,
            best_month: bestMonth
        };
    }
    
    function loadSalesChartData(productId) {
        fetch(`http://localhost:5000/api/kpis/chart/${productId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Erreur ${response.status}`);
                }
                return response.json();
            })
            .then(chartData => {
                if (isChartJsLoaded) {
                    createSalesChart(chartData);
                } else {
                    console.error("Impossible de créer le graphique: Chart.js non chargé");
                }
            })
            .catch(error => {
                console.error('Erreur lors du chargement des données du graphique:', error);
                // Créer un graphique vide
                if (isChartJsLoaded) {
                    createEmptySalesChart();
                }
            });
    }
    
    function createEmptySalesChart() {
        const canvas = document.getElementById('monthlySalesChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (salesChart) {
            salesChart.destroy();
        }
        
        const emptyLabels = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 
                           'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
        const emptyData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        
        salesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: emptyLabels,
                datasets: [{
                    label: 'Aucune vente enregistrée',
                    data: emptyData,
                    backgroundColor: 'rgba(200, 200, 200, 0.2)',
                    borderColor: 'rgba(200, 200, 200, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Quantité vendue'
                        }
                    }
                }
            }
        });
    }
    
    function createSalesChart(chartData) {
        const canvas = document.getElementById('monthlySalesChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (salesChart) {
            salesChart.destroy();
        }
        
        salesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.labels || [],
                datasets: chartData.datasets || []
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Quantité vendue'
                        }
                    }
                }
            }
        });
    }
    
    function createPriceComparisonChart(currentPrice, idealPrice, scrapedPrices) {
        const canvas = document.getElementById('priceComparisonChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (priceChart) {
            priceChart.destroy();
        }
        
        // Préparer les données pour le graphique
        let labels = ['Prix actuel', 'Prix idéal'];
        let data = [parseFloat(currentPrice) || 0, parseFloat(idealPrice) || 0];
        let backgroundColors = ['rgba(255, 99, 132, 0.2)', 'rgba(75, 192, 192, 0.2)'];
        let borderColors = ['rgba(255, 99, 132, 1)', 'rgba(75, 192, 192, 1)'];
        
        // Ajouter les prix du marché si disponibles
        if (scrapedPrices && Array.isArray(scrapedPrices) && scrapedPrices.length > 0) {
            labels.push('Prix moyen du marché');
            const validPrices = scrapedPrices.filter(price => !isNaN(parseFloat(price)));
            let avgMarketPrice = 0;
            if (validPrices.length > 0) {
                avgMarketPrice = validPrices.reduce((sum, price) => sum + parseFloat(price), 0) / validPrices.length;
            }
            data.push(avgMarketPrice);
            backgroundColors.push('rgba(54, 162, 235, 0.2)');
            borderColors.push('rgba(54, 162, 235, 1)');
        }
        
        priceChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Prix (TND)',
                    data: data,
                    backgroundColor: backgroundColors,
                    borderColor: borderColors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Prix (TND)'
                        }
                    }
                }
            }
        });
    }
    
    function updateDashboard(kpis) {
        // Total produits analysés
        const totalProductsEl = document.getElementById('totalProducts');
        if (totalProductsEl) totalProductsEl.textContent = kpis.length;
        
        // Différence prix moyenne
        const avgPriceDiffEl = document.getElementById('avgPriceDiff');
        if (avgPriceDiffEl) {
            const validKpis = kpis.filter(kpi => kpi.price_difference !== undefined && kpi.price_difference !== null);
            const avgDiff = validKpis.length > 0 ? 
                validKpis.reduce((sum, kpi) => sum + parseFloat(kpi.price_difference || 0), 0) / validKpis.length : 0;
            avgPriceDiffEl.textContent = validKpis.length > 0 ? formatPrice(avgDiff) : '-';
        }
        
        // Prix optimaux (différence < 5%)
        const optimalPriceCountEl = document.getElementById('optimalPriceCount');
        if (optimalPriceCountEl) {
            const optimalCount = kpis.filter(kpi => {
                if (!kpi.price_difference || !kpi.current_price) return false;
                const diff = Math.abs(parseFloat(kpi.price_difference || 0));
                const percentage = parseFloat(kpi.current_price) > 0 ? 
                    (diff / parseFloat(kpi.current_price)) * 100 : 0;
                return percentage < 5;
            }).length;
            optimalPriceCountEl.textContent = optimalCount;
        }
        
        // Potentiel de revenus (somme des différences positives)
        const totalRevenuePotentialEl = document.getElementById('totalRevenuePotential');
        if (totalRevenuePotentialEl) {
            const revenuePotential = kpis.reduce((sum, kpi) => {
                const diff = parseFloat(kpi.price_difference || 0);
                return sum + Math.max(0, diff);
            }, 0);
            totalRevenuePotentialEl.textContent = formatPrice(revenuePotential);
        }
    }
    
    function displayKpis(kpis) {
        if (!kpiTableBody) return;
        
        kpiTableBody.innerHTML = '';
        
        if (!kpis || kpis.length === 0) {
            kpiTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center;">Aucun KPI trouvé</td></tr>';
            return;
        }
        
        kpis.forEach(kpi => {
            const row = document.createElement('tr');
            
            const priceDiff = parseFloat(kpi.price_difference || 0);
            const priceDiffClass = priceDiff > 0 ? 'price-diff-positive' : 
                                 priceDiff < 0 ? 'price-diff-negative' : 'price-diff-neutral';
            const priceDiffText = formatPrice(priceDiff);
            
            const formattedDate = kpi.market_analysis_date ? 
                new Date(kpi.market_analysis_date).toLocaleDateString('fr-FR') : '-';
            
            row.innerHTML = `
                <td><strong>${kpi.product_name || 'Produit sans nom'}</strong></td>
                <td>${formatPrice(kpi.current_price)}</td>
                <td>${formatPrice(kpi.ideal_price)}</td>
                <td class="${priceDiffClass}">${priceDiffText}</td>
                <td class="recommendation-cell">${kpi.recommendation || 'Aucune recommandation'}</td>
                <td>${formattedDate}</td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-small btn-export" onclick="viewProductDetails('${kpi.product_id}')">
                            Détails
                        </button>
                    </div>
                </td>
            `;
            
            kpiTableBody.appendChild(row);
        });
    }
    
    function applyFilters() {
        let filteredKpis = [...allKpis];
        
        // Filtre par produit
        const selectedProduct = productKpiFilter ? productKpiFilter.value : '';
        if (selectedProduct) {
            filteredKpis = filteredKpis.filter(kpi => kpi.product_id === selectedProduct);
        }
        
        // Tri
        const sortField = sortBy ? sortBy.value : 'date';
        filteredKpis.sort((a, b) => {
            switch(sortField) {
                case 'date':
                    return new Date(b.market_analysis_date || 0) - new Date(a.market_analysis_date || 0);
                case 'price_diff':
                    return (parseFloat(b.price_difference || 0)) - (parseFloat(a.price_difference || 0));
                case 'product_name':
                    return (a.product_name || '').localeCompare(b.product_name || '');
                default:
                    return 0;
            }
        });
        
        displayKpis(filteredKpis);
        updateDashboard(filteredKpis);
    }
    
    function exportKpis() {
        if (allKpis.length === 0) {
            showMessage('Aucune donnée à exporter', true);
            return;
        }
        
        // Créer les données CSV
        const headers = ['Produit', 'Prix actuel (TND)', 'Prix idéal (TND)', 'Différence (TND)', 'Recommandation', 'Date d\'analyse'];
        const csvData = [headers.join(',')];
        
        allKpis.forEach(kpi => {
            const row = [
                `"${kpi.product_name || 'Produit sans nom'}"`,
                (parseFloat(kpi.current_price || 0)).toFixed(3),
                (parseFloat(kpi.ideal_price || 0)).toFixed(3),
                (parseFloat(kpi.price_difference || 0)).toFixed(3),
                `"${kpi.recommendation || ''}"`,
                kpi.market_analysis_date ? new Date(kpi.market_analysis_date).toLocaleDateString('fr-FR') : '-'
            ];
            csvData.push(row.join(','));
        });
        
        // Télécharger le fichier
        const blob = new Blob([csvData.join('\n')], {type: 'text/csv;charset=utf-8;'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `kpis-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        showMessage('KPIs exportés avec succès');
    }
    
    // Fonction globale pour les boutons dans le HTML - uniquement pour voir les détails
    window.viewProductDetails = function(productId) {
        // Sélectionner le produit dans la liste déroulante
        if (productSelect) {
            productSelect.value = productId;
        }
        
        // Charger les détails du produit
        loadProductDetails(productId);
        
        // Faire défiler jusqu'à la section d'analyse
        if (productAnalysisSection) {
            productAnalysisSection.scrollIntoView({ behavior: 'smooth' });
        }
    };
});