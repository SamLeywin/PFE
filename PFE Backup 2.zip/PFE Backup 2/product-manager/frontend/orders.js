document.addEventListener('DOMContentLoaded', function() {
    const ordersList = document.getElementById('ordersList');
    const messageDiv = document.getElementById('message');
    const dateFromFilter = document.getElementById('dateFromFilter');
    const dateToFilter = document.getElementById('dateToFilter');
    const productFilter = document.getElementById('productFilter');
    const applyFiltersBtn = document.getElementById('applyFiltersBtn');
    const resetFiltersBtn = document.getElementById('resetFiltersBtn');
    const orderStats = document.getElementById('orderStats');
    
    // Initialiser la date "à" à aujourd'hui
    const today = new Date();
    dateToFilter.valueAsDate = today;
    
    // Initialiser la date "de" à 30 jours avant
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(today.getDate() - 30);
    dateFromFilter.valueAsDate = thirtyDaysAgo;
    
    // Charger les commandes et produits au démarrage
    loadOrders();
    loadProductsForFilter();
    
    // Event listeners
    applyFiltersBtn.addEventListener('click', applyFilters);
    resetFiltersBtn.addEventListener('click', resetFilters);
    
    function showMessage(text, isError = false) {
        messageDiv.textContent = text;
        messageDiv.className = isError ? 'message error' : 'message success';
        setTimeout(() => {
            messageDiv.textContent = '';
            messageDiv.className = 'message';
        }, 5000);
    }
    
    function loadOrders(filters) {
    showMessage('Chargement des commandes...');
    
    // Construire l'URL avec les filtres
    let url = 'http://localhost:5000/api/orders';
    
    // Ajouter les paramètres de filtrage
    const params = [];
    
    // Utiliser les filtres passés en paramètre, sinon utiliser les valeurs des champs
    const dateFromValue = filters?.dateFrom || dateFromFilter.value;
    const dateToValue = filters?.dateTo || dateToFilter.value;
    const productIdValue = filters?.productId || productFilter.value;
    
    if (dateFromValue) {
        params.push(`date_from=${dateFromValue}`);
    }
    
    if (dateToValue) {
        params.push(`date_to=${dateToValue}`);
    }
    
    if (productIdValue) {
        params.push(`product_id=${productIdValue}`);
    }
    
    // Ajouter les paramètres à l'URL s'ils existent
    if (params.length > 0) {
        url += '?' + params.join('&');
    }
    
    // Ajouter un paramètre pour éviter le cache
    if (url.includes('?')) {
        url += `&_t=${Date.now()}`;
    } else {
        url += `?_t=${Date.now()}`;
    }
    
    console.log("Chargement des commandes depuis:", url);
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erreur ${response.status}`);
            }
            return response.json();
        })
        .then(orders => {
            console.log(`${orders.length} commandes chargées:`, orders);
            displayOrders(orders);
            showMessage(`${orders.length} commandes chargées`);
        })
        .catch(error => {
            console.error('Erreur:', error);
            showMessage(`Erreur: ${error.message}`, true);
            ordersContainer.innerHTML = '<p class="no-results">Erreur lors du chargement des commandes</p>';
        });
}
    
    function loadProductsForFilter() {
        fetch('http://localhost:5000/api/products')
            .then(response => response.json())
            .then(products => {
                productFilter.innerHTML = '<option value="">Tous les produits</option>';
                products.forEach(product => {
                    const option = document.createElement('option');
                    option.value = product.id;
                    option.textContent = product.name;
                    productFilter.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Erreur lors du chargement des produits:', error);
            });
    }
    
    function displayOrders(orders) {
        ordersList.innerHTML = '';
        
        if (orders.length === 0) {
            ordersList.innerHTML = '<p>Aucune commande trouvée</p>';
            return;
        }
        
        orders.forEach(order => {
            const orderCard = document.createElement('div');
            orderCard.className = 'order-card';
            
            const orderDate = new Date(order.order_date).toLocaleDateString('fr-FR');
            
            let orderHtml = `
                <div class="order-info">
                    <div>
                        <strong>Commande #${order.order_id}</strong>
                        <div>Date: ${orderDate}</div>
                    </div>
                    <div>
                        <strong>Total: ${formatPrice(order.total_amount)}</strong>
                    </div>
                </div>
                <div class="order-meta">
                    <div>ID: ${order._id || order.id}</div>
                </div>
                <div class="order-items">
                    <h4>Articles</h4>
                    ${order.items.map(item => `
                        <div class="order-item">
                            <div>
                                <div><strong>${item.product_name}</strong></div>
                                <div>Quantité: ${item.quantity}</div>
                            </div>
                            <div>
                                <div>${formatPrice(item.price)} / unité</div>
                                <div><strong>${formatPrice(item.total)}</strong></div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
            
            orderCard.innerHTML = orderHtml;
            ordersList.appendChild(orderCard);
        });
    }
    
    function updateOrderStats(orders) {
        // Calculer les statistiques
        const totalOrders = orders.length;
        const totalRevenue = orders.reduce((sum, order) => sum + order.total_amount, 0);
        const totalProducts = orders.reduce((sum, order) => sum + order.items.reduce((s, item) => s + item.quantity, 0), 0);
        
        // Trouver le produit le plus vendu
        const productCounts = {};
        orders.forEach(order => {
            order.items.forEach(item => {
                if (!productCounts[item.product_name]) {
                    productCounts[item.product_name] = 0;
                }
                productCounts[item.product_name] += item.quantity;
            });
        });
        
        let bestProduct = { name: 'Aucun', count: 0 };
        Object.keys(productCounts).forEach(name => {
            if (productCounts[name] > bestProduct.count) {
                bestProduct = { name: name, count: productCounts[name] };
            }
        });
        
        // Mettre à jour les statistiques dans l'UI
        orderStats.innerHTML = `
            <div class="stat-card">
                <div class="stat-number">${totalOrders}</div>
                <div class="stat-label">Commandes</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${formatPrice(totalRevenue)}</div>
                <div class="stat-label">Chiffre d'affaires</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${totalProducts}</div>
                <div class="stat-label">Articles vendus</div>
            </div>
            <div class="stat-card">
                <div class="stat-number">${bestProduct.name}</div>
                <div class="stat-label">Produit le plus vendu (${bestProduct.count} unités)</div>
            </div>
        `;
    }
    
    function applyFilters() {
        const filters = {
            dateFrom: dateFromFilter.value,
            dateTo: dateToFilter.value,
            productId: productFilter.value
        };
        
        loadOrders(filters);
    }
    
    function resetFilters() {
        // Réinitialiser les valeurs des filtres
        const today = new Date();
        dateToFilter.valueAsDate = today;
        
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(today.getDate() - 30);
        dateFromFilter.valueAsDate = thirtyDaysAgo;
        
        productFilter.value = '';
        
        // Recharger les commandes sans filtre
        loadOrders();
    }
    
    function formatPrice(price) {
        if (price === null || price === undefined) return '-';
        return parseFloat(price).toFixed(3) + ' TND';
    }
    
    // Fonction globale pour exporter les commandes actuellement filtrées
    window.exportOrders = function() {
        const filters = {
            dateFrom: dateFromFilter.value,
            dateTo: dateToFilter.value,
            productId: productFilter.value
        };
        
        let url = 'http://localhost:5000/api/orders/export?';
        const params = [];
        
        if (filters.dateFrom) params.push(`date_from=${filters.dateFrom}`);
        if (filters.dateTo) params.push(`date_to=${filters.dateTo}`);
        if (filters.productId) params.push(`product_id=${filters.productId}`);
        
        url += params.join('&');
        
        // Redirection vers l'URL d'export pour télécharger le fichier
        window.location.href = url;
    };
});