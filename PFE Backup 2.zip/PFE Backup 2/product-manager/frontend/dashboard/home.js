document.addEventListener('DOMContentLoaded', function() {
    // Éléments DOM
    const productSelect = document.getElementById('productSelect');
    const refreshBtn = document.getElementById('refreshBtn');
    const messageDiv = document.getElementById('message');
    
    // Éléments d'information sur le produit
    const productName = document.getElementById('productName');
    const currentPrice = document.getElementById('currentPrice');
    const productCategory = document.getElementById('productCategory');
    const lastAnalysisDate = document.getElementById('lastAnalysisDate');
    const recommendationText = document.getElementById('recommendationText');
    
    // Variables pour les graphiques
    let salesTrendChart = null;
    let priceDistributionChart = null;
    let idealPriceGauge = null;
    let salesVolumeChart = null;
    let bestPeriodChart = null;
    let competitorCountChart = null;
    
    // Vérifier si l'utilisateur est connecté
    const token = localStorage.getItem('authToken');
    if (!token) {
        window.location.href = '../auth/login.html';
        return;
    }
    
    // Charger les produits pour le sélecteur
    loadProducts();
    
    // Event listeners
    if (productSelect) {
        productSelect.addEventListener('change', function() {
            if (this.value) {
                loadDashboard(this.value);
            } else {
                resetDashboard();
            }
        });
    }
    
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            if (productSelect.value) {
                loadDashboard(productSelect.value);
            }
        });
    }
    
    function loadProducts() {
        fetch('http://localhost:5000/api/products', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erreur ${response.status}`);
            }
            return response.json();
        })
        .then(products => {
            productSelect.innerHTML = '<option value="">-- Sélectionnez un produit --</option>';
            
            products.forEach(product => {
                const option = document.createElement('option');
                option.value = product.id;
                option.textContent = product.name;
                productSelect.appendChild(option);
            });
            
            showMessage(`${products.length} produits disponibles`);
        })
        .catch(error => {
            console.error('Erreur:', error);
            showMessage(`Erreur: ${error.message}`, true);
        });
    }
    
    function loadDashboard(productId) {
        showMessage('Chargement des données...');
        
        fetch(`http://localhost:5000/api/dashboard/${productId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erreur ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            // Mettre à jour les informations du produit
            updateProductInfo(data.product);
            
            // Recommandation
            if (recommendationText) {
                recommendationText.textContent = data.recommendation || 'Aucune recommandation disponible';
            }
            
            // Créer/mettre à jour tous les graphiques
            createSalesTrendChart(data.sales_trend);
            createPriceDistributionChart(data.price_distribution);
            createIdealPriceGauge(data.ideal_price_gauge);
            createSalesVolumeChart(data.sales_volume);
            createBestPeriodChart(data.best_periods);
            createCompetitorCountChart(data.competitor_count);
            
            showMessage('Données chargées avec succès');
        })
        .catch(error => {
            console.error('Erreur:', error);
            showMessage(`Erreur: ${error.message}`, true);
        });
    }
    
    function updateProductInfo(product) {
        if (productName) productName.textContent = product.name || 'Produit sans nom';
        if (currentPrice) currentPrice.textContent = formatPrice(product.price);
        if (productCategory) productCategory.textContent = product.category || '-';
        if (lastAnalysisDate) {
            lastAnalysisDate.textContent = product.last_analysis_date ? 
                new Date(product.last_analysis_date).toLocaleDateString('fr-FR') : 'Jamais analysé';
        }
    }
    
    function resetDashboard() {
        // Réinitialiser les informations du produit
        if (productName) productName.textContent = 'Nom du produit';
        if (currentPrice) currentPrice.textContent = '0 TND';
        if (productCategory) productCategory.textContent = '-';
        if (lastAnalysisDate) lastAnalysisDate.textContent = '-';
        if (recommendationText) recommendationText.textContent = 'Sélectionnez un produit pour voir les recommandations.';
        
        // Réinitialiser tous les graphiques
        destroyCharts();
    }
    
    function destroyCharts() {
        if (salesTrendChart) salesTrendChart.destroy();
        if (priceDistributionChart) priceDistributionChart.destroy();
        if (idealPriceGauge) idealPriceGauge.destroy();
        if (salesVolumeChart) salesVolumeChart.destroy();
        if (bestPeriodChart) bestPeriodChart.destroy();
        if (competitorCountChart) competitorCountChart.destroy();
    }
    
    // Fonctions pour créer les graphiques
    function createSalesTrendChart(data) {
        const canvas = document.getElementById('salesTrendChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (salesTrendChart) {
            salesTrendChart.destroy();
        }
        
        const months = data.map(item => item.month);
        const sales = data.map(item => item.sales);
        
        salesTrendChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: 'Ventes',
                    data: sales,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 2,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Quantité vendue'
                        }
                    }
                },
                plugins: {
                    title: {
                        display: false
                    }
                }
            }
        });
    }
    
    function createPriceDistributionChart(data) {
        const canvas = document.getElementById('priceDistributionChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (priceDistributionChart) {
            priceDistributionChart.destroy();
        }
        
        const labels = data.map(item => item.range);
        const counts = data.map(item => item.count);
        
        priceDistributionChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Nombre de produits',
                    data: counts,
                    backgroundColor: 'rgba(75, 192, 75, 0.6)',
                    borderColor: 'rgba(75, 192, 75, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Nombre de produits'
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 45,
                            minRotation: 45
                        }
                    }
                },
                plugins: {
                    title: {
                        display: false
                    }
                }
            }
        });
    }
    
    function createIdealPriceGauge(data) {
        const canvas = document.getElementById('idealPriceGauge');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (idealPriceGauge) {
            idealPriceGauge.destroy();
        }
        
        // Configuration de la jauge
        const gaugeChartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                datalabels: {
                    display: false
                },
                tooltip: {
                    enabled: false
                }
            },
            cutout: '50%',
            rotation: 270,
            circumference: 180,
            showTooltips: false
        };
        
        // Créer un graphique de type "doughnut" pour simuler une jauge
        idealPriceGauge = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Prix idéal', 'Écart'],
                datasets: [{
                    data: [data.ideal, data.max - data.ideal],
                    backgroundColor: [
                        'rgba(255, 159, 64, 0.7)', // Orange
                        'rgba(220, 220, 220, 0.3)' // Gris clair
                    ],
                    borderWidth: 0
                }]
            },
            options: gaugeChartOptions
        });
        
        // Ajouter un texte pour afficher les valeurs
        const idealPriceText = document.createElement('div');
        idealPriceText.className = 'gauge-value';
        idealPriceText.innerHTML = `<span>Prix actuel: ${formatPrice(data.current)}</span>
                                    <span>Prix idéal: ${formatPrice(data.ideal)}</span>`;
        
        const container = canvas.parentNode;
        container.style.position = 'relative';
        container.appendChild(idealPriceText);
    }
    
    function createSalesVolumeChart(data) {
        const canvas = document.getElementById('salesVolumeChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (salesVolumeChart) {
            salesVolumeChart.destroy();
        }
        
        const periods = data.map(item => item.period);
        const volumes = data.map(item => item.sales);
        
        salesVolumeChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: periods,
                datasets: [{
                    label: 'Volume de ventes',
                    data: volumes,
                    backgroundColor: 'rgba(128, 128, 128, 0.6)',
                    borderColor: 'rgba(128, 128, 128, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Unités vendues'
                        }
                    }
                },
                plugins: {
                    title: {
                        display: false
                    }
                }
            }
        });
    }
    
    function createBestPeriodChart(data) {
        const canvas = document.getElementById('bestPeriodChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (bestPeriodChart) {
            bestPeriodChart.destroy();
        }
        
        // Si aucune donnée, afficher un message
        if (!data || data.length === 0) {
            const noDataText = document.createElement('div');
            noDataText.className = 'no-data-text';
            noDataText.textContent = 'Aucune donnée disponible';
            
            const container = canvas.parentNode;
            container.innerHTML = '';
            container.appendChild(noDataText);
            return;
        }
        
        const labels = data.map(item => item.name);
        const values = data.map(item => item.percentage);
        
        // Couleurs vives pour le graphique en secteurs
        const backgroundColors = [
            'rgba(255, 99, 132, 0.7)',
            'rgba(54, 162, 235, 0.7)',
            'rgba(255, 206, 86, 0.7)',
            'rgba(75, 192, 192, 0.7)',
            'rgba(153, 102, 255, 0.7)'
        ];
        
        bestPeriodChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    data: values,
                    backgroundColor: backgroundColors,
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            boxWidth: 15
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                return `${label}: ${value.toFixed(1)}%`;
                            }
                        }
                    }
                }
            }
        });
    }
    
    function createCompetitorCountChart(count) {
        const canvas = document.getElementById('competitorCountChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        if (competitorCountChart) {
            competitorCountChart.destroy();
        }
        
        // Donut chart for competitor count
        competitorCountChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Concurrents'],
                datasets: [{
                    data: [count, 1], // Use 1 as placeholder for proper rendering
                    backgroundColor: [
                        'rgba(255, 0, 0, 0.7)', // Red
                        'rgba(220, 220, 220, 0.1)' // Light grey (almost invisible)
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                cutout: '70%',
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: false
                    }
                }
            }
        });
        
        // Display the number in the center
        const countDisplay = document.createElement('div');
        countDisplay.className = 'competitor-count';
        countDisplay.innerHTML = `<span class="count-value">${count}</span><span class="count-label">concurrents</span>`;
        
        const container = canvas.parentNode;
        container.style.position = 'relative';
        container.appendChild(countDisplay);
    }
    
    // Fonction utilitaire pour formater les prix
    function formatPrice(price) {
        if (price === null || price === undefined || isNaN(parseFloat(price))) return '-';
        return parseFloat(price).toFixed(3) + ' TND';
    }
    
    function showMessage(text, isError = false) {
        if (!messageDiv) return;
        
        messageDiv.textContent = text;
        messageDiv.className = isError ? 'message error' : 'message success';
        setTimeout(() => {
            messageDiv.textContent = '';
            messageDiv.className = 'message';
        }, 5000);
    }
});