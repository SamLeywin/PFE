document.addEventListener('DOMContentLoaded', function() {
    const productForm = document.getElementById('productForm');
    const productsList = document.getElementById('productsList');
    const addAnotherBtn = document.getElementById('addAnother');
    const submitBtn = document.getElementById('submitProducts');
    const messageDiv = document.getElementById('message');
    
    // Pour l'importation CSV
    const csvFileInput = document.getElementById('csvFile');
    const csvPreview = document.getElementById('csvPreview');
    const previewHeader = document.getElementById('previewHeader');
    const previewData = document.getElementById('previewData');
    const nameColumn = document.getElementById('nameColumn');
    const priceColumn = document.getElementById('priceColumn');
    const descriptionColumn = document.getElementById('descriptionColumn');
    const categoryColumn = document.getElementById('categoryColumn');
    const stockColumn = document.getElementById('stockColumn');
    const importCsvBtn = document.getElementById('importCsvBtn');
    const csvImportMessage = document.getElementById('csvImportMessage');
    
    // Pour l'importation des commandes
    const orderCsvFile = document.getElementById('orderCsvFile');
    const orderCsvPreview = document.getElementById('orderCsvPreview');
    const orderPreviewHeader = document.getElementById('orderPreviewHeader');
    const orderPreviewData = document.getElementById('orderPreviewData');
    const importOrdersBtn = document.getElementById('importOrdersBtn');
    const orderImportMessage = document.getElementById('orderImportMessage');
    const orderIdColumn = document.getElementById('orderIdColumn');
    const productNameColumn = document.getElementById('productNameColumn');
    const productIdColumn = document.getElementById('productIdColumn');
    const quantityColumn = document.getElementById('quantityColumn');
    const orderPriceColumn = document.getElementById('orderPriceColumn');
    const dateColumn = document.getElementById('dateColumn');
    
    let productsToSubmit = [];
    
    // Ajouter Papa Parse pour le parsing CSV
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.3.1/papaparse.min.js';
    document.head.appendChild(script);
    
    // Initialiser les écouteurs d'événements une fois que Papa Parse est chargé
    script.onload = function() {
        if (csvFileInput) {
            csvFileInput.addEventListener('change', handleProductCsvFile);
        }
        if (orderCsvFile) {
            orderCsvFile.addEventListener('change', handleOrderCsvFile);
        }
    };
    
    // Gérer l'ajout de produits individuels
    if (addAnotherBtn) {
        addAnotherBtn.addEventListener('click', function() {
            const formData = getFormData();
            if (validateForm(formData)) {
                addProductToList(formData);
                resetForm();
            }
        });
    }
    
    if (submitBtn) {
        submitBtn.addEventListener('click', submitProducts);
    }
    
    if (importCsvBtn) {
        importCsvBtn.addEventListener('click', importProductsFromCsv);
    }
    
    if (importOrdersBtn) {
        importOrdersBtn.addEventListener('click', importOrdersFromCsv);
    }
    
    // Récupérer les données du formulaire
    function getFormData() {
        return {
            name: document.getElementById('name').value,
            price: parseFloat(document.getElementById('price').value),
            description: document.getElementById('description').value,
            category: document.getElementById('category').value,
            stock: document.getElementById('stock').value ? parseInt(document.getElementById('stock').value) : null
        };
    }
    
    // Valider le formulaire
    function validateForm(data) {
        if (!data.name) {
            showMessage('Le nom du produit est obligatoire', true);
            return false;
        }
        if (isNaN(data.price) || data.price <= 0) {
            showMessage('Le prix doit être un nombre positif', true);
            return false;
        }
        return true;
    }
    
    // Ajouter un produit à la liste
    function addProductToList(product) {
        productsToSubmit.push(product);
        updateProductsList();
        showMessage('Produit ajouté à la liste');
    }
    
    // Mettre à jour la liste des produits
    function updateProductsList() {
        productsList.innerHTML = '';
        
        if (productsToSubmit.length === 0) {
            productsList.innerHTML = '<p>Aucun produit ajouté</p>';
            return;
        }
        
        productsToSubmit.forEach((product, index) => {
            const productItem = document.createElement('div');
            productItem.className = 'product-item';
            productItem.innerHTML = `
                <div class="product-info">
                    <div class="product-name">${product.name}</div>
                    <div class="product-price">${product.price.toFixed(3)} TND</div>
                </div>
                <button class="remove-btn" data-index="${index}">×</button>
            `;
            
            // Ajouter un écouteur pour le bouton de suppression
            productItem.querySelector('.remove-btn').addEventListener('click', function() {
                const index = parseInt(this.getAttribute('data-index'));
                productsToSubmit.splice(index, 1);
                updateProductsList();
            });
            
            productsList.appendChild(productItem);
        });
    }
    
    // Réinitialiser le formulaire
    function resetForm() {
        document.getElementById('name').value = '';
        document.getElementById('price').value = '';
        document.getElementById('description').value = '';
        document.getElementById('category').value = '';
        document.getElementById('stock').value = '';
        document.getElementById('name').focus();
    }
    
    // Afficher un message
    function showMessage(text, isError = false) {
        if (!messageDiv) return;
        
        messageDiv.textContent = text;
        messageDiv.className = isError ? 'message error' : 'message success';
        setTimeout(() => {
            messageDiv.textContent = '';
            messageDiv.className = 'message';
        }, 5000);
    }
    
    function showCsvImportMessage(text, isError = false) {
        if (!csvImportMessage) return;
        
        csvImportMessage.textContent = text;
        csvImportMessage.className = isError ? 'message error' : 'message success';
        setTimeout(() => {
            csvImportMessage.textContent = '';
            csvImportMessage.className = 'message';
        }, 5000);
    }
    
    function showOrderImportMessage(text, isError = false) {
        if (!orderImportMessage) return;
        
        orderImportMessage.textContent = text;
        orderImportMessage.className = isError ? 'message error' : 'message success';
        setTimeout(() => {
            orderImportMessage.textContent = '';
            orderImportMessage.className = 'message';
        }, 5000);
    }
    
    // Soumettre les produits à l'API
    function submitProducts() {
        if (productsToSubmit.length === 0) {
            showMessage('Aucun produit à soumettre', true);
            return;
        }
        
        // Afficher un message de chargement
        showMessage('Envoi des produits en cours...', false);
        
        // URL de l'API - assurez-vous que cette URL est correcte
        const apiUrl = 'http://localhost:5000/api/products';
        
        console.log('Envoi des données à:', apiUrl);
        console.log('Données envoyées:', JSON.stringify({ products: productsToSubmit }));
        
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({ products: productsToSubmit }),
        })
        .then(response => {
            console.log('Statut de la réponse:', response.status);
            
            if (!response.ok) {
                return response.json().then(errorData => {
                    throw new Error(`Erreur ${response.status}: ${errorData.error || 'Erreur inconnue'}`);
                });
            }
            return response.json();
        })
        .then(data => {
            console.log('Réponse reçue:', data);
            showMessage(`${productsToSubmit.length} produit(s) ajouté(s) avec succès!`);
            productsToSubmit = [];
            updateProductsList();
        })
        .catch(error => {
            console.error('Erreur fetch:', error);
            showMessage(`Erreur: ${error.message}`, true);
        });
    }
    
    // Gestion de l'importation CSV pour les produits
    function handleProductCsvFile(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        showCsvImportMessage('Analyse du fichier CSV en cours...');
        
        // Utiliser Papa Parse pour analyser le CSV
        Papa.parse(file, {
            header: true,
            preview: 5, // Aperçu des 5 premières lignes
            complete: function(results) {
                displayProductCsvPreview(results.data, results.meta.fields);
                showCsvImportMessage('Fichier CSV chargé avec succès. Veuillez mapper les colonnes.');
            },
            error: function(error) {
                showCsvImportMessage('Erreur lors de l\'analyse du fichier CSV: ' + error.message, true);
            }
        });
    }
    
    function displayProductCsvPreview(data, headers) {
        // Réinitialiser les zones
        previewHeader.innerHTML = '';
        previewData.innerHTML = '';
        
        // Afficher l'aperçu
        csvPreview.style.display = 'block';
        
        // Créer l'en-tête du tableau
        const headerRow = document.createElement('tr');
        headers.forEach(header => {
            const th = document.createElement('th');
            th.textContent = header;
            headerRow.appendChild(th);
        });
        previewHeader.appendChild(headerRow);
        
        // Ajouter les données d'aperçu
        data.forEach((row, rowIndex) => {
            if (rowIndex >= 5) return; // Limiter à 5 lignes
            
            const tr = document.createElement('tr');
            headers.forEach(header => {
                const td = document.createElement('td');
                td.textContent = row[header] || '';
                tr.appendChild(td);
            });
            previewData.appendChild(tr);
        });
        
        // Remplir les options de colonne
        populateColumnOptions(nameColumn, headers, 'name');
        populateColumnOptions(priceColumn, headers, 'price');
        populateColumnOptions(descriptionColumn, headers, null, true);
        populateColumnOptions(categoryColumn, headers, null, true);
        populateColumnOptions(stockColumn, headers, null, true);
    }
    
    function populateColumnOptions(selectElement, headers, defaultColumn, includeEmpty = false) {
        if (!selectElement) return;
        
        selectElement.innerHTML = '';
        
        // Ajouter l'option vide si nécessaire
        if (includeEmpty) {
            const emptyOption = document.createElement('option');
            emptyOption.value = '';
            emptyOption.textContent = '-- Non inclus --';
            selectElement.appendChild(emptyOption);
        }
        
        // Ajouter les en-têtes comme options
        headers.forEach(header => {
            const option = document.createElement('option');
            option.value = header;
            option.textContent = header;
            
            // Sélectionner automatiquement si le nom de la colonne contient le type par défaut
            const headerLower = header.toLowerCase();
            if (defaultColumn && headerLower.includes(defaultColumn)) {
                option.selected = true;
            }
            
            selectElement.appendChild(option);
        });
    }
    
    function importProductsFromCsv() {
        const file = csvFileInput.files[0];
        if (!file) {
            showCsvImportMessage('Veuillez sélectionner un fichier CSV', true);
            return;
        }
        
        const nameCol = nameColumn.value;
        const priceCol = priceColumn.value;
        
        if (!nameCol || !priceCol) {
            showCsvImportMessage('Les colonnes pour le nom et le prix sont obligatoires', true);
            return;
        }
        
        showCsvImportMessage('Importation en cours...');
        
        // Créer un FormData pour l'envoi
        const formData = new FormData();
        formData.append('file', file);
        formData.append('name_column', nameCol);
        formData.append('price_column', priceCol);
        
        // Ajouter les colonnes optionnelles si sélectionnées
        if (descriptionColumn.value) {
            formData.append('description_column', descriptionColumn.value);
        }
        if (categoryColumn.value) {
            formData.append('category_column', categoryColumn.value);
        }
        if (stockColumn.value) {
            formData.append('stock_column', stockColumn.value);
        }
        
        // Envoyer à l'API
        fetch('http://localhost:5000/api/products/import/csv', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    throw new Error(`Erreur ${response.status}: ${errorData.error || 'Erreur inconnue'}`);
                });
            }
            return response.json();
        })
        .then(data => {
            showCsvImportMessage(`${data.products.length} produits importés avec succès!`);
            
            // Réinitialiser le formulaire
            csvFileInput.value = '';
            csvPreview.style.display = 'none';
        })
        .catch(error => {
            console.error('Erreur lors de l\'importation:', error);
            showCsvImportMessage(`Erreur: ${error.message}`, true);
        });
    }
    
    // Gestion de l'importation CSV pour les commandes
    function handleOrderCsvFile(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        showOrderImportMessage('Analyse du fichier CSV en cours...');
        
        // Utiliser Papa Parse pour analyser le CSV
        Papa.parse(file, {
            header: true,
            preview: 5, // Aperçu des 5 premières lignes
            complete: function(results) {
                displayOrderCsvPreview(results.data, results.meta.fields);
                showOrderImportMessage('Fichier CSV chargé avec succès. Veuillez mapper les colonnes.');
            },
            error: function(error) {
                showOrderImportMessage('Erreur lors de l\'analyse du fichier CSV: ' + error.message, true);
            }
        });
    }
    
    function displayOrderCsvPreview(data, headers) {
        // Réinitialiser les zones
        orderPreviewHeader.innerHTML = '';
        orderPreviewData.innerHTML = '';
        
        // Afficher l'aperçu
        orderCsvPreview.style.display = 'block';
        
        // Créer l'en-tête du tableau
        const headerRow = document.createElement('tr');
        headers.forEach(header => {
            const th = document.createElement('th');
            th.textContent = header;
            headerRow.appendChild(th);
        });
        orderPreviewHeader.appendChild(headerRow);
        
        // Ajouter les données d'aperçu
        data.forEach((row, rowIndex) => {
            if (rowIndex >= 5) return; // Limiter à 5 lignes
            
            const tr = document.createElement('tr');
            headers.forEach(header => {
                const td = document.createElement('td');
                td.textContent = row[header] || '';
                tr.appendChild(td);
            });
            orderPreviewData.appendChild(tr);
        });
        
        // Remplir les options de colonne pour les commandes
        populateColumnOptions(orderIdColumn, headers, 'order');
        populateColumnOptions(productNameColumn, headers, 'product');
        populateColumnOptions(productIdColumn, headers, 'id', true);
        populateColumnOptions(quantityColumn, headers, 'quantity');
        populateColumnOptions(orderPriceColumn, headers, 'price', true);
        populateColumnOptions(dateColumn, headers, 'date', true);
    }
    
    function importOrdersFromCsv() {
        const file = orderCsvFile.files[0];
        if (!file) {
            showOrderImportMessage('Veuillez sélectionner un fichier CSV', true);
            return;
        }
        
        const orderIdCol = orderIdColumn.value;
        const productNameCol = productNameColumn.value;
        const quantityCol = quantityColumn.value;
        
        if (!orderIdCol || !productNameCol || !quantityCol) {
            showOrderImportMessage('Les colonnes pour l\'ID de commande, le nom du produit et la quantité sont obligatoires', true);
            return;
        }
        
        showOrderImportMessage('Importation des commandes en cours...');
        
        // Créer un FormData pour l'envoi
        const formData = new FormData();
        formData.append('file', file);
        formData.append('order_id_column', orderIdCol);
        formData.append('product_name_column', productNameCol);
        formData.append('quantity_column', quantityCol);
        
        // Ajouter les colonnes optionnelles si sélectionnées
        if (productIdColumn.value) {
            formData.append('product_id_column', productIdColumn.value);
        }
        if (orderPriceColumn.value) {
            formData.append('price_column', orderPriceColumn.value);
        }
        if (dateColumn.value) {
            formData.append('date_column', dateColumn.value);
        }
        
        // Envoyer à l'API
        fetch('http://localhost:5000/api/orders/import', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(errorData => {
                    throw new Error(`Erreur ${response.status}: ${errorData.error || 'Erreur inconnue'}`);
                });
            }
            return response.json();
        })
        .then(data => {
            showOrderImportMessage(`${data.orders.length} commandes importées avec succès!`);
            
            // Réinitialiser le formulaire
            orderCsvFile.value = '';
            orderCsvPreview.style.display = 'none';
        })
        .catch(error => {
            console.error('Erreur lors de l\'importation des commandes:', error);
            showOrderImportMessage(`Erreur: ${error.message}`, true);
        });
    }
});