document.addEventListener('DOMContentLoaded', function() {
    // Vérifier si l'utilisateur est connecté
    const token = localStorage.getItem('authToken');
    const userInfo = localStorage.getItem('user');
    
    // Si pas de token, rediriger vers la page de login
    if (!token) {
        // Vérifier si on est déjà sur une page d'authentification
        const currentPath = window.location.pathname;
        if (!currentPath.includes('/auth/')) {
            window.location.href = '../auth/login.html';
        }
        return;
    }
    
    // Mettre à jour l'interface utilisateur
    const userNameElement = document.getElementById('userName');
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (userNameElement && userInfo) {
        try {
            const user = JSON.parse(userInfo);
            userNameElement.textContent = user.name || 'Utilisateur';
        } catch (e) {
            console.error('Erreur lors du parsing des infos utilisateur:', e);
        }
    }
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            // Supprimer le token et les informations utilisateur
            localStorage.removeItem('authToken');
            localStorage.removeItem('user');
            
            // Rediriger vers la page de login
            window.location.href = '../auth/login.html';
        });
    }
});