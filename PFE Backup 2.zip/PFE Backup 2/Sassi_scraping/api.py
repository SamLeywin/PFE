from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Union, Any
import os
import html2text
from urllib.parse import urlparse
from datetime import datetime
import traceback
import json
from elasticsearch import Elasticsearch

from scraper import (
    setup_selenium,
    html_to_markdown_with_readability,
    create_dynamic_listing_model,
    create_listings_container_model,
    format_data,
    save_raw_data,
    save_formatted_data,
    calculate_price
)
from pagination_detector import detect_pagination_elements

app = FastAPI(title="Sassi Scraper API", description="API for scraping websites with pagination support")
from fastapi.middleware.cors import CORSMiddleware

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Elasticsearch client
es = Elasticsearch(["http://localhost:9200"])

class ScrapeRequest(BaseModel):
    urls: List[str]
    fields: List[str]
    model_selection: str = "llama-3.3-70b-versatile"
    pagination_details: Optional[str] = None
    use_pagination: bool = True
    max_pages: int = 3
    product_filter: Optional[str] = None
    max_products: Optional[int] = None
    product_ids: Optional[List[str]] = None
    search_query: Optional[str] = None
    product_id: Optional[str] = None  # New field for product ID

class ScrapeResult(BaseModel):
    url: str
    data: List[Dict]
    pagination_urls: List[str]
    pages_scraped: int
    input_tokens: int
    output_tokens: int
    total_cost: float
    output_folder: str
    search_query: Optional[str] = None
    product_id: Optional[str] = None  # New field
    ideal_price: Optional[float] = None  # New field
    error: Optional[str] = None

class ScrapeResponse(BaseModel):
    results: List[ScrapeResult]
    total_cost: float
    status: str = "success"
    failed_urls: List[Dict[str, str]] = []

async def get_product_name_from_es(product_id: str) -> Optional[str]:
    try:
        # Debug output for troubleshooting
        print(f"Looking up product with ID: {product_id}")
        
        # Make sure we're connecting to the right Elasticsearch instance
        result = es.get(index="products", id=product_id)
        
        # Add debug output
        print(f"Elasticsearch result: {result}")
        
        if "_source" in result and "name" in result["_source"]:
            product_name = result["_source"]["name"]
            print(f"Found product name: {product_name}")
            return product_name
        else:
            print(f"Product found but name is missing: {result}")
            return None
    except Exception as e:
        print(f"Error fetching product name from Elasticsearch: {str(e)}")
        return None
    

async def index_scraping_results(product_id: str, scraping_data: Dict, ideal_price: Optional[float] = None):
    try:
        # S'assurer que les données ne sont pas vides
        if not scraping_data:
            print(f"Warning: Empty scraping data for product {product_id}")
            scraping_data = {"error": "No data found"}
            
        # Formater les données pour qu'elles soient adaptées à Elasticsearch
        document = {
            "product_id": product_id,
            "scraping_data": scraping_data,
            "ideal_price": ideal_price,
            "timestamp": datetime.now().isoformat(),
            "status": "completed"
        }
        
        # Ajouter des logs pour déboguer
        print(f"Indexing scraping results for product {product_id}")
        print(f"Document structure: {json.dumps({'fields': list(document.keys())})}")
        
        # Stocker les données dans Elasticsearch
        result = es.index(index="product_scraping_results", document=document)
        print(f"Successfully indexed scraping results with ID: {result['_id']}")
        
        # Mettre à jour le produit avec la date d'analyse et le prix idéal
        try:
            es.update(
                index="products",
                id=product_id,
                body={
                    "doc": {
                        "last_analysis_date": document["timestamp"],
                        "ideal_price": ideal_price
                    }
                }
            )
            print(f"Updated product {product_id} with analysis results")
        except Exception as e:
            print(f"Error updating product: {str(e)}")
            
    except Exception as e:
        print(f"Error indexing scraping results: {str(e)}")
        traceback.print_exc()

def calculate_ideal_price(prices):
    """Calculate ideal price based on scraped prices - Formule améliorée"""
    if not prices or len(prices) == 0:
        return None
    
    # Trier les prix du plus bas au plus élevé
    sorted_prices = sorted(prices)
    
    # Éliminer les valeurs aberrantes (10% les plus bas et 10% les plus élevés)
    if len(sorted_prices) > 5:
        cutoff_low = int(len(sorted_prices) * 0.1)
        cutoff_high = int(len(sorted_prices) * 0.9)
        filtered_prices = sorted_prices[cutoff_low:cutoff_high]
    else:
        filtered_prices = sorted_prices
    
    if not filtered_prices:
        filtered_prices = sorted_prices
    
    # Calculer la moyenne
    avg_price = sum(filtered_prices) / len(filtered_prices)
    
    # Calculer le prix idéal: légèrement inférieur à la moyenne du marché
    # mais pas trop bas pour maintenir la rentabilité
    market_position = 0.95  # 5% en dessous du marché
    ideal_price = avg_price * market_position
    
    # Arrondir à 3 décimales (millimes)
    return round(ideal_price, 3)

def generate_unique_folder_name(url):
    domain = urlparse(url).netloc.replace("www.", "")
    timestamp = datetime.now().strftime("%Y_%m_%d__%H_%M_%S")
    return f"{domain}_{timestamp}"

@app.post("/scrape", response_model=ScrapeResponse)
async def scrape_endpoint(request: ScrapeRequest):
    print("Incoming request as curl:")
    print(request.json)
    
    try:
        all_results = []
        overall_total_cost = 0.0
        failed_urls = []
        final_ideal_price = None
        
        # Get product name from Elasticsearch if product_id is provided
        search_query = request.search_query
        if request.product_id and not search_query:
            product_name = await get_product_name_from_es(request.product_id)
            if product_name:
                search_query = product_name
                print(f"Using product name from Elasticsearch: {product_name}")

        urls = [
            "https://yousarssif.com",
            "https://vongo.tn",
            "https://tdiscount.tn"
        ]
        
        for url in urls:
            driver = None
            try:
                original_url = url
                if search_query:
                    if '?' in url:
                        url = f"{url}&q={search_query.replace(' ', '+')}"
                    else:
                        domain = urlparse(url).netloc.lower()
                        if 'yousarssif.com' in domain:
                            url = f"{url}/recherche?controller=search&s={search_query.replace(' ', '+')}"
                        elif 'vongo.tn' in domain:
                            url = f"{url}/recherche?controller=search&s={search_query.replace(' ', '+')}"
                        elif 'tdiscount.tn' in domain:
                            url = f"{url}/?s={search_query.replace(' ', '+')}&post_type=product"
                        else:
                            url = f"{url}/search?q={search_query.replace(' ', '+')}"
                
                output_folder = os.path.join('output', generate_unique_folder_name(original_url))
                os.makedirs(output_folder, exist_ok=True)
                
                total_input_tokens = 0
                total_output_tokens = 0
                total_cost = 0
                all_data = []
                pagination_urls = []
                pages_scraped = 0
                
                driver = setup_selenium()
                
                print(f"Scraping initial page: {url}")
                driver.get(url)
                driver.implicitly_wait(15)
                raw_html = driver.page_source
                
                if not raw_html or len(raw_html) < 1000:
                    raise Exception(f"Retrieved HTML is too small or empty: {len(raw_html) if raw_html else 0} bytes")
                
                markdown = html_to_markdown_with_readability(raw_html)
                save_raw_data(markdown, output_folder, f'rawData_1.md')
                pages_scraped += 1
                
                DynamicListingModel = create_dynamic_listing_model(request.fields)
                DynamicListingsContainer = create_listings_container_model(DynamicListingModel)
                
                formatted_data, token_counts = format_data(
                    markdown, 
                    DynamicListingsContainer, 
                    DynamicListingModel,
                    request.model_selection
                )
                
                if isinstance(token_counts, tuple):
                    token_counts = {'input_tokens': token_counts[0], 'output_tokens': token_counts[1]}
                
                page_input_tokens = token_counts.get('input_tokens', 0)
                page_output_tokens = token_counts.get('output_tokens', 0)
                input_tokens, output_tokens, cost = calculate_price(token_counts, request.model_selection)
                total_input_tokens += page_input_tokens
                total_output_tokens += page_output_tokens
                total_cost += cost
                
                save_formatted_data(formatted_data, output_folder, f'sorted_data_1.json', f'sorted_data_1.xlsx')
                
                data_to_add = None
                if hasattr(formatted_data, 'dict'):
                    data_to_add = formatted_data.dict()
                elif isinstance(formatted_data, dict):
                    data_to_add = formatted_data
                else:
                    data_to_add = {"raw": str(formatted_data)}
                
                all_data.append(data_to_add)
                
                if request.use_pagination:
                    print("Detecting pagination...")
                    pagination_data, pagination_token_counts, pagination_price = detect_pagination_elements(
                        url,
                        request.pagination_details,
                        request.model_selection,
                        markdown
                    )

                    if isinstance(pagination_token_counts, tuple):
                        pagination_token_counts = {'input_tokens': pagination_token_counts[0], 'output_tokens': pagination_token_counts[1]}
                    
                    if pagination_data:
                        if hasattr(pagination_data, 'page_urls'):
                            pagination_urls = pagination_data.page_urls
                        else:
                            pagination_urls = pagination_data.get("page_urls", [])
                        
                        total_input_tokens += pagination_token_counts.get('input_tokens', 0)
                        total_output_tokens += pagination_token_counts.get('output_tokens', 0)
                        total_cost += pagination_price
                        
                        pagination_urls = pagination_urls[:request.max_pages]
                        
                        for i, pagination_url in enumerate(pagination_urls, start=2):
                            print(f"Scraping pagination page {i}: {pagination_url}")
                            driver.get(pagination_url)
                            driver.implicitly_wait(15)
                            page_html = driver.page_source
                            page_markdown = html_to_markdown_with_readability(page_html)
                            
                            save_raw_data(page_markdown, output_folder, f'rawData_{i}.md')
                            pages_scraped += 1
                            
                            page_formatted_data, page_token_counts = format_data(
                                page_markdown,
                                DynamicListingsContainer,
                                DynamicListingModel,
                                request.model_selection
                            )

                            if isinstance(page_token_counts, tuple):
                                page_token_counts = {'input_tokens': page_token_counts[0], 'output_tokens': page_token_counts[1]}

                            page_input_tokens = page_token_counts.get('input_tokens', 0)
                            page_output_tokens = page_token_counts.get('output_tokens', 0)
                            page_cost = calculate_price(page_token_counts, request.model_selection)
                            
                            total_input_tokens += page_input_tokens
                            total_output_tokens += page_output_tokens
                            total_cost += page_cost
                            
                            save_formatted_data(
                                page_formatted_data,
                                output_folder,
                                f'sorted_data_{i}.json',
                                f'sorted_data_{i}.xlsx'
                            )
                            
                            if page_formatted_data:
                                if hasattr(page_formatted_data, 'dict'):
                                    all_data.append(page_formatted_data.dict())
                                elif isinstance(page_formatted_data, dict):
                                    all_data.append(page_formatted_data)
                                else:
                                    all_data.append({"raw": str(page_formatted_data)})
                
                # Calculate ideal price if we have product_id
                ideal_price = None
                if request.product_id:
                    # Extraire les prix des données scrapées
                    all_prices = []
                    for data_item in all_data:
                        if isinstance(data_item, dict) and "listings" in data_item:
                            for listing in data_item["listings"]:
                                if "price" in listing:
                                    try:
                                        price = float(listing["price"])
                                        all_prices.append(price)
                                    except (ValueError, TypeError):
                                        continue
                    
                    if all_prices:  # S'assurer qu'il y a des prix à traiter
                        ideal_price = calculate_ideal_price(all_prices)
                        # Stocker le dernier prix idéal calculé
                        final_ideal_price = ideal_price
                        
                    await index_scraping_results(
                        product_id=request.product_id,
                        scraping_data=all_data,
                        ideal_price=ideal_price
                    )

                result = ScrapeResult(
                    url=url,
                    data=all_data,
                    pagination_urls=pagination_urls,
                    pages_scraped=pages_scraped,
                    input_tokens=total_input_tokens,
                    output_tokens=total_output_tokens,
                    total_cost=total_cost,
                    output_folder=output_folder,
                    search_query=search_query if search_query else None,
                    product_id=request.product_id if request.product_id else None,
                    ideal_price=ideal_price
                )
                all_results.append(result)
                overall_total_cost += total_cost
                print(f"Successfully processed URL: {url}")
            
            except Exception as e:
                error_details = traceback.format_exc()
                print(f"Error while processing {url}: {str(e)}\n{error_details}")
                failed_urls.append({"url": url, "error": str(e)})
                
            finally:
                if driver:
                    try:
                        driver.quit()
                    except Exception as e:
                        print(f"Error closing driver: {str(e)}")
                        
        status = "success"
        if failed_urls and not all_results:
            status = "failed"
        elif failed_urls:
            status = f"partial_success ({len(failed_urls)} URLs failed)"
        
        if not all_results and failed_urls:
            print(f"WARNING: Failed to scrape any URLs successfully")
         
        return ScrapeResponse(
            results=all_results,
            total_cost=overall_total_cost,
            status=status,
            failed_urls=failed_urls
        )
   
    except Exception as e:
        error_details = traceback.format_exc()
        print(f"Fatal error in scrape_endpoint: {str(e)}\n{error_details}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "1.0.0"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)