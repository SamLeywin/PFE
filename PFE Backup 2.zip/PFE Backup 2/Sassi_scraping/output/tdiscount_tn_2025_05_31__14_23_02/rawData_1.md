  * [ Accueil  ](https://tdiscount.tn)
/

  * [Shop](https://tdiscount.tn/shop/)
/

  * [Électroménager](https://tdiscount.tn/categorie-produit/electromenager/)

# Électroménager

**1084** Products found

Vue ____

__Filter

  * Tri par popularité
    * [Tri par popularité](https://tdiscount.tn/categorie-produit/electromenager/?orderby=popularity)
    * [Tri par notes moyennes](https://tdiscount.tn/categorie-produit/electromenager/?orderby=rating)
    * [Tri du plus récent au plus ancien](https://tdiscount.tn/categorie-produit/electromenager/?orderby=date)
    * [Tri par tarif croissant](https://tdiscount.tn/categorie-produit/electromenager/?orderby=price)
    * [Tri par tarif décroissant](https://tdiscount.tn/categorie-produit/electromenager/?orderby=price-desc)
  * Cancel

  * [![Micro Onde LG 20 Litres | EasyClean - MS2042DB - Noir](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Micro Onde LG 20 Litres | EasyClean - MS2042DB - Noir](https://tdiscount.tn/wp-content/uploads/2025/01/lg_micro-onde_easyclean_ms2042db-300x300.png)](https://tdiscount.tn/produit/electromenager/gros-electromenager/micro-onde/micro-onde-lg-20-litres-easyclean-ms2042db-noir/)

[__Ajouter au panier](?add-to-cart=47692)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/micro-
onde/micro-onde-lg-20-litres-easyclean-ms2042db-noir/)[ liste de souhaits
](?add-to-wishlist=47692 "liste de souhaits")

[ Compare ](?add_to_compare=47692 "Compare")

## [Micro Onde LG 20 Litres | EasyClean – MS2042DB – Noir](https://tdiscount.tn/produit/electromenager/gros-electromenager/micro-onde/micro-onde-lg-20-litres-easyclean-ms2042db-noir/)

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

Micro-Onde EasyClean™ LG MS2042DB / Volume 20 litres / Puissance : 700 Watts /
Type de Micro-onde est Combiné (micro-onde, Four, Grill), / Puissance Grille
électrique de 1200 Watts , Technologie I-wave et Revêtement EasyClean™ /
Revêtement anti-graisse facile à nettoyer / Cuisson automatique /
Décongélation automatique : 4 (Viande, Poisson, Volaille, Pain) / Type de
porte : Bouton poussoir / Bouton de démarrage rapide / Verrouillage de
sécurité enfants / Bouton de démarrage rapide / Dimensions (455 x 330x 260)mm
/ Garantie 1an. En savoir plus

529.0 DT

[__Ajouter au panier](?add-to-cart=47692)

[ liste de souhaits ](?add-to-wishlist=47692 "liste de souhaits")

[ Compare ](?add_to_compare=47692 "Compare")

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

## [Micro Onde LG 20 Litres | EasyClean – MS2042DB – Noir](https://tdiscount.tn/produit/electromenager/gros-electromenager/micro-onde/micro-onde-lg-20-litres-easyclean-ms2042db-noir/)

529.0 DT

  * [![Pack de 4- Assouplissant 1L x 4 Violet Blanc Bleu Rose](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Pack de 4- Assouplissant 1L x 4 Violet Blanc Bleu Rose](https://tdiscount.tn/wp-content/uploads/2025/01/aso104-300x300.jpg)- 5.0 DT](https://tdiscount.tn/produit/electromenager/hygiene-soin-maison/produit-nettoyage/pack-de-4-assouplissant-1l-x-4-violet-blanc-bleu-rose/)

[ __Ajouter au panier](?add-to-cart=43294)
[__](https://tdiscount.tn/produit/electromenager/hygiene-soin-maison/produit-
nettoyage/pack-de-4-assouplissant-1l-x-4-violet-blanc-bleu-rose/)[ liste de
souhaits ](?add-to-wishlist=43294 "liste de souhaits")

[ Compare ](?add_to_compare=43294 "Compare")

## [Pack de 4- Assouplissant 1L x 4 Violet Blanc Bleu
Rose](https://tdiscount.tn/produit/electromenager/hygiene-soin-maison/produit-
nettoyage/pack-de-4-assouplissant-1l-x-4-violet-blanc-bleu-rose/)

Vendu par :  [Panthère Rose](https://tdiscount.tn/store/panthere-rose/)

    * **Marque :** Panthere rose
    * **Contenance :** 1 litres x 4
    * **Parfum:** florale, océaon,matinal et lavande
    * **Pays de fabrication :** Tunisie

17.5 DT~~22.5 DT~~

[__Ajouter au panier](?add-to-cart=43294)

[ liste de souhaits ](?add-to-wishlist=43294 "liste de souhaits")

[ Compare ](?add_to_compare=43294 "Compare")

Vendu par :  [Panthère Rose](https://tdiscount.tn/store/panthere-rose/)

## [Pack de 4- Assouplissant 1L x 4 Violet Blanc Bleu
Rose](https://tdiscount.tn/produit/electromenager/hygiene-soin-maison/produit-
nettoyage/pack-de-4-assouplissant-1l-x-4-violet-blanc-bleu-rose/)

17.5 DT~~22.5 DT~~

  * [![Mixeur Plongeant 4en1 Hausberg 1,5 L -1500W Blanc](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Mixeur Plongeant 4en1 Hausberg 1,5 L -1500W Blanc](https://tdiscount.tn/wp-content/uploads/2025/01/1-2025-01-11T105540.578-300x300.jpg)- 136.0 DT](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-multifonction/hausberg-mixeur-plongeant-4en1-hb-7710ab-15-l-1500w-fonction-turbo-blanc/)

[ __Ajouter au panier](?add-to-cart=40340)
[__](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-
multifonction/hausberg-mixeur-plongeant-4en1-hb-7710ab-15-l-1500w-fonction-
turbo-blanc/)[ liste de souhaits ](?add-to-wishlist=40340 "liste de souhaits")

[ Compare ](?add_to_compare=40340 "Compare")

## [Mixeur Plongeant 4en1 Hausberg 1,5 L -1500W
Blanc](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-
multifonction/hausberg-mixeur-plongeant-4en1-hb-7710ab-15-l-1500w-fonction-
turbo-blanc/)

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

Ensemble multi-mixeur 4 fonctions : râpe, mixeur, mixeur, hachoir – Couleur:
BLANC – Tige, fil et lames en acier inoxydable – Capacité du bol : 1,5 litres
– Fond antiadhésif – Fonction turbo – Verre pour mesurer les ingrédients
inclus – Puissance : 1500W – Tension : 230V – Fréquence : 50-60Hz -fonction
turbo

163.0 DT~~299.0 DT~~

[__Ajouter au panier](?add-to-cart=40340)

[ liste de souhaits ](?add-to-wishlist=40340 "liste de souhaits")

[ Compare ](?add_to_compare=40340 "Compare")

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

## [Mixeur Plongeant 4en1 Hausberg 1,5 L -1500W
Blanc](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-
multifonction/hausberg-mixeur-plongeant-4en1-hb-7710ab-15-l-1500w-fonction-
turbo-blanc/)

163.0 DT~~299.0 DT~~

  * [![Four Encastrable focus - 56L - Inox](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Four Encastrable focus - 56L - Inox](https://tdiscount.tn/wp-content/uploads/2025/01/four-ventile-focus-f-521x-inox-7programmes-300x300.jpg)- 100.0 DT](https://tdiscount.tn/produit/electromenager/gros-electromenager/four/four-encastrable-b-f-521x-56l-inox-garantie-2ans/)

[ __Ajouter au panier](?add-to-cart=39977)
[__](https://tdiscount.tn/produit/electromenager/gros-
electromenager/four/four-encastrable-b-f-521x-56l-inox-garantie-2ans/)[ liste
de souhaits ](?add-to-wishlist=39977 "liste de souhaits")

[ Compare ](?add_to_compare=39977 "Compare")

## [Four Encastrable focus – 56L –
Inox](https://tdiscount.tn/produit/electromenager/gros-
electromenager/four/four-encastrable-b-f-521x-56l-inox-garantie-2ans/)

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

Four Ventilé

7 programmes

Inox 60 CM

Boutons

56 Litres

Chaleur tournante

Minuterie électronique

Porte froide

Classe Énergétique B

Garantie 2ans

699.0 DT~~799.0 DT~~

[__Ajouter au panier](?add-to-cart=39977)

[ liste de souhaits ](?add-to-wishlist=39977 "liste de souhaits")

[ Compare ](?add_to_compare=39977 "Compare")

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

## [Four Encastrable focus – 56L –
Inox](https://tdiscount.tn/produit/electromenager/gros-
electromenager/four/four-encastrable-b-f-521x-56l-inox-garantie-2ans/)

699.0 DT~~799.0 DT~~

  * [![Plaque encastrable 4 Feux 60 Cm Inox](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Plaque encastrable 4 Feux 60 Cm Inox](https://tdiscount.tn/wp-content/uploads/2025/01/7-7-300x300.jpg)](https://tdiscount.tn/produit/electromenager/gros-electromenager/plaque-de-cuisson/plaque-encastrable-4-feux-60-cm-inox-2/)

[__Ajouter au panier](?add-to-cart=39842)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/plaque-
de-cuisson/plaque-encastrable-4-feux-60-cm-inox-2/)[ liste de souhaits ](?add-
to-wishlist=39842 "liste de souhaits")

[ Compare ](?add_to_compare=39842 "Compare")

## [Plaque encastrable 4 Feux 60 Cm
Inox](https://tdiscount.tn/produit/electromenager/gros-electromenager/plaque-
de-cuisson/plaque-encastrable-4-feux-60-cm-inox-2/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

Table de Cuisson Encastrable Focus – Largeur : 60cm – Nombre de bruleurs : 4
Bruleurs à Gaz – Grilles et chapeaux de brûleurs en fonte – Flamme Stabilisé –
Allumage automatique – Commandes frontales – Couleur : Noir

** Garantie 2ans**

439.0 DT

[__Ajouter au panier](?add-to-cart=39842)

[ liste de souhaits ](?add-to-wishlist=39842 "liste de souhaits")

[ Compare ](?add_to_compare=39842 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [Plaque encastrable 4 Feux 60 Cm
Inox](https://tdiscount.tn/produit/electromenager/gros-electromenager/plaque-
de-cuisson/plaque-encastrable-4-feux-60-cm-inox-2/)

439.0 DT

  * [![SOFPINCE Sèche Linge - Plastique Rotin - Grège & Marron](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![SOFPINCE Sèche Linge - Plastique Rotin - Grège & Marron](https://tdiscount.tn/wp-content/uploads/2025/01/s_che_linge_rotin_sofpince_180_x_52.5_x_109_cm_-_gr_ge_1-300x300.jpg)- 20.0 DT](https://tdiscount.tn/produit/electromenager/gros-electromenager/seche-linge/sofpince-seche-linge-plastique-rotin-grege-marron/)

[ __Ajouter au panier](?add-to-cart=36760)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/seche-
linge/sofpince-seche-linge-plastique-rotin-grege-marron/)[ liste de souhaits
](?add-to-wishlist=36760 "liste de souhaits")

[ Compare ](?add_to_compare=36760 "Compare")

## [SOFPINCE Sèche Linge – Plastique Rotin – Grège &
Marron](https://tdiscount.tn/produit/electromenager/gros-electromenager/seche-
linge/sofpince-seche-linge-plastique-rotin-grege-marron/)

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

    * Matière : Plastique
    * Effet : Rotin
    * Idéal pour l’extérieur
    * marque : SOFPINCE
    * Fabrique en Tunisie

49.0 DT~~69.0 DT~~

[__Ajouter au panier](?add-to-cart=36760)

[ liste de souhaits ](?add-to-wishlist=36760 "liste de souhaits")

[ Compare ](?add_to_compare=36760 "Compare")

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

## [SOFPINCE Sèche Linge – Plastique Rotin – Grège &
Marron](https://tdiscount.tn/produit/electromenager/gros-electromenager/seche-
linge/sofpince-seche-linge-plastique-rotin-grege-marron/)

49.0 DT~~69.0 DT~~

  * [![Whirlpool Congélateur - Horizontal - CF430 A+ - Blanc - 450L - Garantie 2ans](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Whirlpool Congélateur - Horizontal - CF430 A+ - Blanc - 450L - Garantie 2ans](https://tdiscount.tn/wp-content/uploads/2025/01/2-2025-01-04T173520.079-300x300.jpg)- 110.0 DT](https://tdiscount.tn/produit/electromenager/gros-electromenager/congelateur/whirlpool-congelateur-horizontal-cf430-a-blanc-450l-garantie-2ans/)

[ __Ajouter au panier](?add-to-cart=30497)
[__](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/whirlpool-congelateur-horizontal-
cf430-a-blanc-450l-garantie-2ans/)[ liste de souhaits ](?add-to-wishlist=30497
"liste de souhaits")

[ Compare ](?add_to_compare=30497 "Compare")

## [Whirlpool Congélateur – Horizontal – CF430 A+ – Blanc – 450L – Garantie
2ans](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/whirlpool-congelateur-horizontal-
cf430-a-blanc-450l-garantie-2ans/)

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

De forme **horizontale** , le congélateur coffre, aussi appelé congélateur
bahut, s’ouvre par le dessus. Il est dit « posable » car il ne nécessite pas
un support particulier pour être installé.

Malgré l’éventail de tailles proposé, ce congélateur ne peut pas facilement
trouver sa place dans une cuisine car sa largeur est souvent assez importante.
Mais il peut parfaitement intégrer une cave, un sous-sol ou encore un garage.

En ce qui concerne l’intérieur, celui-ci dispose d’un beau volume parfois
compartimenté.

1 589.0 DT~~1 699.0 DT~~

[__Ajouter au panier](?add-to-cart=30497)

[ liste de souhaits ](?add-to-wishlist=30497 "liste de souhaits")

[ Compare ](?add_to_compare=30497 "Compare")

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

## [Whirlpool Congélateur – Horizontal – CF430 A+ – Blanc – 450L – Garantie
2ans](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/whirlpool-congelateur-horizontal-
cf430-a-blanc-450l-garantie-2ans/)

1 589.0 DT~~1 699.0 DT~~

  * [![Friteuse Sans Huile Air fryer - Easy Fry Essential - Tefal Noir](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Friteuse Sans Huile Air fryer - Easy Fry Essential - Tefal Noir](https://tdiscount.tn/wp-content/uploads/2025/01/1-2025-01-04T164402.561-300x300.jpg)- 70.0 DT](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/friteuse/tefal-friteuse-sans-huile-easy-fry-essential-ey130815-air-fryer-noir-garantie-1an/)

[ __Ajouter au panier](?add-to-cart=30478)
[__](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/tefal-friteuse-sans-huile-easy-fry-essential-ey130815-air-
fryer-noir-garantie-1an/)[ liste de souhaits ](?add-to-wishlist=30478 "liste
de souhaits")

[ Compare ](?add_to_compare=30478 "Compare")

## [Friteuse Sans Huile Air fryer – Easy Fry Essential – Tefal
Noir](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/tefal-friteuse-sans-huile-easy-fry-essential-ey130815-air-
fryer-noir-garantie-1an/)

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

Une **friteuse à air** compacte avec une capacité de **3.5 L** pour une
cuisine saine et savoureuse à la maison

Savourez de délicieux repas sains à la maison avec une friteuse à air
polyvalente et facile à utiliser qui garantit des résultats parfaits en un
rien de temps ! En plus d’être économe en énergie, le design compact
n’encombre pas l’espace de votre cuisine, tandis que le panier compatible
lave-vaisselle et le thermostat précis garantissent une cuisson sans stress.
Découvrez la technologie air chaud pour des aliments frits à l’air savoureux
en utilisant moins d’huile ; préparez des frites parfaitement croustillantes,
des légumes et même des desserts.

Des résultats faciles et rapides pour des **repas** sains et délicieux

RAPIDE ET ÉCO-ÉNERGÉTIQUE : Une friteuse à air indispensable pour une cuisson
rapide qui économise plus de 50% d’énergie qu’un four traditionnel

POLYVALENCE : une **friteuse** à air polyvalente conçue pour préparer toutes
vos recettes préférées : des frites parfaitement croustillantes aux légumes,
en passant par un poulet rôti et même des desserts

TECHNOLOGIE AIR CHAUD : une friteuse saine offrant des résultats dorés et
croustillants avec peu ou pas d’huile ; 99 % de matière grasse ajoutée en
moins

ÉLÉMENTS COMPATIBLES LAVE-VAISSELLE : comprend un panier anti-adhésif
compatible lave-vaisselle pour un nettoyage facile et une cuisson sans stress

TRÉGLAGES PRÉCIS : un thermostat très précis et un minuteur (allant jusqu’à
200 °C et 60 minutes, respectivement) garantissent des résultats parfaits,
quel que soit le défi à relever

DESIGN COMPACT : découvrez une friteuse à air compacte dotée d’une capacité de
3.5 L, promettant des repas parfaits et sains pour 2 à 4 personnes

329.0 DT~~399.0 DT~~

[__Ajouter au panier](?add-to-cart=30478)

[ liste de souhaits ](?add-to-wishlist=30478 "liste de souhaits")

[ Compare ](?add_to_compare=30478 "Compare")

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

## [Friteuse Sans Huile Air fryer – Easy Fry Essential – Tefal
Noir](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/tefal-friteuse-sans-huile-easy-fry-essential-ey130815-air-
fryer-noir-garantie-1an/)

329.0 DT~~399.0 DT~~

  * [![Friteuse Sans Huile XXL Faible En Matiéres Grasses- 6L -2400W -Garantie 1 an](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Friteuse Sans Huile XXL Faible En Matiéres Grasses- 6L -2400W -Garantie 1 an](https://tdiscount.tn/wp-content/uploads/2025/01/1-20-300x300.jpg)- 185.1 DT](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/friteuse/friteuse-sans-huile-xxl-faible-en-matieres-grasses-6l-2400w-garantie-1-an/)

[ __Ajouter au panier](?add-to-cart=30067)
[__](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/friteuse-sans-huile-xxl-faible-en-matieres-
grasses-6l-2400w-garantie-1-an/)[ liste de souhaits ](?add-to-wishlist=30067
"liste de souhaits")

[ Compare ](?add_to_compare=30067 "Compare")

## [Friteuse Sans Huile XXL Faible En Matiéres Grasses- 6L -2400W -Garantie 1
an](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/friteuse-sans-huile-xxl-faible-en-matieres-
grasses-6l-2400w-garantie-1-an/)

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

    * Capacité de 6 litres.
    * Taille: 310*270MM
    * Temps de 60 minutes
    * Température variable
    * Bol amovible

139.9 DT~~325.0 DT~~

[__Ajouter au panier](?add-to-cart=30067)

[ liste de souhaits ](?add-to-wishlist=30067 "liste de souhaits")

[ Compare ](?add_to_compare=30067 "Compare")

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

## [Friteuse Sans Huile XXL Faible En Matiéres Grasses- 6L -2400W -Garantie 1
an](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/friteuse-sans-huile-xxl-faible-en-matieres-
grasses-6l-2400w-garantie-1-an/)

139.9 DT~~325.0 DT~~

  * [![Défroisseur à main TEFAL 1300W Vert](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Défroisseur à main TEFAL 1300W Vert](https://tdiscount.tn/wp-content/uploads/2024/12/defroisseur-a-main-tefal-1300w-vert-DT2024E-300x300.jpg)](https://tdiscount.tn/produit/electromenager/hygiene-soin-maison/defroisseur/defroisseur-a-main-tefal-1300w-vert/)

[__Ajouter au panier](?add-to-cart=27686)
[__](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/defroisseur-a-main-tefal-1300w-vert/)[ liste de souhaits
](?add-to-wishlist=27686 "liste de souhaits")

[ Compare ](?add_to_compare=27686 "Compare")

## [Défroisseur à main TEFAL 1300W
Vert](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/defroisseur-a-main-tefal-1300w-vert/)

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

_**Défroisseur à main**_

Puissance : 1300 W

Capacité du réservoir d’eau : 70 ml

Chauffe extrêmement rapide

Usage vertical

Technologie de température optimale

Vapeur : 20g/min

Élimine les cheveux & les poiles

Couleur : Vert

**Garantie : 1 an**

179.0 DT

[__Ajouter au panier](?add-to-cart=27686)

[ liste de souhaits ](?add-to-wishlist=27686 "liste de souhaits")

[ Compare ](?add_to_compare=27686 "Compare")

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

## [Défroisseur à main TEFAL 1300W
Vert](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/defroisseur-a-main-tefal-1300w-vert/)

179.0 DT

  * [![Mixeur Plongeant Kenwood 600W Blanc](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Mixeur Plongeant Kenwood 600W Blanc](https://tdiscount.tn/wp-content/uploads/2024/12/mixeur-plongeant-kenwood-hbm02001wh-600w-blanc-2-300x300.png)](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/mixeur-plongeant/mixeur-plongeant-kenwood-600w-blanc/)

[__Ajouter au panier](?add-to-cart=27423)
[__](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/mixeur-
plongeant/mixeur-plongeant-kenwood-600w-blanc/)[ liste de souhaits ](?add-to-
wishlist=27423 "liste de souhaits")

[ Compare ](?add_to_compare=27423 "Compare")

## [Mixeur Plongeant Kenwood 600W
Blanc](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/mixeur-
plongeant/mixeur-plongeant-kenwood-600w-blanc/)

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

Puissance : 600W

Nombre de vitesses : 2 vitesses

Capacité du bol : 0.5L

Performances optimales pour un mélange sans effort

Poignée texturée

Confortable et facile à saisir lors de la manipulation

Fonctionnement plus pratique

Matière : Inox + Plastique

Poids : 1.1kg

Couleur : Blanc

**Garantie 1 an**

108.0 DT

[__Ajouter au panier](?add-to-cart=27423)

[ liste de souhaits ](?add-to-wishlist=27423 "liste de souhaits")

[ Compare ](?add_to_compare=27423 "Compare")

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

## [Mixeur Plongeant Kenwood 600W
Blanc](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/mixeur-
plongeant/mixeur-plongeant-kenwood-600w-blanc/)

108.0 DT

  * [![Congélateur150l horizontal newstar - defrost - blanc](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Congélateur150l horizontal newstar - defrost - blanc](https://tdiscount.tn/wp-content/uploads/2024/12/auvwzb_1721809871-300x300.jpg)](https://tdiscount.tn/produit/electromenager/gros-electromenager/congelateur/congelateur-150l-horizontal-newstar-cg180-defrost-blanc/)

[__Ajouter au panier](?add-to-cart=14623)
[__](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/congelateur-150l-horizontal-newstar-cg180-defrost-
blanc/)[ liste de souhaits ](?add-to-wishlist=14623 "liste de souhaits")

[ Compare ](?add_to_compare=14623 "Compare")

## [Congélateur150l horizontal newstar – defrost –
blanc](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/congelateur-150l-horizontal-newstar-cg180-defrost-
blanc/)

Vendu par :  [AC SPACE](https://tdiscount.tn/store/ac-space/)

Congélateur horizontal newstar cg180  
– système de refroidissement: defrost  
– capacité: 150 litres  
– classe énergétique: a+  
– dégivrage manuel  
– 1 panier  
– pieds réglables  
– alimentation: 220-240 / 50hz  
– dimensions: 84.5 x 76 x 56 cm  
– couleur: blanc  
– garantie: 1an

815.0 DT

[__Ajouter au panier](?add-to-cart=14623)

[ liste de souhaits ](?add-to-wishlist=14623 "liste de souhaits")

[ Compare ](?add_to_compare=14623 "Compare")

Vendu par :  [AC SPACE](https://tdiscount.tn/store/ac-space/)

## [Congélateur150l horizontal newstar – defrost –
blanc](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/congelateur-150l-horizontal-newstar-cg180-defrost-
blanc/)

815.0 DT

  * [![ORIENT HOTTE CASQUETTE 60CM INOX-OH-CLASSICO-60XS](https://tdiscount.tn/wp-content/uploads/2024/10/hotte-casquette-orient-60-cm-silver-300x300.jpg)![ORIENT HOTTE CASQUETTE 60CM INOX-OH-CLASSICO-60XS](https://tdiscount.tn/wp-content/uploads/2024/10/hotte-casquette-orient-60-cm-silver-300x300.jpg)](https://tdiscount.tn/produit/electromenager/gros-electromenager/hotte-cuisine/orient-hotte-casquette-60cm-inox-oh-classico-60xs/)

[__Ajouter au panier](?add-to-cart=4778)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/hotte-
cuisine/orient-hotte-casquette-60cm-inox-oh-classico-60xs/)[ liste de souhaits
](?add-to-wishlist=4778 "liste de souhaits")

[ Compare ](?add_to_compare=4778 "Compare")

## [ORIENT HOTTE CASQUETTE 60CM INOX-OH-
CLASSICO-60XS](https://tdiscount.tn/produit/electromenager/gros-
electromenager/hotte-cuisine/orient-hotte-casquette-60cm-inox-oh-
classico-60xs/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

    * Hotte aspirante Casquette sous meuble Orient – Largeur: 60 cm – Puissance totale 220 W – Puissance moteur : 95W – Puissance lampe : 2x 15 W – Tension d’alimentation : 220/240 V – Fréquence d’alimentation : 50 Hz – Ampérage : 1.5 A – Renouvellement d’air: 280m³/h – Deux filtres métalliques lavables – Visière en verre – Commande à boutons poussoirs – Sélecteur de puissance à vitesses – Deux lampes – Dimension Nette 510 x 620 x 150 – Poids 6 kg – Garantie 1 an

175.0 DT

[__Ajouter au panier](?add-to-cart=4778)

[ liste de souhaits ](?add-to-wishlist=4778 "liste de souhaits")

[ Compare ](?add_to_compare=4778 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [ORIENT HOTTE CASQUETTE 60CM INOX-OH-
CLASSICO-60XS](https://tdiscount.tn/produit/electromenager/gros-
electromenager/hotte-cuisine/orient-hotte-casquette-60cm-inox-oh-
classico-60xs/)

175.0 DT

  * [![](https://tdiscount.tn/wp-content/uploads/2025/05/climatiseur_gree_tropicalis_18000btu_chaud___froid_-_garantie_3_ans-1-300x300.webp)![](https://tdiscount.tn/wp-content/uploads/2025/05/climatiseur_gree_tropicalis_18000btu_chaud___froid_-_garantie_3_ans-1-300x300.webp)New](https://tdiscount.tn/produit/electromenager/climatiseur/climatiseur-gree-tropicalise-24000btu-chaud-froid-garantie-3ans/)

[ __Ajouter au panier](?add-to-cart=72326)
[__](https://tdiscount.tn/produit/electromenager/climatiseur/climatiseur-gree-
tropicalise-24000btu-chaud-froid-garantie-3ans/)[ liste de souhaits ](?add-to-
wishlist=72326 "liste de souhaits")

[ Compare ](?add_to_compare=72326 "Compare")

## [Climatiseur GREE Tropicalisé 24000BTU Chaud-Froid – Garantie
3ans](https://tdiscount.tn/produit/electromenager/climatiseur/climatiseur-
gree-tropicalise-24000btu-chaud-froid-garantie-3ans/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

Climatiseur GREE Tropicalisé – Capacité: 24000 BTU – Mode : Chaud & Froid –
Classe énergétique: 1 – Superficie: 50-70m² – Mode Turbo – Ultra Silencieux –
Fonction « I feel » – Respecte l’environnement – Consommation minimale
d’énergie – Résiste aux températures Extrêmes – 7 vitesses de ventilation –
Niveau Sonore 63 – Nettoyage automatique- Couleur : Blanc – **Garantie : 3 ans
( Garantie compresseur 6 ans)**

2 999.0 DT

[__Ajouter au panier](?add-to-cart=72326)

[ liste de souhaits ](?add-to-wishlist=72326 "liste de souhaits")

[ Compare ](?add_to_compare=72326 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [Climatiseur GREE Tropicalisé 24000BTU Chaud-Froid – Garantie
3ans](https://tdiscount.tn/produit/electromenager/climatiseur/climatiseur-
gree-tropicalise-24000btu-chaud-froid-garantie-3ans/)

2 999.0 DT

  * [![](https://tdiscount.tn/wp-content/uploads/2025/05/climatiseur_gree_tropicalis_18000btu_chaud___froid_-_garantie_3_ans-300x300.webp)![](https://tdiscount.tn/wp-content/uploads/2025/05/climatiseur_gree_tropicalis_18000btu_chaud___froid_-_garantie_3_ans-300x300.webp)- 250.0 DT](https://tdiscount.tn/produit/electromenager/climatiseur/climatiseur-gree-tropicalise-18000btu-chaud-froid-garantie-3-ans/)

[ __Ajouter au panier](?add-to-cart=72322)
[__](https://tdiscount.tn/produit/electromenager/climatiseur/climatiseur-gree-
tropicalise-18000btu-chaud-froid-garantie-3-ans/)[ liste de souhaits ](?add-
to-wishlist=72322 "liste de souhaits")

[ Compare ](?add_to_compare=72322 "Compare")

## [Climatiseur GREE Tropicalisé 18000BTU Chaud – Froid – Garantie 3
ans](https://tdiscount.tn/produit/electromenager/climatiseur/climatiseur-gree-
tropicalise-18000btu-chaud-froid-garantie-3-ans/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

Climatiseur GREE Tropicalisé Chaud/Froid – Puissance: 18000 BTU – Réfrigérant
R410a – Classe énergétique: 2 – Mode Turbo – Ultra Silencieux – Superficie:
35-50m² – Fonction: I feel – Respecte l’environnement – Consommation minimale
d’énergie – Dimension Unité Intérieure 270 x 785 x 198mm – Dimension Unité
Extérieure 540 x 710 x 255 mm – **Garantie: 3 ans ( 6 ans de garantie sur le
compresseur)**

2 129.0 DT~~2 379.0 DT~~

[__Ajouter au panier](?add-to-cart=72322)

[ liste de souhaits ](?add-to-wishlist=72322 "liste de souhaits")

[ Compare ](?add_to_compare=72322 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [Climatiseur GREE Tropicalisé 18000BTU Chaud – Froid – Garantie 3
ans](https://tdiscount.tn/produit/electromenager/climatiseur/climatiseur-gree-
tropicalise-18000btu-chaud-froid-garantie-3-ans/)

2 129.0 DT~~2 379.0 DT~~

  * [![Barbecue à Charbon SOMAGIC Mykonos - Noir](https://tdiscount.tn/wp-content/uploads/2025/05/3292193851331-1-300x300.jpeg)![Barbecue à Charbon SOMAGIC Mykonos - Noir](https://tdiscount.tn/wp-content/uploads/2025/05/3292193851331-1-300x300.jpeg)- 100.0 DT](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/barbecue/barbecue-a-charbon-somagic-mykonos-noir/)

[ __Ajouter au panier](?add-to-cart=71972)
[__](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/barbecue/barbecue-a-charbon-somagic-mykonos-noir/)[ liste de souhaits
](?add-to-wishlist=71972 "liste de souhaits")

[ Compare ](?add_to_compare=71972 "Compare")

## [Barbecue à Charbon SOMAGIC Mykonos –
Noir](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/barbecue/barbecue-a-charbon-somagic-mykonos-noir/)

Vendu par :  [FUEGO STORE](https://tdiscount.tn/store/fuego-store/)

Le Barbecue à Charbon SOMAGIC Mykonos est un modèle pratique et robuste conçu
pour des grillades conviviales en extérieur. Sa cuve en fonte de 52 x 37,5 cm
assure une excellente répartition de la chaleur. Il dispose d’un parevent en
acier laqué et d’une grille réglable pour une cuisson maîtrisée. Son chariot
stable avec roues facilite le déplacement et son coloris noir lui donne un
style élégant

480.0 DT~~580.0 DT~~

[__Ajouter au panier](?add-to-cart=71972)

[ liste de souhaits ](?add-to-wishlist=71972 "liste de souhaits")

[ Compare ](?add_to_compare=71972 "Compare")

Vendu par :  [FUEGO STORE](https://tdiscount.tn/store/fuego-store/)

## [Barbecue à Charbon SOMAGIC Mykonos –
Noir](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/barbecue/barbecue-a-charbon-somagic-mykonos-noir/)

480.0 DT~~580.0 DT~~

  * [![Barbecue à Charbon SOMAGIC ROYAN- Noir](https://tdiscount.tn/wp-content/uploads/2025/05/1-2-300x300.png)![Barbecue à Charbon SOMAGIC ROYAN- Noir](https://tdiscount.tn/wp-content/uploads/2025/05/1-2-300x300.png)- 60.0 DT](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/barbecue/barbecue-a-charbon-somagic-royan-noir/)

[ __Ajouter au panier](?add-to-cart=71970)
[__](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/barbecue/barbecue-a-charbon-somagic-royan-noir/)[ liste de souhaits
](?add-to-wishlist=71970 "liste de souhaits")

[ Compare ](?add_to_compare=71970 "Compare")

## [Barbecue à Charbon SOMAGIC ROYAN-
Noir](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/barbecue/barbecue-a-charbon-somagic-royan-noir/)

Vendu par :  [FUEGO STORE](https://tdiscount.tn/store/fuego-store/)

Barbecue à charbon de bois -Cuve en fonte 52 x 37,5 cm – _Dimensions hors tout
: 75 x 52 x 85 cm_

320.0 DT~~380.0 DT~~

[__Ajouter au panier](?add-to-cart=71970)

[ liste de souhaits ](?add-to-wishlist=71970 "liste de souhaits")

[ Compare ](?add_to_compare=71970 "Compare")

Vendu par :  [FUEGO STORE](https://tdiscount.tn/store/fuego-store/)

## [Barbecue à Charbon SOMAGIC ROYAN-
Noir](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/barbecue/barbecue-a-charbon-somagic-royan-noir/)

320.0 DT~~380.0 DT~~

  * [![Congélateur Vertical Hisense RS-34W 262 Litres - Silver](https://tdiscount.tn/wp-content/uploads/2025/05/123-300x300.webp)![Congélateur Vertical Hisense RS-34W 262 Litres - Silver](https://tdiscount.tn/wp-content/uploads/2025/05/123-300x300.webp)- 100.0 DT](https://tdiscount.tn/produit/electromenager/gros-electromenager/congelateur/congelateur-vertical-hisense-rs-34w-262-litres-silver/)

[ __Ajouter au panier](?add-to-cart=71795)
[__](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/congelateur-vertical-hisense-rs-34w-262-litres-
silver/)[ liste de souhaits ](?add-to-wishlist=71795 "liste de souhaits")

[ Compare ](?add_to_compare=71795 "Compare")

## [Congélateur Vertical Hisense RS-34W 262 Litres –
Silver](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/congelateur-vertical-hisense-rs-34w-262-litres-
silver/)

Vendu par :  [MG ELECTRO](https://tdiscount.tn/store/mg-electro/)

Congélateur Vertical HISENSE – Système de Refroidissement: Nofrost – Volume:
262 Litres – Capacité de congélation: 20 kg/24h – Classe énergétique: A+ –
Stockage froid autonome: 12 h – Nombre de tiroirs de congélation: 7 tiroirs –
Avec Afficheur digital – R600a – Niveau de bruit: 42 dB – Avec Poignée –
Dimensions: 185.5 x 59.5 x 71.2 cm – Couleur: Silver – **Garantie: 1 an**

1 799.0 DT~~1 899.0 DT~~

[__Ajouter au panier](?add-to-cart=71795)

[ liste de souhaits ](?add-to-wishlist=71795 "liste de souhaits")

[ Compare ](?add_to_compare=71795 "Compare")

Vendu par :  [MG ELECTRO](https://tdiscount.tn/store/mg-electro/)

## [Congélateur Vertical Hisense RS-34W 262 Litres –
Silver](https://tdiscount.tn/produit/electromenager/gros-
electromenager/congelateur/congelateur-vertical-hisense-rs-34w-262-litres-
silver/)

1 799.0 DT~~1 899.0 DT~~

  * [![Tristar CM-2300 Machine à café capsule](https://tdiscount.tn/wp-content/uploads/2025/05/cm-2300_0-300x300.jpg)![Tristar CM-2300 Machine à café capsule](https://tdiscount.tn/wp-content/uploads/2025/05/cm-2300_0-300x300.jpg)](https://tdiscount.tn/produit/electromenager/machine-a-cafe/tristar-cm-2300-machine-a-cafe-capsule/)

[__Ajouter au panier](?add-to-cart=71488)
[__](https://tdiscount.tn/produit/electromenager/machine-a-cafe/tristar-
cm-2300-machine-a-cafe-capsule/)[ liste de souhaits ](?add-to-wishlist=71488
"liste de souhaits")

[ Compare ](?add_to_compare=71488 "Compare")

## [Tristar CM-2300 Machine à café
capsule](https://tdiscount.tn/produit/electromenager/machine-a-cafe/tristar-
cm-2300-machine-a-cafe-capsule/)

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

Élevez votre rituel quotidien du café à de nouveaux sommets avec la machine à
café à capsules Tristar CM-2300 – un véritable révolutionnaire dans le monde
des amateurs de café. Cette cafetière combine une saveur inégalée, une
compatibilité avec les capsules Nespresso, une puissante pompe haute

399.0 DT

[__Ajouter au panier](?add-to-cart=71488)

[ liste de souhaits ](?add-to-wishlist=71488 "liste de souhaits")

[ Compare ](?add_to_compare=71488 "Compare")

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

## [Tristar CM-2300 Machine à café
capsule](https://tdiscount.tn/produit/electromenager/machine-a-cafe/tristar-
cm-2300-machine-a-cafe-capsule/)

399.0 DT

  * [![Fondue électrique SEVERIN FO2470- 1500 Watt en Acier Inoxydable - Noir](https://tdiscount.tn/wp-content/uploads/2025/05/fondue-electrique-severin-1500-watt-en-acier-inoxydable-noir-fo2470-300x300.webp)![Fondue électrique SEVERIN FO2470- 1500 Watt en Acier Inoxydable - Noir](https://tdiscount.tn/wp-content/uploads/2025/05/fondue-electrique-severin-1500-watt-en-acier-inoxydable-noir-fo2470-300x300.webp)- 84.0 DT](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/fondue-electrique-severin-fo2470-1500-watt-en-acier-inoxydable-noir/)

[ __Ajouter au panier](?add-to-cart=71455)
[__](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/fondue-
electrique-severin-fo2470-1500-watt-en-acier-inoxydable-noir/)[ liste de
souhaits ](?add-to-wishlist=71455 "liste de souhaits")

[ Compare ](?add_to_compare=71455 "Compare")

## [Fondue électrique SEVERIN FO2470- 1500 Watt en Acier Inoxydable –
Noir](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/fondue-
electrique-severin-fo2470-1500-watt-en-acier-inoxydable-noir/)

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

Fondue électrique en acier +8 fourchettes à code couleur et protection
antiéclaboussures amovible, passe au lave-vaisselle, câble extra long, max
1500W Manipulation confortable La casserole électrique est amovible/chauffée
avec le thermostat en continu Câble extra long pour plus de flexibilité.
Facile à nettoyer Étant donné que toutes les pièces amovibles passent au lave-
vaisselle – **Garantie : 1 an**

221.0 DT~~305.0 DT~~

[__Ajouter au panier](?add-to-cart=71455)

[ liste de souhaits ](?add-to-wishlist=71455 "liste de souhaits")

[ Compare ](?add_to_compare=71455 "Compare")

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

## [Fondue électrique SEVERIN FO2470- 1500 Watt en Acier Inoxydable –
Noir](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/fondue-
electrique-severin-fo2470-1500-watt-en-acier-inoxydable-noir/)

221.0 DT~~305.0 DT~~

  * [__Page précédente](https://tdiscount.tn/categorie-produit/electromenager/page/1/)
  * [1](https://tdiscount.tn/categorie-produit/electromenager/page/1/)
  * 2
  * [3](https://tdiscount.tn/categorie-produit/electromenager/page/3/)
  * [4](https://tdiscount.tn/categorie-produit/electromenager/page/4/)
  * [5](https://tdiscount.tn/categorie-produit/electromenager/page/5/)
  * …
  * [53](https://tdiscount.tn/categorie-produit/electromenager/page/53/)
  * [54](https://tdiscount.tn/categorie-produit/electromenager/page/54/)
  * [55](https://tdiscount.tn/categorie-produit/electromenager/page/55/)
  * [Page suivante __](https://tdiscount.tn/categorie-produit/electromenager/page/3/)

Categories

  * [All Categories](https://tdiscount.tn/shop/)
  * [Électroménager](https://tdiscount.tn/categorie-produit/electromenager/)
  * [Appareil de cuisson](https://tdiscount.tn/categorie-produit/electromenager/appareil-de-cuisson/)
  * [Autre petit électroménager](https://tdiscount.tn/categorie-produit/electromenager/autre-petit-electromenager/)
  * [Climatiseur](https://tdiscount.tn/categorie-produit/electromenager/climatiseur/)
  * [Gros électroménager](https://tdiscount.tn/categorie-produit/electromenager/gros-electromenager/)
  * [Hygiène & soin maison](https://tdiscount.tn/categorie-produit/electromenager/hygiene-soin-maison/)
  * [Lave vaisselle](https://tdiscount.tn/categorie-produit/electromenager/lave-vaisselle/)
  * [Machine à café](https://tdiscount.tn/categorie-produit/electromenager/machine-a-cafe/)
  * [Machine à laver](https://tdiscount.tn/categorie-produit/electromenager/machine-a-laver/)
  * [Réfrigérateur](https://tdiscount.tn/categorie-produit/electromenager/refrigerateurs/)
  * [Robot de cuisine](https://tdiscount.tn/categorie-produit/electromenager/robot-de-cuisine/)

By Brands

  * [Acer](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=acer) (1)
  * [Ariston](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=ariston) (31)
  * [Arnica](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=arnica) (3)
  * [Arzum](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=arzum) (17)
  * [BEPER](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=beper) (2)
  * [Biolux](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=biolux) (1)
  * [BLACK&DECKER](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=blackdecker) (1)
  * [BOMANN](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=bomann) (2)
  * [Bosch](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=bosch) (1)
  * [BRANDT](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=brandt) (5)
  * [Braun](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=braun) (44)
  * [CAFÈ ROVI](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=cafe-rovi) (1)
  * [Candy](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=candy) (3)
  * [CLATRONIC](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=clatronic) (3)
  * [COALA](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=coala) (12)
  * [Condor](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=condor) (19)
  * [DESSINI](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=dessini) (1)
  * [dracoss](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=dracoss) (4)
  * [Dysis](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=dysis) (2)
  * [FAKIR](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=fakir) (9)
  * [Fiorillo](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=fiorillo) (2)
  * [Florence](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=florence) (7)
  * [FLORIA](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=floria) (2)
  * [FOCUS](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=focus) (114)
  * [GALANZ](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=galanz) (17)
  * [Gree](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=gree) (11)
  * [Hausberg](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=hausberg) (2)
  * [Hisense](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=hisense) (1)
  * [Hoover](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=hoover) (4)
  * [Joker](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=joker) (14)
  * [Joyroom](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=joyroom) (11)
  * [KÄRCHER](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=karcher) (11)
  * [KENWOOD](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=kenwood) (24)
  * [KIWI](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=kiwi) (45)
  * [KORKMAZ](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=korkmaz) (9)
  * [Kumtel](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=kumtel) (1)
  * [LEXICAL](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=lexical) (30)
  * [LG](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=lg) (33)
  * [LIVOO](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=livoo) (3)
  * [Luxell](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=luxell) (3)
  * [MAGEFESA](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=magefesa) (3)
  * [Magimix](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=magimix) (1)
  * [Midea](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=midea) (5)
  * [MOULINEX](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=moulinex) (2)
  * [Orient](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=orient) (1)
  * [Panthère Rose](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=panthere-rose) (45)
  * [Perfect bio](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=perfect-bio) (9)
  * [Perilla](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=perilla) (1)
  * [Philips](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=philips) (3)
  * [Premium](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=premium) (15)
  * [PRINCESS](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=princess) (37)
  * [RAF](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=raf) (2)
  * [RUSSELL HOBBS](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=russell-hobbs) (9)
  * [Saba](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=saba) (6)
  * [Samsung](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=samsung) (22)
  * [SEG](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=seg) (13)
  * [SEVERIN](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=severin) (13)
  * [Silver Crest](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=silver-crest) (1)
  * [Silverline](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=silverline) (3)
  * [SINBO](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=sinbo) (8)
  * [SOFPINCE](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=sofpince) (1)
  * [Sokany](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=sokany) (2)
  * [Somagic](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=somagic) (7)
  * [TCL](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tcl) (2)
  * [Techwood](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=techwood) (49)
  * [TEFAL](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tefal) (27)
  * [Telefunken](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=telefunken) (32)
  * [Topmatic](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=topmatic) (17)
  * [Tornado](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tornado) (2)
  * [TRISTAR](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tristar) (76)
  * [TVS](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tvs) (1)
  * [ufesa](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=ufesa) (12)
  * [Westinghouse](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=westinghouse) (1)
  * [WHIRLPOOL](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=whirlpool) (2)
  * [Whirlpool ](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=whirlpool-2) (2)

By price

Prix min Prix max Filtrer

Prix :  —

Volume

  * [0 - 300 Litres](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=0-300-litres) (3)
  * [301 - 400 Litres](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=301-400-litres) (4)
  * [401 – 500 Litres](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=401-500-litres) (11)
  * [501 - 600 Litres](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=501-600-litres) (2)
  * [600 et plus](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=600-et-plus) (3)

Tour par minute

  * [1000 - 1200 tr/min](https://tdiscount.tn/categorie-produit/electromenager/?filter_tours-par-minute=1000-1200-tr-min) (13)
  * [1200– 1400 tr/min](https://tdiscount.tn/categorie-produit/electromenager/?filter_tours-par-minute=1200-1400-tr-min) (11)
  * [1400 - 1600 tr/min](https://tdiscount.tn/categorie-produit/electromenager/?filter_tours-par-minute=1400-1600-tr-min) (14)
  * [600 - 800 tr/min](https://tdiscount.tn/categorie-produit/electromenager/?filter_tours-par-minute=600-800-tr-min) (4)

Type de porte

  * [Combiné](https://tdiscount.tn/categorie-produit/electromenager/?filter_type-de-porte=combine) (5)
  * [Double Portes](https://tdiscount.tn/categorie-produit/electromenager/?filter_type-de-porte=double-portes) (10)
  * [Side By Side](https://tdiscount.tn/categorie-produit/electromenager/?filter_type-de-porte=side-by-side) (5)
  * [Une Porte](https://tdiscount.tn/categorie-produit/electromenager/?filter_type-de-porte=une-porte) (2)

Capacite de lavage

  * [13 - 18+ kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=13-18-kg) (2)
  * [6 - 8 kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=6-8-kg) (17)
  * [6 kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=6) (1)
  * [8 Kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=8) (1)
  * [9 - 12 kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=9-12-kg) (22)

Systeme de refroidissement

  * [DeFrost](https://tdiscount.tn/categorie-produit/electromenager/?filter_systeme-de-refroidissement=defrost) (3)
  * [Less Frost](https://tdiscount.tn/categorie-produit/electromenager/?filter_systeme-de-refroidissement=less-frost) (2)
  * [NoFrost](https://tdiscount.tn/categorie-produit/electromenager/?filter_systeme-de-refroidissement=nofrost) (17)

Nombre de portes

  * [1](https://tdiscount.tn/categorie-produit/electromenager/?filter_nombre-de-portes=1) (3)
  * [2](https://tdiscount.tn/categorie-produit/electromenager/?filter_nombre-de-portes=2) (15)
  * [4](https://tdiscount.tn/categorie-produit/electromenager/?filter_nombre-de-portes=4) (2)

__

__

## Main Menu

__

  * [__Électroménager](https://tdiscount.tn/categorie-produit/electromenager/)
  * [__Téléphonie & Tablette](https://tdiscount.tn/categorie-produit/telephonie-tablette/)
  * [__TV Image & Son](https://tdiscount.tn/categorie-produit/tv-image-son/)
  * [__Chaussures & Vêtements](https://tdiscount.tn/categorie-produit/vetements-et-accessoires/)
  * [__Hygiène & Soin](https://tdiscount.tn/categorie-produit/electromenager/hygiene-soin-maison/)
  * [__Maison et Bricolage](https://tdiscount.tn/categorie-produit/autres-categories/maison-et-bricolage/)
  * [__Informatique](https://tdiscount.tn/categorie-produit/informatique/)
  * [__Jeu vidéo & Console](https://tdiscount.tn/categorie-produit/gaming/jeu-video-console/)
  * [__Gaming](https://tdiscount.tn/categorie-produit/gaming/)
  * [__Sport et Loisir](https://tdiscount.tn/categorie-produit/autres-categories/sport-et-loisir/)
  * [__Animalerie](https://tdiscount.tn/categorie-produit/autres-categories/animalerie/)
  * [Autres catégories](https://tdiscount.tn/categorie-produit/autres-categories/)

___×_

Compare products

Close

Activer les notifications D'accord  Non Merci

![](https://www.facebook.com/tr?id=3918057461794796&ev=PageView&noscript=1)

