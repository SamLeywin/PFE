  * [ Accueil  ](https://tdiscount.tn)
/

  * [Shop](https://tdiscount.tn/shop/)

**11** Products found

Vue ____

__Filter

  * Pertinence
    * [Pertinence](https://tdiscount.tn/shop/?orderby=relevance&s=Lampe%20de%20table%20LED&post_type=product)
    * [Tri par popularité](https://tdiscount.tn/shop/?orderby=popularity&s=Lampe%20de%20table%20LED&post_type=product)
    * [Tri par notes moyennes](https://tdiscount.tn/shop/?orderby=rating&s=Lampe%20de%20table%20LED&post_type=product)
    * [Tri du plus récent au plus ancien](https://tdiscount.tn/shop/?orderby=date&s=Lampe%20de%20table%20LED&post_type=product)
    * [Tri par tarif croissant](https://tdiscount.tn/shop/?orderby=price&s=Lampe%20de%20table%20LED&post_type=product)
    * [Tri par tarif décroissant](https://tdiscount.tn/shop/?orderby=price-desc&s=Lampe%20de%20table%20LED&post_type=product)
  * Cancel

  * [![Lampe LED RGB De 16 Couleurs Avec Commande 7 W](https://tdiscount.tn/wp-content/uploads/2025/03/led-RGB-300x300.jpg)- 6.1 DT](https://tdiscount.tn/produit/autres-categories/maison-et-bricolage/maison/lampe-decorative/lampe-led-rgb-de-16-couleurs-avec-commande-7-w/)

[ __Ajouter au panier](?add-to-cart=66015)
[__](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/maison/lampe-decorative/lampe-led-rgb-de-16-couleurs-avec-
commande-7-w/)[ liste de souhaits ](?add-to-wishlist=66015 "liste de
souhaits")

[ Compare ](?add_to_compare=66015 "Compare")

## [Lampe LED RGB De 16 Couleurs Avec Commande 7
W](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/maison/lampe-decorative/lampe-led-rgb-de-16-couleurs-avec-
commande-7-w/)

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

Type: ampoule de LED de RGBW -Matériau: aluminium Aviation, plastique -Couleur
de l’article: argent, blanc- Couleur de la lumière: 16 couleurs -Mode :4 modes
d’éclairage -Puissance: 7 W -Température de couleur: blanc froid 5700 K, blanc
chaud 2700 K -Angle de faisceau: 270 degrés -Type de douille: E27 -Tension
d’entrée: ca 85-265 V 50-60Hz -Méthode de contrôle: télécommande
IR/interrupteur mural -Fonction de télécommande IR: marche/arrêt, Dim up/down,
Flash, stroboscope, lisse

18.9 DT~~25.0 DT~~

[__Ajouter au panier](?add-to-cart=66015)

[ liste de souhaits ](?add-to-wishlist=66015 "liste de souhaits")

[ Compare ](?add_to_compare=66015 "Compare")

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

## [Lampe LED RGB De 16 Couleurs Avec Commande 7
W](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/maison/lampe-decorative/lampe-led-rgb-de-16-couleurs-avec-
commande-7-w/)

18.9 DT~~25.0 DT~~

  * [![Gants Avec 2 Lampes Lumineux](https://tdiscount.tn/wp-content/uploads/2025/01/Gants-Avec-2-Lampes-Lumineux-300x300.jpg)- 8.0 DT](https://tdiscount.tn/produit/autres-categories/maison-et-bricolage/bricolage/multiprises-enrouleur-lampe/gants-avec-2-lampes-lumineux/)

[ __Ajouter au panier](?add-to-cart=53848)
[__](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/bricolage/multiprises-enrouleur-lampe/gants-avec-2-lampes-
lumineux/)[ liste de souhaits ](?add-to-wishlist=53848 "liste de souhaits")

[ Compare ](?add_to_compare=53848 "Compare")

## [Gants Avec 2 Lampes Lumineux](https://tdiscount.tn/produit/autres-
categories/maison-et-bricolage/bricolage/multiprises-enrouleur-lampe/gants-
avec-2-lampes-lumineux/)

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

    * Deux LED de 5 000 mcd.
    * Alimenté avec Composition des cellules de la batterie Lithium.
    * Nombre de piles : 2 piles CR2 Tension 3 Volts
    * Éclairez là où vous en avez besoin.
    * Ajustement confortable avec néoprène noir de 0,5 mm.

Gants avec 2 Lampes Lumineux péche doit être acheté par multiple de 1

22.0 DT~~30.0 DT~~

[__Ajouter au panier](?add-to-cart=53848)

[ liste de souhaits ](?add-to-wishlist=53848 "liste de souhaits")

[ Compare ](?add_to_compare=53848 "Compare")

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

## [Gants Avec 2 Lampes Lumineux](https://tdiscount.tn/produit/autres-
categories/maison-et-bricolage/bricolage/multiprises-enrouleur-lampe/gants-
avec-2-lampes-lumineux/)

22.0 DT~~30.0 DT~~

  * [![LAPDESK de pc portable 2 en 1](https://tdiscount.tn/wp-content/uploads/2025/01/lapdesk-300x300.jpg)- 26.0 DT](https://tdiscount.tn/produit/informatique/accessoires-informatique/mallette-housse-sac-a-dos/lapdesk-de-pc-portable-2-en-1/)

[ __Ajouter au panier](?add-to-cart=51593)
[__](https://tdiscount.tn/produit/informatique/accessoires-
informatique/mallette-housse-sac-a-dos/lapdesk-de-pc-portable-2-en-1/)[ liste
de souhaits ](?add-to-wishlist=51593 "liste de souhaits")

[ Compare ](?add_to_compare=51593 "Compare")

## [LAPDESK de pc portable 2 en
1](https://tdiscount.tn/produit/informatique/accessoires-
informatique/mallette-housse-sac-a-dos/lapdesk-de-pc-portable-2-en-1/)

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

Couleur: marron  
Dimensions du produit : 30 x 56 x 7,5 cm; 1,4 kg  
Est nécessaire l’assemblage: No  
Type de montage: Déjà assemblé  
Matériau primaire: Bois  
Matériau supérieur : Bois  
Type de finition: Bois  
Style: moderne  
Capacité Taille: unique  
Qu’y a-t-il dans la boîte?: Construit en lumière  
Forme de l’article: rectangulaire  
Instructions d’entretien: Essuyer avec un chiffon sec  
Nombre de boîtes : 1

59.0 DT~~85.0 DT~~

[__Ajouter au panier](?add-to-cart=51593)

[ liste de souhaits ](?add-to-wishlist=51593 "liste de souhaits")

[ Compare ](?add_to_compare=51593 "Compare")

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

## [LAPDESK de pc portable 2 en
1](https://tdiscount.tn/produit/informatique/accessoires-
informatique/mallette-housse-sac-a-dos/lapdesk-de-pc-portable-2-en-1/)

59.0 DT~~85.0 DT~~

  * [![Gants de pêche avec 2 lampes lumineux](https://tdiscount.tn/wp-content/uploads/2025/01/Gants-Avec-2-Lampes-Lumineux-Peche-300x300.jpg)- 13.0 DT](https://tdiscount.tn/produit/autres-categories/maison-et-bricolage/bricolage/outillage-a-main/gants-de-peche-avec-2-lampes-lumineux/)

[ __Ajouter au panier](?add-to-cart=49895)
[__](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/bricolage/outillage-a-main/gants-de-peche-avec-2-lampes-lumineux/)[
liste de souhaits ](?add-to-wishlist=49895 "liste de souhaits")

[ Compare ](?add_to_compare=49895 "Compare")

## [Gants de pêche avec 2 lampes
lumineux](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/bricolage/outillage-a-main/gants-de-peche-avec-2-lampes-lumineux/)

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

Deux LED de 5 000 mcd. – Alimenté avec Composition des cellules de la batterie
Lithium. – Nombre de piles : 2 piles CR2 Tension 3 Volts – Éclairez là où vous
en avez besoin. – Ajustement confortable avec néoprène noir de 0,5 mm.

22.0 DT~~35.0 DT~~

[__Ajouter au panier](?add-to-cart=49895)

[ liste de souhaits ](?add-to-wishlist=49895 "liste de souhaits")

[ Compare ](?add_to_compare=49895 "Compare")

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

## [Gants de pêche avec 2 lampes
lumineux](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/bricolage/outillage-a-main/gants-de-peche-avec-2-lampes-lumineux/)

22.0 DT~~35.0 DT~~

  * [![Montre Connectée KIESLECT KR Noir](https://tdiscount.tn/wp-content/uploads/2025/04/Kieslect_Watch_KR_Black-2-300x300.jpg)- 90.0 DT](https://tdiscount.tn/produit/telephonie-tablette/montre-connectee/smartwatch/montre-connectee-kieslect-kr-noir/)

[ __Ajouter au panier](?add-to-cart=70323)
[__](https://tdiscount.tn/produit/telephonie-tablette/montre-
connectee/smartwatch/montre-connectee-kieslect-kr-noir/)[ liste de souhaits
](?add-to-wishlist=70323 "liste de souhaits")

[ Compare ](?add_to_compare=70323 "Compare")

## [Montre Connectée KIESLECT KR
Noir](https://tdiscount.tn/produit/telephonie-tablette/montre-
connectee/smartwatch/montre-connectee-kieslect-kr-noir/)

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

    * Montre d’appel Bluetooth
    * Assistant vocal IA
    * 1.32″ Semi-AMOLED
    * Lecteur de musique
    * Gestion du stress
    * 70 modes d’entraînement
    * Compatible Android et IOS
    * **Garantie 1 an**

149.0 DT~~239.0 DT~~

[__Ajouter au panier](?add-to-cart=70323)

[ liste de souhaits ](?add-to-wishlist=70323 "liste de souhaits")

[ Compare ](?add_to_compare=70323 "Compare")

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

## [Montre Connectée KIESLECT KR
Noir](https://tdiscount.tn/produit/telephonie-tablette/montre-
connectee/smartwatch/montre-connectee-kieslect-kr-noir/)

149.0 DT~~239.0 DT~~

  * [![Smartphone Realme C61 6Go 128Go Vert Noir](https://tdiscount.tn/wp-content/uploads/2025/03/smartphone-realme-c61-vert-300x300.png)](https://tdiscount.tn/produit/telephonie-tablette/smartphone-tunisie/smartphone-realme-c61-8go-256go-vert-noir/)

[__Ajouter au panier](?add-to-cart=66463)
[__](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-8go-256go-vert-noir/)[ liste de souhaits ](?add-
to-wishlist=66463 "liste de souhaits")

[ Compare ](?add_to_compare=66463 "Compare")

## [Smartphone Realme C61 8Go 256Go Vert
Noir](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-8go-256go-vert-noir/)

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

Écran 6.745″ HD+, (1600 x 720 px), jusqu’à 90 Hz -Processeur : UNISOC T612, 8
cœurs, (2x A75 1.8 GHz, 6x A55 1.8 GHz)-Mémoire : 8 Go (+ 16 Go de RAM
dynamique)-Stockage : 256 Go-Caméra Arrière : 50 MP AI-Caméra Selfie : 8 MP-
Connectivité : Réseau 4G – Wi-Fi – Bluetooth 5.0 – Prise casque 3.5 mm – Prise
USB Type C-Chargeur 15 W-Batterie 5000 mAh-Système d’exploitation : Android
14-Couleur : Gold-**_Garantie 2 ans_**

559.0 DT

[__Ajouter au panier](?add-to-cart=66463)

[ liste de souhaits ](?add-to-wishlist=66463 "liste de souhaits")

[ Compare ](?add_to_compare=66463 "Compare")

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

## [Smartphone Realme C61 8Go 256Go Vert
Noir](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-8go-256go-vert-noir/)

559.0 DT

  * [![Smartphone Realme C61 6Go 128Go Gold](https://tdiscount.tn/wp-content/uploads/2025/03/smartphone-realme-c61-gold-300x300.png)](https://tdiscount.tn/produit/telephonie-tablette/smartphone-tunisie/smartphone-realme-c61-8go-256go-gold/)

[__Ajouter au panier](?add-to-cart=66462)
[__](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-8go-256go-gold/)[ liste de souhaits ](?add-to-
wishlist=66462 "liste de souhaits")

[ Compare ](?add_to_compare=66462 "Compare")

## [Smartphone Realme C61 8Go 256Go
Gold](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-8go-256go-gold/)

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

Écran 6.745″ HD+, (1600 x 720 px), jusqu’à 90 Hz Processeur : UNISOC T612, 8
cœurs, (2x A75 1.8 GHz, 6x A55 1.8 GHz) Mémoire : 8 Go (+ 16 Go de RAM
dynamique) Stockage : 256 Go Caméra Arrière : 50 MP AI Caméra Selfie : 8 MP
Connectivité : Réseau 4G – Wi-Fi – Bluetooth 5.0 – Prise casque 3.5 mm – Prise
USB Type C -Chargeur 15 W Batterie 5000 mAh Système d’exploitation : Android
14 Couleur : Gold ** _Garantie 2 ans_**

559.0 DT

[__Ajouter au panier](?add-to-cart=66462)

[ liste de souhaits ](?add-to-wishlist=66462 "liste de souhaits")

[ Compare ](?add_to_compare=66462 "Compare")

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

## [Smartphone Realme C61 8Go 256Go
Gold](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-8go-256go-gold/)

559.0 DT

  * [![Smartphone Realme C61 6Go 128Go Gold](https://tdiscount.tn/wp-content/uploads/2025/03/smartphone-realme-c61-gold-300x300.png)](https://tdiscount.tn/produit/telephonie-tablette/smartphone-tunisie/smartphone-realme-c61-6go-128go-gold/)

[__Ajouter au panier](?add-to-cart=66460)
[__](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-6go-128go-gold/)[ liste de souhaits ](?add-to-
wishlist=66460 "liste de souhaits")

[ Compare ](?add_to_compare=66460 "Compare")

## [Smartphone Realme C61 6Go 128Go
Gold](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-6go-128go-gold/)

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

Écran 6.745″ HD+, (1600 x 720 px), jusqu’à 90 Hz -Processeur : UNISOC T612, 8
cœurs, (2x A75 1.8 GHz, 6x A55 1.8 GHz)-Mémoire : 6 Go (+ 12 Go de RAM
dynamique)-Stockage : 128 Go-Caméra Arrière : 50 MP AI-Caméra Selfie : 8 MP-
Connectivité : Réseau 4G – Wi-Fi – Bluetooth 5.0 – Prise casque 3.5 mm – Prise
USB Type C-Chargeur 15 W-Batterie 5000 mAh-Système d’exploitation : Android
14-Couleur : Gold-**_Garantie 2 ans_**

459.0 DT

[__Ajouter au panier](?add-to-cart=66460)

[ liste de souhaits ](?add-to-wishlist=66460 "liste de souhaits")

[ Compare ](?add_to_compare=66460 "Compare")

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

## [Smartphone Realme C61 6Go 128Go
Gold](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-6go-128go-gold/)

459.0 DT

  * [![Smartphone Realme C61 6Go 128Go Vert Noir](https://tdiscount.tn/wp-content/uploads/2025/03/smartphone-realme-c61-vert-300x300.png)](https://tdiscount.tn/produit/telephonie-tablette/smartphone-tunisie/smartphone-realme-c61-6go-128go-vert-noir/)

[__Ajouter au panier](?add-to-cart=66461)
[__](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-6go-128go-vert-noir/)[ liste de souhaits ](?add-
to-wishlist=66461 "liste de souhaits")

[ Compare ](?add_to_compare=66461 "Compare")

## [Smartphone Realme C61 6Go 128Go Vert
Noir](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-6go-128go-vert-noir/)

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

Écran 6.745″ HD+, (1600 x 720 px), jusqu’à 90 Hz -Processeur : UNISOC T612, 8
cœurs, (2x A75 1.8 GHz, 6x A55 1.8 GHz)-Mémoire : 6 Go (+ 12 Go de RAM
dynamique)-Stockage : 128 Go-Caméra Arrière : 50 MP AI-Caméra Selfie : 8 MP-
Connectivité : Réseau 4G – Wi-Fi – Bluetooth 5.0 – Prise casque 3.5 mm – Prise
USB Type C-Chargeur 15 W-Batterie 5000 mAh-Système d’exploitation : Android
14-Couleur : Vert noir-**_Garantie 2 ans_**

459.0 DT

[__Ajouter au panier](?add-to-cart=66461)

[ liste de souhaits ](?add-to-wishlist=66461 "liste de souhaits")

[ Compare ](?add_to_compare=66461 "Compare")

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

## [Smartphone Realme C61 6Go 128Go Vert
Noir](https://tdiscount.tn/produit/telephonie-tablette/smartphone-
tunisie/smartphone-realme-c61-6go-128go-vert-noir/)

459.0 DT

  * [![Montre Connectée KIESLECT KR](https://tdiscount.tn/wp-content/uploads/2024/12/Kieslect_Watch_KR_Black-300x300.jpg)- 80.0 DT](https://tdiscount.tn/produit/telephonie-tablette/montre-connectee/montre-connectee-kieslect-kr/)

[ __Ajouter au panier](?add-to-cart=66428)
[__](https://tdiscount.tn/produit/telephonie-tablette/montre-connectee/montre-
connectee-kieslect-kr/)[ liste de souhaits ](?add-to-wishlist=66428 "liste de
souhaits")

[ Compare ](?add_to_compare=66428 "Compare")

## [Montre Connectée KIESLECT KR](https://tdiscount.tn/produit/telephonie-
tablette/montre-connectee/montre-connectee-kieslect-kr/)

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

Montre d’appel Bluetooth

Assistant vocal IA

1.32″ Semi-AMOLED

Lecteur de musique

Gestion du stress

70 modes d’entraînement

Compatible Android et IOS

Etanchéité: IP68

**Garantie 2 ans**

159.0 DT~~239.0 DT~~

[__Ajouter au panier](?add-to-cart=66428)

[ liste de souhaits ](?add-to-wishlist=66428 "liste de souhaits")

[ Compare ](?add_to_compare=66428 "Compare")

Vendu par :  [SMARTY](https://tdiscount.tn/store/smarty/)

## [Montre Connectée KIESLECT KR](https://tdiscount.tn/produit/telephonie-
tablette/montre-connectee/montre-connectee-kieslect-kr/)

159.0 DT~~239.0 DT~~

  * [![Perceuse Visseuse À Percussion Sans Fil 20V INGCO](https://tdiscount.tn/wp-content/uploads/2025/01/visseuse_20v-300x300.jpg)- 61.0 DT](https://tdiscount.tn/produit/autres-categories/maison-et-bricolage/bricolage/outillage-a-main/perceuse-visseuse-a-percussion-sans-fil-20v-ingco/)

[ __Ajouter au panier](?add-to-cart=50708)
[__](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/bricolage/outillage-a-main/perceuse-visseuse-a-percussion-sans-
fil-20v-ingco/)[ liste de souhaits ](?add-to-wishlist=50708 "liste de
souhaits")

[ Compare ](?add_to_compare=50708 "Compare")

## [Perceuse Visseuse À Percussion Sans Fil 20V
INGCO](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/bricolage/outillage-a-main/perceuse-visseuse-a-percussion-sans-
fil-20v-ingco/)

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

    * Dimensions du produit (L x l x h) : 32 x 9 x 25 cm; 380 grammes
    * Batterie(s) :2 Lithium-ion – incluse(s)
    * Matière : Plastique, Métal
    * Type d’alimentation : À Batterie
    * Tension :20 Volts
    * Couple :‎60 Newton Meters
    * Vitesse : 2000 tr/min
    * Fonctions spéciales : Lampe de travail à LED intégrée, Portable, Sans fil, Moteur sans balais
    * Composants inclus : 1x perceuse à percussion, 2x batteries 2,0 Ah, 1x chargeur rapide, 47x accessoires, 3x forets à maçonnerie, 1x boîte d’emballage en plastique
    * Type de batterie : Lithium
    * Capacité des batterie : 2000 Milliampères-heure (mAh)

289.0 DT~~350.0 DT~~

[__Ajouter au panier](?add-to-cart=50708)

[ liste de souhaits ](?add-to-wishlist=50708 "liste de souhaits")

[ Compare ](?add_to_compare=50708 "Compare")

Vendu par :  [BricoAgrico](https://tdiscount.tn/store/bricoagrico/)

## [Perceuse Visseuse À Percussion Sans Fil 20V
INGCO](https://tdiscount.tn/produit/autres-categories/maison-et-
bricolage/bricolage/outillage-a-main/perceuse-visseuse-a-percussion-sans-
fil-20v-ingco/)

289.0 DT~~350.0 DT~~

Categories

  * [uncategorized](https://tdiscount.tn/categorie-produit/uncategorized/)
  * [Autres catégories](https://tdiscount.tn/categorie-produit/autres-categories/)
  * [Best Deals](https://tdiscount.tn/categorie-produit/best-deals/)
  * [bloc note](https://tdiscount.tn/categorie-produit/bloc-note/)
  * [Bougie parfumé](https://tdiscount.tn/categorie-produit/bougie-parfume/)
  * [Boutique parapharmacie](https://tdiscount.tn/categorie-produit/boutique-parapharmacie/)
  * [Casserole](https://tdiscount.tn/categorie-produit/casserole-2/)
  * [Diffuseur de parfum](https://tdiscount.tn/categorie-produit/diffuseur-de-parfum/)
  * [Ecouteurs](https://tdiscount.tn/categorie-produit/ecouteurs/)
  * [Ecran Gamer](https://tdiscount.tn/categorie-produit/ecran-gamer-2/)
  * [Eid al Adha 2025](https://tdiscount.tn/categorie-produit/eid-al-adha-2025/)
  * [Électroménager](https://tdiscount.tn/categorie-produit/electromenager/)
  * [Enceintes](https://tdiscount.tn/categorie-produit/enceintes/)
  * [Étagère](https://tdiscount.tn/categorie-produit/etagere/)
  * [évier](https://tdiscount.tn/categorie-produit/evier/)
  * [Gaming](https://tdiscount.tn/categorie-produit/gaming/)
  * [Impression](https://tdiscount.tn/categorie-produit/impression/)
  * [Imprimante Matricielle](https://tdiscount.tn/categorie-produit/imprimante-matricielle-2/)
  * [Informatique](https://tdiscount.tn/categorie-produit/informatique/)
  * [iPad](https://tdiscount.tn/categorie-produit/ipad-2/)
  * [iPhone](https://tdiscount.tn/categorie-produit/iphone-2/)
  * [JEUX & JOUETS](https://tdiscount.tn/categorie-produit/jeux-jouets/)
  * [Logiciels](https://tdiscount.tn/categorie-produit/logiciels-2/)
  * [Mac](https://tdiscount.tn/categorie-produit/mac-2/)
  * [Meuble jardin](https://tdiscount.tn/categorie-produit/meuble-jardin-2/)
  * [montre](https://tdiscount.tn/categorie-produit/montre/)
  * [Montres](https://tdiscount.tn/categorie-produit/montres-2/)
  * [Moussem – موسم](https://tdiscount.tn/categorie-produit/moussem-%d9%85%d9%88%d8%b3%d9%85/)
  * [New Deal](https://tdiscount.tn/categorie-produit/new-deal/)
  * [Notre sélection Pc Portable](https://tdiscount.tn/categorie-produit/notre-selection-pc-portable/)
  * [Onduleur](https://tdiscount.tn/categorie-produit/onduleur-2/)
  * [Papier](https://tdiscount.tn/categorie-produit/papier-2/)
  * [Processeur](https://tdiscount.tn/categorie-produit/processeur-2/)
  * [Refroidisseur](https://tdiscount.tn/categorie-produit/refroidisseur-2/)
  * [Sant? et Beaut?](https://tdiscount.tn/categorie-produit/sant-et-beaut/)
  * [Scanner](https://tdiscount.tn/categorie-produit/scanner-2/)
  * [Service de Table](https://tdiscount.tn/categorie-produit/service-de-table-2/)
  * [Spécial Ramadan](https://tdiscount.tn/categorie-produit/special-ramadan/)
  * [Tablette Graphique](https://tdiscount.tn/categorie-produit/tablette-graphique-2/)
  * [Téléphone Fixe](https://tdiscount.tn/categorie-produit/telephone-fixe-2/)
  * [Téléphonie & Tablette](https://tdiscount.tn/categorie-produit/telephonie-tablette/)
  * [TV Image & Son](https://tdiscount.tn/categorie-produit/tv-image-son/)
  * [Ventilateur](https://tdiscount.tn/categorie-produit/ventilateur-2/)
  * [Vêtements et Accessoires](https://tdiscount.tn/categorie-produit/vetements-et-accessoires/)
  * [Webcam](https://tdiscount.tn/categorie-produit/webcam-2/)

By Brands

  * [INGCO](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&product_brand=ingco) (1)
  * [Kieslect](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&product_brand=kieslect) (2)
  * [Realme](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&product_brand=realme) (4)

By price

Prix min Prix max Filtrer

Prix :  —

Ram

  * [4 Go](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&filter_ram=4-go) (2)
  * [8 Go](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&filter_ram=8-go) (2)

Camera Arriere

  * [13 MP](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&filter_camera-arriere=13-mp) (4)

Camera Avant

  * [5 MP](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&filter_camera-avant=5-mp) (4)

Stockage

  * [128 Go](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&filter_stockage=128-go) (2)
  * [256 Go](https://tdiscount.tn/shop/?s=Lampe+de+table+LED&post_type=product&filter_stockage=256-go) (2)

__

__

## Main Menu

__

  * [__Électroménager](https://tdiscount.tn/categorie-produit/electromenager/)
  * [__Téléphonie & Tablette](https://tdiscount.tn/categorie-produit/telephonie-tablette/)
  * [__TV Image & Son](https://tdiscount.tn/categorie-produit/tv-image-son/)
  * [__Chaussures & Vêtements](https://tdiscount.tn/categorie-produit/vetements-et-accessoires/)
  * [__Hygiène & Soin](https://tdiscount.tn/categorie-produit/electromenager/hygiene-soin-maison/)
  * [__Maison et Bricolage](https://tdiscount.tn/categorie-produit/autres-categories/maison-et-bricolage/)
  * [__Informatique](https://tdiscount.tn/categorie-produit/informatique/)
  * [__Jeu vidéo & Console](https://tdiscount.tn/categorie-produit/gaming/jeu-video-console/)
  * [__Gaming](https://tdiscount.tn/categorie-produit/gaming/)
  * [__Sport et Loisir](https://tdiscount.tn/categorie-produit/autres-categories/sport-et-loisir/)
  * [__Animalerie](https://tdiscount.tn/categorie-produit/autres-categories/animalerie/)
  * [Autres catégories](https://tdiscount.tn/categorie-produit/autres-categories/)

___×_

Compare products

Close

Activer les notifications D'accord  Non Merci

