  * [ Accueil  ](https://tdiscount.tn)
/

  * [Shop](https://tdiscount.tn/shop/)
/

  * [Électroménager](https://tdiscount.tn/categorie-produit/electromenager/)

# Électroménager

**1276** Products found

Vue ____

__Filter

  * Tri par popularité
    * [Tri par popularité](https://tdiscount.tn/categorie-produit/electromenager/?orderby=popularity)
    * [Tri par notes moyennes](https://tdiscount.tn/categorie-produit/electromenager/?orderby=rating)
    * [Tri du plus récent au plus ancien](https://tdiscount.tn/categorie-produit/electromenager/?orderby=date)
    * [Tri par tarif croissant](https://tdiscount.tn/categorie-produit/electromenager/?orderby=price)
    * [Tri par tarif décroissant](https://tdiscount.tn/categorie-produit/electromenager/?orderby=price-desc)
  * Cancel

  * [![Réfrigérateur Inverter LG GN-H702HLHL 506 Litres NoFrost - Silver](https://tdiscount.tn/wp-content/uploads/2025/01/lg-refrigerateur_-gn-h702hlhl-300x300.png)![Réfrigérateur Inverter LG GN-H702HLHL 506 Litres NoFrost - Silver](https://tdiscount.tn/wp-content/uploads/2025/01/lg-refrigerateur_-gn-h702hlhl-300x300.png)- 409.0 DT](https://tdiscount.tn/produit/electromenager/gros-electromenager/lg-refrigerateur-gn-h702hlhl-506-litres-platinum-silver-no-frost-avec-wifi/)

[ __Ajouter au panier](?add-to-cart=47812)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/lg-
refrigerateur-gn-h702hlhl-506-litres-platinum-silver-no-frost-avec-wifi/)[
liste de souhaits ](?add-to-wishlist=47812 "liste de souhaits")

[ Compare ](?add_to_compare=47812 "Compare")

## [Réfrigérateur Inverter LG GN-H702HLHL 506 Litres NoFrost –
Silver](https://tdiscount.tn/produit/electromenager/gros-electromenager/lg-
refrigerateur-gn-h702hlhl-506-litres-platinum-silver-no-frost-avec-wifi/)

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

Réfrigérateur LG – 2 ports – Système de refroidissement: NoFrost – Capacité
Net total: 506 Litres – Capacité Net Réfrigérateur: 376 Litres – Capacité Net
Congélateur: 130 Litres – Capacité Brut total: 547 Litres – Capacité Brut
Réfrigérateur: 392 Litres – Capacité Brut Congélateur : 155 Litres – Classe
énergétique: A+++ – Wi-Fi – Éclairage LED – Smart ThinQ™ – Diagnostic
intelligent – HygieneFresh+™ – Compresseur linéaire Inverter – Alarme de porte
– R600a – Flux d’air multiple – 2 Clayette – Bac à légume – Zone Frais –
Casier à œufs – Panier de porte – Lampe – Dimensions: H x L x P: 180 x 78 x 73
cm – Couleur: Silver – **Garantie: 3 ans (10 ans sur moteur)**

3 790.0 DT~~4 199.0 DT~~

[__Ajouter au panier](?add-to-cart=47812)

[ liste de souhaits ](?add-to-wishlist=47812 "liste de souhaits")

[ Compare ](?add_to_compare=47812 "Compare")

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

## [Réfrigérateur Inverter LG GN-H702HLHL 506 Litres NoFrost –
Silver](https://tdiscount.tn/produit/electromenager/gros-electromenager/lg-
refrigerateur-gn-h702hlhl-506-litres-platinum-silver-no-frost-avec-wifi/)

3 790.0 DT~~4 199.0 DT~~

  * [![MACHINE A LAVER SEMI AUTOMATIQUE Tornado 12KG - Blue](https://tdiscount.tn/wp-content/uploads/2025/01/2-49-300x300.jpg)![MACHINE A LAVER SEMI AUTOMATIQUE Tornado 12KG - Blue](https://tdiscount.tn/wp-content/uploads/2025/01/2-49-300x300.jpg)](https://tdiscount.tn/produit/electromenager/gros-electromenager/tornado-machine-a-laver-semi-automatique-12kg-blue/)

[__Ajouter au panier](?add-to-cart=52720)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/tornado-
machine-a-laver-semi-automatique-12kg-blue/)[ liste de souhaits ](?add-to-
wishlist=52720 "liste de souhaits")

[ Compare ](?add_to_compare=52720 "Compare")

## [MACHINE A LAVER SEMI AUTOMATIQUE Tornado 12KG –
Blue](https://tdiscount.tn/produit/electromenager/gros-electromenager/tornado-
machine-a-laver-semi-automatique-12kg-blue/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

Machine à Laver **Semi-Automatique** TORNADO – Capacité: **12 Kg** – Nombre de
Tours: **1200 tours** – Classe énergétique:**A+** – **2 Programmes de
Lavage:** lavage standard – lavage puissant – Avec 2 moteurs – Fonctionne avec
le système Vortex dans deux directions pour le lavage – Fonctionne avec un
système d’extraction centrifuge pour le séchage – Dimensions: H x L x P: 97 x
86.5 x 50 cm – Couleur: Noir – Garantie: 1an

429.0 DT

[__Ajouter au panier](?add-to-cart=52720)

[ liste de souhaits ](?add-to-wishlist=52720 "liste de souhaits")

[ Compare ](?add_to_compare=52720 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [MACHINE A LAVER SEMI AUTOMATIQUE Tornado 12KG –
Blue](https://tdiscount.tn/produit/electromenager/gros-electromenager/tornado-
machine-a-laver-semi-automatique-12kg-blue/)

429.0 DT

  * [![Robot Pétrin Lexical LMB-1820 1300W 5 Litres - Blanc](https://tdiscount.tn/wp-content/uploads/2025/04/robot-petrin-lexical-lmb-1820-1300w-5-litres-blanc-300x300.jpg)![Robot Pétrin Lexical LMB-1820 1300W 5 Litres - Blanc](https://tdiscount.tn/wp-content/uploads/2025/04/robot-petrin-lexical-lmb-1820-1300w-5-litres-blanc-300x300.jpg)](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-petrin/robot-petrin-lexical-lmb-1820-1300w-5-litres-blanc/)

[__Ajouter au panier](?add-to-cart=70422)
[__](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-
petrin/robot-petrin-lexical-lmb-1820-1300w-5-litres-blanc/)[ liste de souhaits
](?add-to-wishlist=70422 "liste de souhaits")

[ Compare ](?add_to_compare=70422 "Compare")

## [Robot Pétrin Lexical LMB-1820 1300W 5 Litres –
Blanc](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-
petrin/robot-petrin-lexical-lmb-1820-1300w-5-litres-blanc/)

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

Robot Pétrin Lexical LMB-1820 – **Puissance** : 1300 Watts – **Capacité du
Bol** : 5 Litres – **Nombre de vitesses** : Vitesses réglable – Matériau du
bol: Acier Inoxydable – Facile à nettoyer – **Couleur** : Blanc – **Garantie**
: 1 an

260.0 DT

[__Ajouter au panier](?add-to-cart=70422)

[ liste de souhaits ](?add-to-wishlist=70422 "liste de souhaits")

[ Compare ](?add_to_compare=70422 "Compare")

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

## [Robot Pétrin Lexical LMB-1820 1300W 5 Litres –
Blanc](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-
petrin/robot-petrin-lexical-lmb-1820-1300w-5-litres-blanc/)

260.0 DT

  * [![Défroisseur A Main TEFAL Pure Pop 1300W - Vert](https://tdiscount.tn/wp-content/uploads/2025/01/1-2025-01-10T171345.094-300x300.jpg)![Défroisseur A Main TEFAL Pure Pop 1300W - Vert](https://tdiscount.tn/wp-content/uploads/2025/01/1-2025-01-10T171345.094-300x300.jpg)- 80.0 DT](https://tdiscount.tn/produit/electromenager/hygiene-soin-maison/defroisseur/tefal-defroisseur-a-vapeur-pure-pop-1300w-dt2024-vert-garantie-1-an/)

[ __Ajouter au panier](?add-to-cart=40401)
[__](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/tefal-defroisseur-a-vapeur-pure-pop-1300w-dt2024-vert-
garantie-1-an/)[ liste de souhaits ](?add-to-wishlist=40401 "liste de
souhaits")

[ Compare ](?add_to_compare=40401 "Compare")

## [Défroisseur A Main TEFAL Pure Pop 1300W –
Vert](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/tefal-defroisseur-a-vapeur-pure-pop-1300w-dt2024-vert-
garantie-1-an/)

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

179.0 DT~~259.0 DT~~

[__Ajouter au panier](?add-to-cart=40401)

[ liste de souhaits ](?add-to-wishlist=40401 "liste de souhaits")

[ Compare ](?add_to_compare=40401 "Compare")

Vendu par :  [SKME](https://tdiscount.tn/store/skme/)

## [Défroisseur A Main TEFAL Pure Pop 1300W –
Vert](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/tefal-defroisseur-a-vapeur-pure-pop-1300w-dt2024-vert-
garantie-1-an/)

179.0 DT~~259.0 DT~~

  * [![Batteur Avec Bol 2 Litre- Noir / Blanc - 250W - 7 Vitesse - CX-6620](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Batteur Avec Bol 2 Litre- Noir / Blanc - 250W - 7 Vitesse - CX-6620](https://tdiscount.tn/wp-content/uploads/2025/01/2-9-300x300.jpg)- 21.0 DT](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/batteur/batteur-avec-bol-2-litre-noir-blanc-250w-7-vitesse-cx-6620/)

[ __Ajouter au panier](?add-to-cart=30093)
[__](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/batteur/batteur-avec-bol-2-litre-noir-blanc-250w-7-vitesse-cx-6620/)[
liste de souhaits ](?add-to-wishlist=30093 "liste de souhaits")

[ Compare ](?add_to_compare=30093 "Compare")

## [Batteur Avec Bol 2 Litre- Noir / Blanc – 250W – 7 Vitesse –
CX-6620](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/batteur/batteur-avec-bol-2-litre-noir-blanc-250w-7-vitesse-cx-6620/)

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

    * Sokany
    * Mod?le : CX-6620
    * Puissance nominale : 250 W
    * Tension : 220-240 V
    * Fr?quence : 50 Hz
    * Nombre de vitesses : 7
    * Mat?riau des v?tements : acier inoxydable
    * Mat?riau du bo?tier : acier inoxydable
    * Mat?riau du corps : ABS
    * Volume total : 2 l
    * Fonction antid?rapante : Oui
    * Bouton d’?jection : Oui
    * Protection contre la surchauffe
    * Pieds antid?rapants
    * La possibilit? de p?trir la p?te
    * Poign?e ergonomique
    * Design moderne

78.0 DT~~99.0 DT~~

[__Ajouter au panier](?add-to-cart=30093)

[ liste de souhaits ](?add-to-wishlist=30093 "liste de souhaits")

[ Compare ](?add_to_compare=30093 "Compare")

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

## [Batteur Avec Bol 2 Litre- Noir / Blanc – 250W – 7 Vitesse –
CX-6620](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/batteur/batteur-avec-bol-2-litre-noir-blanc-250w-7-vitesse-cx-6620/)

78.0 DT~~99.0 DT~~

  * [![Réfrigérateur Side By Side FOCUS SMART6400 620L NoFrost](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Réfrigérateur Side By Side FOCUS SMART6400 620L NoFrost](https://tdiscount.tn/wp-content/uploads/2025/05/refrigerateur-side-by-side-focus-smart6400-620l-nofrost-noir-1-300x300.png)](https://tdiscount.tn/produit/electromenager/refrigerateurs/refrigerateur-side-by-side-focus-smart6400-620l-nofrost/)

[__Ajouter au panier](?add-to-cart=71295)
[__](https://tdiscount.tn/produit/electromenager/refrigerateurs/refrigerateur-
side-by-side-focus-smart6400-620l-nofrost/)[ liste de souhaits ](?add-to-
wishlist=71295 "liste de souhaits")

[ Compare ](?add_to_compare=71295 "Compare")

## [Réfrigérateur Side By Side FOCUS SMART6400 620L
NoFrost](https://tdiscount.tn/produit/electromenager/refrigerateurs/refrigerateur-
side-by-side-focus-smart6400-620l-nofrost/)

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

Réfrigérateur Side By Side FOCUS – 4 Portes – Système de refroidissement:
NoFrost – Capacité: 620 Litres – Classe énergétique: A+ – Classe climatique:
ST – Niveau de bruit: 41 dB – Eclairage LED – Avec distributeur – Clayettes en
verre – Bac à glaçons – Dimensions: H x L x P: 179 x 84 x 69 cm – Couleur:
Noir – **Garantie: 2 ans**

3 489.0 DT

[__Ajouter au panier](?add-to-cart=71295)

[ liste de souhaits ](?add-to-wishlist=71295 "liste de souhaits")

[ Compare ](?add_to_compare=71295 "Compare")

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

## [Réfrigérateur Side By Side FOCUS SMART6400 620L
NoFrost](https://tdiscount.tn/produit/electromenager/refrigerateurs/refrigerateur-
side-by-side-focus-smart6400-620l-nofrost/)

3 489.0 DT

  * [![Lave Linge Frontal TELEFUNKEN MACH-8KG1200TDG 8kg-Dark Gris](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Lave Linge Frontal TELEFUNKEN MACH-8KG1200TDG 8kg-Dark Gris](https://tdiscount.tn/wp-content/uploads/2025/04/lave-linge-frontal-telefunken-mach-8kg1200tdg-8kg-dark-gris-2-300x300.webp)](https://tdiscount.tn/produit/electromenager/gros-electromenager/lave-linge-frontal-telefunken-mach-8kg1200tdg-8kg-dark-gris/)

[__Ajouter au panier](?add-to-cart=70676)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/lave-
linge-frontal-telefunken-mach-8kg1200tdg-8kg-dark-gris/)[ liste de souhaits
](?add-to-wishlist=70676 "liste de souhaits")

[ Compare ](?add_to_compare=70676 "Compare")

## [Lave Linge Frontal TELEFUNKEN MACH-8KG1200TDG 8kg-Dark
Gris](https://tdiscount.tn/produit/electromenager/gros-electromenager/lave-
linge-frontal-telefunken-mach-8kg1200tdg-8kg-dark-gris/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

Machine à Laver TELEFUNKEN – Capacité de lavage : 8kg – Type d’ouverture :
Frontale – Classe énergétique : A+++ – Nombre de programmes : 15 Programmes –
Vitesse d’essorage : 1200tr/min – Rinçage + essorage – Départ Différé –
Affichage LED – Dimensions (HxLxP) : 845 x 597 x 527mm – Couleur : Gris
–**Garantie 1an**

989.0 DT

[__Ajouter au panier](?add-to-cart=70676)

[ liste de souhaits ](?add-to-wishlist=70676 "liste de souhaits")

[ Compare ](?add_to_compare=70676 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [Lave Linge Frontal TELEFUNKEN MACH-8KG1200TDG 8kg-Dark
Gris](https://tdiscount.tn/produit/electromenager/gros-electromenager/lave-
linge-frontal-telefunken-mach-8kg1200tdg-8kg-dark-gris/)

989.0 DT

  * [![Défroisseur Vapeur Vertical Professionnel Lexical LGR-1201 1800W Blanc](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Défroisseur Vapeur Vertical Professionnel Lexical LGR-1201 1800W Blanc](https://tdiscount.tn/wp-content/uploads/2025/04/defroisseur-vapeur-tefal-pro-style-it3420-1700w-300x300.jpg)](https://tdiscount.tn/produit/electromenager/hygiene-soin-maison/defroisseur/defroisseur-vapeur-vertical-professionnel-lexical-lgr-1201-1800w-blanc/)

[__Ajouter au panier](?add-to-cart=70580)
[__](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/defroisseur-vapeur-vertical-professionnel-lexical-
lgr-1201-1800w-blanc/)[ liste de souhaits ](?add-to-wishlist=70580 "liste de
souhaits")

[ Compare ](?add_to_compare=70580 "Compare")

## [Défroisseur Vapeur Vertical Professionnel Lexical LGR-1201 1800W
Blanc](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/defroisseur-vapeur-vertical-professionnel-lexical-
lgr-1201-1800w-blanc/)

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

Défroisseur Lexical LGR-1201 – Puissance: 1800 W – Capacité de réservoir d’eau
: 1200ml – Boucle de brosse – Boucle pour fixer le tuyau – Alimentation en eau
automatique – Protection contre la surchauffe – Brosse à vêtements – Matériel
: plastique – Type d’alimentation: secteur Tension: 220-230V – Semelle
extérieure: acier inoxydable – 4 niveaux de réglage de la vapeur – Temps de
préchauffage rapide 40 secondes Équipement: Générateur de vapeur – Porte-
vêtements – Tube télescopique – Brosse à vêtements – Instruction – Garantie :
1 an – Couleur : Blanc

195.0 DT

[__Ajouter au panier](?add-to-cart=70580)

[ liste de souhaits ](?add-to-wishlist=70580 "liste de souhaits")

[ Compare ](?add_to_compare=70580 "Compare")

Vendu par :  [SRL](https://tdiscount.tn/store/srl/)

## [Défroisseur Vapeur Vertical Professionnel Lexical LGR-1201 1800W
Blanc](https://tdiscount.tn/produit/electromenager/hygiene-soin-
maison/defroisseur/defroisseur-vapeur-vertical-professionnel-lexical-
lgr-1201-1800w-blanc/)

195.0 DT

  * [![Table de cuisson Encastrable Focus 60 cm Vitro Noir](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Table de cuisson Encastrable Focus 60 cm Vitro Noir](https://tdiscount.tn/wp-content/uploads/2025/04/13-300x300.jpg)](https://tdiscount.tn/produit/electromenager/gros-electromenager/plaque-de-cuisson/table-de-cuisson-encastrable-focus-60-cm-vitro-noir/)

[__Ajouter au panier](?add-to-cart=70210)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/plaque-
de-cuisson/table-de-cuisson-encastrable-focus-60-cm-vitro-noir/)[ liste de
souhaits ](?add-to-wishlist=70210 "liste de souhaits")

[ Compare ](?add_to_compare=70210 "Compare")

## [Table de cuisson Encastrable Focus 60 cm Vitro
Noir](https://tdiscount.tn/produit/electromenager/gros-electromenager/plaque-
de-cuisson/table-de-cuisson-encastrable-focus-60-cm-vitro-noir/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

Table de cuisson Encastrable Focus VITRO – Largeur : 60 cm – Nombre de
Brûleurs : 4 Brûleurs à gaz – Allumage automatique – Flamme stabilisé –
Grilles et chapeaux de brûleurs émaillés – Commandes frontales – Dimensions
520 x 590 x 51mm – Couleur : Noir

**Garantie : 2 ans**

429.0 DT

[__Ajouter au panier](?add-to-cart=70210)

[ liste de souhaits ](?add-to-wishlist=70210 "liste de souhaits")

[ Compare ](?add_to_compare=70210 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [Table de cuisson Encastrable Focus 60 cm Vitro
Noir](https://tdiscount.tn/produit/electromenager/gros-electromenager/plaque-
de-cuisson/table-de-cuisson-encastrable-focus-60-cm-vitro-noir/)

429.0 DT

  * [![Réfrigérateur TELEFUNKEN FRIG-283S 237 Litres LessFrost - Silver](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Réfrigérateur TELEFUNKEN FRIG-283S 237 Litres LessFrost - Silver](https://tdiscount.tn/wp-content/uploads/2025/04/r_frig_rateur-telefunken-frig-283s-237-litres-lessfrost-silver-300x300.jpg)](https://tdiscount.tn/produit/electromenager/refrigerateurs/__trashed-78/)

[__Ajouter au panier](?add-to-cart=67754)
[__](https://tdiscount.tn/produit/electromenager/refrigerateurs/__trashed-78/)[
liste de souhaits ](?add-to-wishlist=67754 "liste de souhaits")

[ Compare ](?add_to_compare=67754 "Compare")

## [Réfrigérateur TELEFUNKEN FRIG-283S 237 Litres LessFrost –
Silver](https://tdiscount.tn/produit/electromenager/refrigerateurs/__trashed-78/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

Réfrigérateur TELEFUNKEN – 2 Portes – Système de Refroidissement: Less Frost –
Volume net: 237 litres – Volume Net du réfrigérateur: 198 litres – Volume Net
du congélateur: 41 litres – Éclairage de l’ampoule du réfrigérateur LED –
Portes réversibles – Pieds de nivellement – Verre trempé réglable – Bac à
glaçons – Porte-oeufs – Étagères – Accessoires transparents – Dimensions: H x
L x P: 160 x 54 x 57 cm – Couleur: Silver –**Garantie: 3 ans**

859.0 DT

[__Ajouter au panier](?add-to-cart=67754)

[ liste de souhaits ](?add-to-wishlist=67754 "liste de souhaits")

[ Compare ](?add_to_compare=67754 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [Réfrigérateur TELEFUNKEN FRIG-283S 237 Litres LessFrost –
Silver](https://tdiscount.tn/produit/electromenager/refrigerateurs/__trashed-78/)

859.0 DT

  * [![Lave linge Frontal CONDOR CON-G710 7Kg - Blanc](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Lave linge Frontal CONDOR CON-G710 7Kg - Blanc](https://tdiscount.tn/wp-content/uploads/2025/04/con-g710b_2-300x300.jpg)](https://tdiscount.tn/produit/electromenager/gros-electromenager/lave-linge-frontal-condor-con-g710-7kg-blanc/)

[__Ajouter au panier](?add-to-cart=67147)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/lave-
linge-frontal-condor-con-g710-7kg-blanc/)[ liste de souhaits ](?add-to-
wishlist=67147 "liste de souhaits")

[ Compare ](?add_to_compare=67147 "Compare")

## [Lave linge Frontal CONDOR CON-G710 7Kg –
Blanc](https://tdiscount.tn/produit/electromenager/gros-electromenager/lave-
linge-frontal-condor-con-g710-7kg-blanc/)

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

Lave linge Frontal CONDOR – Capacité de lavage: 7 Kg – Vitesse d’essorage:
1000 tours/min – Classe énergétique: A++ – 15 Programmes – Couleur: Blanc –
Garantie: 2 ans

**Installation Gratuite Sur Grand Tunis**

975.0 DT

[__Ajouter au panier](?add-to-cart=67147)

[ liste de souhaits ](?add-to-wishlist=67147 "liste de souhaits")

[ Compare ](?add_to_compare=67147 "Compare")

Vendu par :  [GT Store](https://tdiscount.tn/store/tdiscount/)

## [Lave linge Frontal CONDOR CON-G710 7Kg –
Blanc](https://tdiscount.tn/produit/electromenager/gros-electromenager/lave-
linge-frontal-condor-con-g710-7kg-blanc/)

975.0 DT

  * [![Déflecteur d'air de climatiseur](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Déflecteur d'air de climatiseur](https://tdiscount.tn/wp-content/uploads/2025/03/Design-sans-titre-2025-03-24T225100.518-300x300.png)- 15.0 DT](https://tdiscount.tn/produit//accessoires-climatisation/deflecteur-dair-de-climatiseur/)

[ __Ajouter au panier](?add-to-cart=66217)
[__](https://tdiscount.tn/produit//accessoires-climatisation/deflecteur-dair-
de-climatiseur/)[ liste de souhaits ](?add-to-wishlist=66217 "liste de
souhaits")

[ Compare ](?add_to_compare=66217 "Compare")

## [Déflecteur d’air de
climatiseur](https://tdiscount.tn/produit//accessoires-
climatisation/deflecteur-dair-de-climatiseur/)

Vendu par :  [Hammami Mall](https://tdiscount.tn/store/hammami-mall/)

Déflecteur d’Air pour Climatiseur – Confort et Efficacité ,Améliorez la
circulation de l’air et optimisez le refroidissement de votre pièce. Facile à
installer, compatible avec tous les climatiseurs et conçu pour une meilleure
répartition de la température, il assure un confort optimal tout en réduisant
la consommation d’énergie.

45.0 DT~~60.0 DT~~

[__Ajouter au panier](?add-to-cart=66217)

[ liste de souhaits ](?add-to-wishlist=66217 "liste de souhaits")

[ Compare ](?add_to_compare=66217 "Compare")

Vendu par :  [Hammami Mall](https://tdiscount.tn/store/hammami-mall/)

## [Déflecteur d’air de
climatiseur](https://tdiscount.tn/produit//accessoires-
climatisation/deflecteur-dair-de-climatiseur/)

45.0 DT~~60.0 DT~~

  * [![MICRO ONDE 25L FOCUS FM.250 - NOIR](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![MICRO ONDE 25L FOCUS FM.250 - NOIR](https://tdiscount.tn/wp-content/uploads/2025/03/micro-onde-focus-fm250-25l-noir-300x300.jpg)- 80.0 DT](https://tdiscount.tn/produit/electromenager/gros-electromenager/micro-onde/micro-onde-25l-focus-fm-250-noir/)

[ __Ajouter au panier](?add-to-cart=63676)
[__](https://tdiscount.tn/produit/electromenager/gros-electromenager/micro-
onde/micro-onde-25l-focus-fm-250-noir/)[ liste de souhaits ](?add-to-
wishlist=63676 "liste de souhaits")

[ Compare ](?add_to_compare=63676 "Compare")

## [MICRO ONDE 25L FOCUS FM.250 –
NOIR](https://tdiscount.tn/produit/electromenager/gros-electromenager/micro-
onde/micro-onde-25l-focus-fm-250-noir/)

Vendu par :  [AC SPACE](https://tdiscount.tn/store/ac-space/)

**Micro Onde Focus FM.250** – **Volume** : 25 Litres – **Puissance** : 5
niveaux de puissance + 2 combinaisons et une fonction Grill – Largeur de 47 cm
– Micro-ondes Grill – Porte en vitre – Fonction de dégivrage – Facile à
nettoyer – 8 menus automatiques – Ecran Blanc – Cuisson en plusieurs étapes –
Fonction prédéfinie – Sécurité enfant (Fonction de verrouillage pour prévenir
les accidents) – Minuteur de 95 minutes – Accessoires inclus : 1 Plaque de
verre 288mm + 1 Grille SUS – **Couleur** : Noir – **Garantie** : 1 an

399.0 DT~~479.0 DT~~

[__Ajouter au panier](?add-to-cart=63676)

[ liste de souhaits ](?add-to-wishlist=63676 "liste de souhaits")

[ Compare ](?add_to_compare=63676 "Compare")

Vendu par :  [AC SPACE](https://tdiscount.tn/store/ac-space/)

## [MICRO ONDE 25L FOCUS FM.250 –
NOIR](https://tdiscount.tn/produit/electromenager/gros-electromenager/micro-
onde/micro-onde-25l-focus-fm-250-noir/)

399.0 DT~~479.0 DT~~

  * [![Air fryer - friteuse sans huile FLORIA 6L](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Air fryer - friteuse sans huile FLORIA 6L](https://tdiscount.tn/wp-content/uploads/2025/02/friteuse-6l-air-fryer-digital-floria-300x300.jpg)- 15.0 DT](https://tdiscount.tn/produit/electromenager/appareil-de-cuisson/friteuse/air-fryer-friteuse-sans-huile-6l-noir/)

[ __Ajouter au panier](?add-to-cart=60693)
[__](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/air-fryer-friteuse-sans-huile-6l-noir/)[ liste de souhaits
](?add-to-wishlist=60693 "liste de souhaits")

[ Compare ](?add_to_compare=60693 "Compare")

## [Air fryer – friteuse sans huile FLORIA
6L](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/air-fryer-friteuse-sans-huile-6l-noir/)

Vendu par :  [minibazar](https://tdiscount.tn/store/minibazar/)

Puissance : 1360 Watts Capacité : 6 Litres , Fonction d’échauffement , Le
panier intérieur avec revêtement antiadhésif peut être lavé au lave-vaisselle
Programmes entièrement automatiques pour cuire des frites, des poulets, des
steaks, des crevettes, de la viande, du poisson et des gâteaux en utilisant
une température et une durée optimales Boîtier et poignée froids au toucher
220 V 50 Hz Couleur : Noir Garantie : 1 an

245.0 DT~~260.0 DT~~

[__Ajouter au panier](?add-to-cart=60693)

[ liste de souhaits ](?add-to-wishlist=60693 "liste de souhaits")

[ Compare ](?add_to_compare=60693 "Compare")

Vendu par :  [minibazar](https://tdiscount.tn/store/minibazar/)

## [Air fryer – friteuse sans huile FLORIA
6L](https://tdiscount.tn/produit/electromenager/appareil-de-
cuisson/friteuse/air-fryer-friteuse-sans-huile-6l-noir/)

245.0 DT~~260.0 DT~~

  * [![Robot pétrin MX-4837- 1000 W- 4L- 6 Vitesses - Acier inoxydable](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Robot pétrin MX-4837- 1000 W- 4L- 6 Vitesses - Acier inoxydable](https://tdiscount.tn/wp-content/uploads/2025/02/1-423-300x300.jpg)- 60.0 DT](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-petrin/robot-petrin-mx-4837-1000-w-4l-6-vitesses-acier-inoxydable-garantie-2-ans/)

[ __Ajouter au panier](?add-to-cart=59103)
[__](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/robot-
petrin/robot-petrin-mx-4837-1000-w-4l-6-vitesses-acier-inoxydable-
garantie-2-ans/)[ liste de souhaits ](?add-to-wishlist=59103 "liste de
souhaits")

[ Compare ](?add_to_compare=59103 "Compare")

## [Robot pétrin MX-4837- 1000 W- 4L- 6 Vitesses – Acier
inoxydable](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/robot-petrin/robot-petrin-mx-4837-1000-w-4l-6-vitesses-acier-
inoxydable-garantie-2-ans/)

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

Robot patissier Tristar MX-4837 – Puissance 1000W – Capacité 4L – Bol en Acier
inoxydable – 6x Vitesses avec Fonction pulse – Fonctions: Batteur, Mixeur et
Petrin – Mouvement planétaire – Fermeture avec système de sécurité – Témoin
lumineux de fonctionnement – Dimensions 35.7 x 21.9 x 29 cm – Garantie 1 an

429.0 DT~~489.0 DT~~

[__Ajouter au panier](?add-to-cart=59103)

[ liste de souhaits ](?add-to-wishlist=59103 "liste de souhaits")

[ Compare ](?add_to_compare=59103 "Compare")

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

## [Robot pétrin MX-4837- 1000 W- 4L- 6 Vitesses – Acier
inoxydable](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/robot-petrin/robot-petrin-mx-4837-1000-w-4l-6-vitesses-acier-
inoxydable-garantie-2-ans/)

429.0 DT~~489.0 DT~~

  * [![Mini Hachoir Techwood -THA-150](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Mini Hachoir Techwood -THA-150](https://tdiscount.tn/wp-content/uploads/2025/02/1-15-300x300.jpg)- 6.0 DT](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/hachoir/mini-hachoir-techwood-tha-150/)

[ __Ajouter au panier](?add-to-cart=58238)
[__](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/mini-hachoir-techwood-tha-150/)[ liste de souhaits ](?add-to-
wishlist=58238 "liste de souhaits")

[ Compare ](?add_to_compare=58238 "Compare")

## [Mini Hachoir Techwood
-THA-150](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/mini-hachoir-techwood-tha-150/)

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

Mini Hachoir Techwood THA-150 – Puissance: 150W – Alimentation: 220-240V~
50/60Hz – Bol capacité: 375 mL – Bouton poussoir – Lâmes en inox – Couvercle
de sécurité – Couleur Blanc – Garantie 1 an

73.0 DT~~79.0 DT~~

[__Ajouter au panier](?add-to-cart=58238)

[ liste de souhaits ](?add-to-wishlist=58238 "liste de souhaits")

[ Compare ](?add_to_compare=58238 "Compare")

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

## [Mini Hachoir Techwood
-THA-150](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/mini-hachoir-techwood-tha-150/)

73.0 DT~~79.0 DT~~

  * [![Mixeur plongeant TECHWOOD TMP-660 Blanc](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Mixeur plongeant TECHWOOD TMP-660 Blanc](https://tdiscount.tn/wp-content/uploads/2025/02/1-14-300x300.jpg)- 12.3 DT](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/mixeur-plongeant/mixeur-plongeant-techwood-tmp-660-blanc/)

[ __Ajouter au panier](?add-to-cart=58233)
[__](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/mixeur-
plongeant/mixeur-plongeant-techwood-tmp-660-blanc/)[ liste de souhaits ](?add-
to-wishlist=58233 "liste de souhaits")

[ Compare ](?add_to_compare=58233 "Compare")

## [Mixeur plongeant TECHWOOD TMP-660
Blanc](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/mixeur-
plongeant/mixeur-plongeant-techwood-tmp-660-blanc/)

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

TMP-660 Mixeur plongeant blanc , puissance de 600 Watts – 2 Vitesses – Pied et
Lame en Acier Inoxydable Pied démontable pour un nettoyage aisé et un
rangement facile

86.7 DT~~99.0 DT~~

[__Ajouter au panier](?add-to-cart=58233)

[ liste de souhaits ](?add-to-wishlist=58233 "liste de souhaits")

[ Compare ](?add_to_compare=58233 "Compare")

Vendu par :  [OLMART](https://tdiscount.tn/store/almart/)

## [Mixeur plongeant TECHWOOD TMP-660
Blanc](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/mixeur-
plongeant/mixeur-plongeant-techwood-tmp-660-blanc/)

86.7 DT~~99.0 DT~~

  * [![Broyeur - Multifonction - Chopper Rapide - 800 ml](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Broyeur - Multifonction - Chopper Rapide - 800 ml](https://tdiscount.tn/wp-content/uploads/2025/02/6777fb3712b9c-1735916343-thumbnail-medium-300x300.jpg)- 9.0 DT](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/hachoir/broyeur-multifonction-chopper-rapide-800-ml/)

[ __Ajouter au panier](?add-to-cart=56657)
[__](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/broyeur-multifonction-chopper-rapide-800-ml/)[ liste de
souhaits ](?add-to-wishlist=56657 "liste de souhaits")

[ Compare ](?add_to_compare=56657 "Compare")

## [Broyeur – Multifonction – Chopper Rapide – 800
ml](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/broyeur-multifonction-chopper-rapide-800-ml/)

Vendu par :  [Cuisinti](https://tdiscount.tn/store/cuisinti/)

Ce mélangeur compact et puissant est capable de mélanger, de mixer et de
réduire en purée en toute simplicité, ce qui en fait un outil essentiel pour
tout cuisinier à domicile.

Avec une capacité de 800 ml, il est parfait pour créer des smoothies, des
sauces et des soupes pour toute la famille. Le fonctionnement pratique du
cordon de traction le rend facile à utiliser et les lames en acier inoxydable
assurent un mélange complet et efficace à chaque fois. Que vous prépariez un
smoothie rapide pour le petit-déjeuner ou que vous créiez une délicieuse soupe
maison pour le dîner, le Mini mélangeur à tirette-800 ml est le compagnon de
cuisine idéal.

18.0 DT~~27.0 DT~~

[__Ajouter au panier](?add-to-cart=56657)

[ liste de souhaits ](?add-to-wishlist=56657 "liste de souhaits")

[ Compare ](?add_to_compare=56657 "Compare")

Vendu par :  [Cuisinti](https://tdiscount.tn/store/cuisinti/)

## [Broyeur – Multifonction – Chopper Rapide – 800
ml](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/broyeur-multifonction-chopper-rapide-800-ml/)

18.0 DT~~27.0 DT~~

  * [![Hachoir à légumes Multifonctionnel Manuel](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Hachoir à légumes Multifonctionnel Manuel](https://tdiscount.tn/wp-content/uploads/2025/02/472793518_963278005193074_5168721021160658924_n-300x300.jpg)- 10.0 DT](https://tdiscount.tn/produit/electromenager/robot-de-cuisine/hachoir/hachoir-a-legumes-multifonctionnel-manuel/)

[ __Ajouter au panier](?add-to-cart=56652)
[__](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/hachoir-a-legumes-multifonctionnel-manuel/)[ liste de souhaits
](?add-to-wishlist=56652 "liste de souhaits")

[ Compare ](?add_to_compare=56652 "Compare")

## [Hachoir à légumes Multifonctionnel
Manuel](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/hachoir-a-legumes-multifonctionnel-manuel/)

Vendu par :  [Cuisinti](https://tdiscount.tn/store/cuisinti/)

Hachoir à légumes multifonctionnel manuel, presse à main, coupe-aliments,
hachoir à viande, broyeur 1.5L

19.0 DT~~29.0 DT~~

[__Ajouter au panier](?add-to-cart=56652)

[ liste de souhaits ](?add-to-wishlist=56652 "liste de souhaits")

[ Compare ](?add_to_compare=56652 "Compare")

Vendu par :  [Cuisinti](https://tdiscount.tn/store/cuisinti/)

## [Hachoir à légumes Multifonctionnel
Manuel](https://tdiscount.tn/produit/electromenager/robot-de-
cuisine/hachoir/hachoir-a-legumes-multifonctionnel-manuel/)

19.0 DT~~29.0 DT~~

  * [![Appareil à Sandwich 3En1 Panini-Gaufrier-Zouza RAF R.549 Noir](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20300%20300'%3E%3C/svg%3E)![Appareil à Sandwich 3En1 Panini-Gaufrier-Zouza RAF R.549 Noir](https://tdiscount.tn/wp-content/uploads/2025/02/appareil-a-sandwich-3en1-r549-800w-noir-300x300.jpg)- 20.0 DT](https://tdiscount.tn/produit/electromenager/autre-petit-electromenager/appareil-a-gaufre-donuts-cupcake-pizza/appareil-a-sandwich-3en1-panini-gaufrier-zouza-raf-r-549-800w-noir/)

[ __Ajouter au panier](?add-to-cart=56255)
[__](https://tdiscount.tn/produit/electromenager/autre-petit-
electromenager/appareil-a-gaufre-donuts-cupcake-pizza/appareil-a-
sandwich-3en1-panini-gaufrier-zouza-raf-r-549-800w-noir/)[ liste de souhaits
](?add-to-wishlist=56255 "liste de souhaits")

[ Compare ](?add_to_compare=56255 "Compare")

## [Appareil à Sandwich 3En1 Panini-Gaufrier-Zouza RAF R.549
Noir](https://tdiscount.tn/produit/electromenager/autre-petit-
electromenager/appareil-a-gaufre-donuts-cupcake-pizza/appareil-a-
sandwich-3en1-panini-gaufrier-zouza-raf-r-549-800w-noir/)

Vendu par :  [Cuisinti](https://tdiscount.tn/store/cuisinti/)

cette appareil Multifonction 3en 1 – 800W Gaufrier, Panini, Zouza marque raf
couleur Noir&Argent pour réalisez des panini, De Gaufre Avec les plaques
interchangeables, le revêtement antiadhésif, le système de verrouillage, le
contrôle automatique de la température cette appareil 3 en 1 le témoin de
chauffe et le témoin de mise en fonction et avec la poignée **isolante** vous
pouvez vous donner confiance à cet appareil. La **sécurité** est importante.

109.0 DT~~129.0 DT~~

[__Ajouter au panier](?add-to-cart=56255)

[ liste de souhaits ](?add-to-wishlist=56255 "liste de souhaits")

[ Compare ](?add_to_compare=56255 "Compare")

Vendu par :  [Cuisinti](https://tdiscount.tn/store/cuisinti/)

## [Appareil à Sandwich 3En1 Panini-Gaufrier-Zouza RAF R.549
Noir](https://tdiscount.tn/produit/electromenager/autre-petit-
electromenager/appareil-a-gaufre-donuts-cupcake-pizza/appareil-a-
sandwich-3en1-panini-gaufrier-zouza-raf-r-549-800w-noir/)

109.0 DT~~129.0 DT~~

  * 1
  * [2](https://tdiscount.tn/categorie-produit/electromenager/page/2/)
  * [3](https://tdiscount.tn/categorie-produit/electromenager/page/3/)
  * [4](https://tdiscount.tn/categorie-produit/electromenager/page/4/)
  * …
  * [62](https://tdiscount.tn/categorie-produit/electromenager/page/62/)
  * [63](https://tdiscount.tn/categorie-produit/electromenager/page/63/)
  * [64](https://tdiscount.tn/categorie-produit/electromenager/page/64/)
  * [Page suivante __](https://tdiscount.tn/categorie-produit/electromenager/page/2/)

Categories

  * [All Categories](https://tdiscount.tn/shop/)
  * [Électroménager](https://tdiscount.tn/categorie-produit/electromenager/)
  * [Appareil de cuisson](https://tdiscount.tn/categorie-produit/electromenager/appareil-de-cuisson/)
  * [Autre petit électroménager](https://tdiscount.tn/categorie-produit/electromenager/autre-petit-electromenager/)
  * [Climatiseur](https://tdiscount.tn/categorie-produit/electromenager/climatiseur/)
  * [Gros électroménager](https://tdiscount.tn/categorie-produit/electromenager/gros-electromenager/)
  * [Hygiène & soin maison](https://tdiscount.tn/categorie-produit/electromenager/hygiene-soin-maison/)
  * [Lave vaisselle](https://tdiscount.tn/categorie-produit/electromenager/lave-vaisselle/)
  * [Machine à café](https://tdiscount.tn/categorie-produit/electromenager/machine-a-cafe/)
  * [Machine à laver](https://tdiscount.tn/categorie-produit/electromenager/machine-a-laver/)
  * [Réfrigérateur](https://tdiscount.tn/categorie-produit/electromenager/refrigerateurs/)
  * [Robot de cuisine](https://tdiscount.tn/categorie-produit/electromenager/robot-de-cuisine/)

By Brands

  * [Acer](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=acer) (1)
  * [Ariston](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=ariston) (41)
  * [Arnica](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=arnica) (5)
  * [ARTISAN](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=artisan) (1)
  * [Arzum](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=arzum) (17)
  * [Beko](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=beko) (1)
  * [BEPER](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=beper) (2)
  * [Biolux](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=biolux) (2)
  * [BLACK&DECKER](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=blackdecker) (1)
  * [BOMANN](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=bomann) (2)
  * [Bosch](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=bosch) (1)
  * [BRANDT](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=brandt) (10)
  * [Braun](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=braun) (50)
  * [CAFÈ ROVI](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=cafe-rovi) (1)
  * [Candy](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=candy) (6)
  * [CLATRONIC](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=clatronic) (3)
  * [COALA](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=coala) (13)
  * [Condor](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=condor) (25)
  * [Crest](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=crest) (1)
  * [DESSINI](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=dessini) (1)
  * [dracoss](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=dracoss) (4)
  * [Dysis](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=dysis) (2)
  * [FAKIR](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=fakir) (9)
  * [Fiorillo](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=fiorillo) (2)
  * [Florence](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=florence) (7)
  * [FLORIA](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=floria) (2)
  * [FOCUS](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=focus) (148)
  * [GALANZ](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=galanz) (18)
  * [Gree](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=gree) (14)
  * [Hausberg](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=hausberg) (2)
  * [Hisense](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=hisense) (4)
  * [Hoover](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=hoover) (5)
  * [Joker](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=joker) (25)
  * [Joyroom](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=joyroom) (11)
  * [KÄRCHER](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=karcher) (11)
  * [KENWOOD](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=kenwood) (25)
  * [KIWI](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=kiwi) (50)
  * [KORKMAZ](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=korkmaz) (10)
  * [Kumtel](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=kumtel) (1)
  * [LEXICAL](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=lexical) (33)
  * [LG](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=lg) (55)
  * [LIVOO](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=livoo) (3)
  * [Luxell](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=luxell) (4)
  * [MAGEFESA](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=magefesa) (3)
  * [Magimix](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=magimix) (1)
  * [Midea](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=midea) (5)
  * [MOULINEX](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=moulinex) (2)
  * [Orient](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=orient) (1)
  * [Panthère Rose](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=panthere-rose) (45)
  * [Perfect bio](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=perfect-bio) (9)
  * [Perilla](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=perilla) (1)
  * [Philips](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=philips) (3)
  * [Premium](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=premium) (17)
  * [PRINCESS](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=princess) (41)
  * [RAF](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=raf) (2)
  * [RUSSELL HOBBS](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=russell-hobbs) (9)
  * [Saba](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=saba) (10)
  * [Samsung](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=samsung) (29)
  * [SEG](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=seg) (13)
  * [SEVERIN](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=severin) (14)
  * [Silver Crest](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=silver-crest) (1)
  * [Silverline](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=silverline) (3)
  * [SINBO](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=sinbo) (12)
  * [SOFPINCE](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=sofpince) (1)
  * [Sokany](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=sokany) (4)
  * [Somagic](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=somagic) (7)
  * [TCL](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tcl) (3)
  * [Techwood](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=techwood) (58)
  * [TEFAL](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tefal) (27)
  * [Telefunken](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=telefunken) (32)
  * [Topmatic](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=topmatic) (17)
  * [Tornado](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tornado) (7)
  * [TRISTAR](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tristar) (80)
  * [TVS](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=tvs) (3)
  * [ufesa](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=ufesa) (12)
  * [Westinghouse](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=westinghouse) (1)
  * [WHIRLPOOL](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=whirlpool) (3)
  * [Whirlpool ](https://tdiscount.tn/categorie-produit/electromenager/?product_brand=whirlpool-2) (2)

By price

Prix min Prix max Filtrer

Prix :  —

Volume

  * [0 - 300 Litres](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=0-300-litres) (3)
  * [301 - 400 Litres](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=301-400-litres) (4)
  * [401 – 500 Litres](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=401-500-litres) (11)
  * [501 - 600 Litres](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=501-600-litres) (2)
  * [600 et plus](https://tdiscount.tn/categorie-produit/electromenager/?filter_volume=600-et-plus) (3)

Tour par minute

  * [1000 - 1200 tr/min](https://tdiscount.tn/categorie-produit/electromenager/?filter_tours-par-minute=1000-1200-tr-min) (13)
  * [1200– 1400 tr/min](https://tdiscount.tn/categorie-produit/electromenager/?filter_tours-par-minute=1200-1400-tr-min) (11)
  * [1400 - 1600 tr/min](https://tdiscount.tn/categorie-produit/electromenager/?filter_tours-par-minute=1400-1600-tr-min) (14)
  * [600 - 800 tr/min](https://tdiscount.tn/categorie-produit/electromenager/?filter_tours-par-minute=600-800-tr-min) (4)

Type de porte

  * [Combiné](https://tdiscount.tn/categorie-produit/electromenager/?filter_type-de-porte=combine) (5)
  * [Double Portes](https://tdiscount.tn/categorie-produit/electromenager/?filter_type-de-porte=double-portes) (10)
  * [Side By Side](https://tdiscount.tn/categorie-produit/electromenager/?filter_type-de-porte=side-by-side) (5)
  * [Une Porte](https://tdiscount.tn/categorie-produit/electromenager/?filter_type-de-porte=une-porte) (2)

Capacite de lavage

  * [13 - 18+ kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=13-18-kg) (2)
  * [6 - 8 kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=6-8-kg) (17)
  * [6 kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=6) (1)
  * [8 Kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=8) (1)
  * [9 - 12 kg](https://tdiscount.tn/categorie-produit/electromenager/?filter_capacite-de-lavage=9-12-kg) (22)

Systeme de refroidissement

  * [DeFrost](https://tdiscount.tn/categorie-produit/electromenager/?filter_systeme-de-refroidissement=defrost) (3)
  * [Less Frost](https://tdiscount.tn/categorie-produit/electromenager/?filter_systeme-de-refroidissement=less-frost) (2)
  * [NoFrost](https://tdiscount.tn/categorie-produit/electromenager/?filter_systeme-de-refroidissement=nofrost) (17)

Nombre de portes

  * [1](https://tdiscount.tn/categorie-produit/electromenager/?filter_nombre-de-portes=1) (3)
  * [2](https://tdiscount.tn/categorie-produit/electromenager/?filter_nombre-de-portes=2) (15)
  * [4](https://tdiscount.tn/categorie-produit/electromenager/?filter_nombre-de-portes=4) (2)

__

__

## Main Menu

__

  * [__Électroménager](https://tdiscount.tn/categorie-produit/electromenager/)
  * [__Téléphonie & Tablette](https://tdiscount.tn/categorie-produit/telephonie-tablette/)
  * [__TV Image & Son](https://tdiscount.tn/categorie-produit/tv-image-son/)
  * [__Chaussures & Vêtements](https://tdiscount.tn/categorie-produit/vetements-et-accessoires/)
  * [__Hygiène & Soin](https://tdiscount.tn/categorie-produit/electromenager/hygiene-soin-maison/)
  * [__Maison et Bricolage](https://tdiscount.tn/categorie-produit/autres-categories/maison-et-bricolage/)
  * [__Informatique](https://tdiscount.tn/categorie-produit/informatique/)
  * [__Jeu vidéo & Console](https://tdiscount.tn/categorie-produit/gaming/jeu-video-console/)
  * [__Gaming](https://tdiscount.tn/categorie-produit/gaming/)
  * [__Sport et Loisir](https://tdiscount.tn/categorie-produit/autres-categories/sport-et-loisir/)
  * [__Animalerie](https://tdiscount.tn/categorie-produit/autres-categories/animalerie/)
  * [Autres catégories](https://tdiscount.tn/categorie-produit/autres-categories/)

___×_

Compare products

Close

Activer les notifications D'accord  Non Merci

![](https://www.facebook.com/tr?id=3918057461794796&ev=PageView&noscript=1)

