La boutique ne fonctionnera pas correctement dans le cas où les cookies sont
désactivés.

**Javascript est désactivé dans votre navigateur.** Pour une meilleure
expérience sur notre site, assurez-vous d’activer JavaScript dans votre
navigateur.

Menu

Compte

  * [Mon compte](https://www.wamia.tn/customer/account/)
  * [Ma liste d’envies ](https://www.wamia.tn/wishlist/)
  * [Connexion](https://www.wamia.tn/customer/account/login/referer/aHR0cHM6Ly93d3cud2FtaWEudG4v/)
  * Comparer 
  * Wamia La marketplace référente de confiance 
  * [Créer un compte](https://www.wamia.tn/customer/account/create/)
  * [Trouver nos magasins](https://www.wamia.tn/mw-store-locator/)

[![Special_aid](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/487x278.png)](/aid-al-adha.html)

[![Pare_soleil](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/pare_soleil.png)](/auto-moto/accessoires-auto/pare-
soleil.html)

[](/high-tech/telephones-portables-et-accessoires/coque-housse-et-etui.html)

[](/beaute-bien-etre.html)

[](/high-tech.html)

[![Livraison gratuite](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/livraison_gratuit.png)](/livraison-gratuite.html)

[](/decoration-maison/literie-et-linge-de-maison/oreiller-et-oreiller-de-
voyage.html)

[](/high-tech/photo-et-camescopes/autre-photo-et-camescopes.html)

[](/high-tech/telephones-portables-et-accessoires/coque-housse-et-etui.html)

[](/beaute-bien-etre.html)

[](/high-tech.html)

[![Livraison gratuite](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/livraison_gratuit.png)](/livraison-gratuite.html)

[](/decoration-maison/literie-et-linge-de-maison/oreiller-et-oreiller-de-
voyage.html)

[](/high-tech/photo-et-camescopes/autre-photo-et-camescopes.html)

prev

next

[![tunisie-promo](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/promo.png)](/tunisie-promo.html)

[![nouveauté](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/nouveaute.png)](/nouveaute.html)

Achetez par catégorie

[![Panneau mural](https://www.wamia.tn/media//wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/panneau.jpg)](/decoration-maison/decoration-
maison/panneau-mural.html) [Panneau mural](/decoration-maison/decoration-
maison/panneau-mural.html)

[![Bagagerie](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/bagagerie.jpg)](/mode/bagagerie.html)
[Bagagerie](/mode/bagagerie.html)

[![Appareils de cuisson](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/appareil-cuisson.jpg)](/electromenager-
tunisie/appareil-de-cuisson.html) [Appareils de cuisson](/electromenager-
tunisie/appareil-de-cuisson.html)

[![Vaisselle](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/vaisselle.jpg)](/cuisine/vaisselle.html)
[Vaisselle](/cuisine/vaisselle.html)

[![Maquillage](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/maquillage.jpg)](/beaute-bien-etre/maquillage.html)
[Maquillage](/beaute-bien-etre/maquillage.html)

[![Téléviseur](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/tv.jpg)](/high-tech/tv-video-et-home-
cinema/televiseur.html) [Téléviseur](/high-tech/tv-video-et-home-
cinema/televiseur.html)

[![Jeux de société](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/jeux-societe.jpg)](/jeux-et-jouets/jeux-de-
societe.html) [Jeux de société](/jeux-et-jouets/jeux-de-societe.html)

[![Vêtements Femme](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/vetements-femme.jpg)](/mode/vetements-femme.html)
[Vêtements Femme](/mode/vetements-femme.html)

[![Outillage à main](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/outillage-main.jpg)](/bricolage/outillage-a-
main.html) [Outillage à main](/bricolage/outillage-a-main.html)

[![Batterie de cuisine](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/batterie-cuisine.jpg)](/cuisine/casseroles-et-
poeles/batterie-de-cuisine.html) [Batterie de cuisine](/cuisine/casseroles-et-
poeles/batterie-de-cuisine.html)

prev

next

C'est à vous!

[Sélection du jour](javascript:void\(0\))

  * [Sélection du jour](javascript:void\(0\))
  * [Maison et Cuisine](javascript:void\(0\))
  * [Électroménager](javascript:void\(0\))

[![meilleur-vente](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/meilleur_vente.jpg)](/meilleures-ventes.html)

[![Maison et
Cuisine](https://www.wamia.tn/media/wysiwyg/562c1eca88bce444052c89c948fb9f9226837ac9736b7e6c1dad24917e78162d.png)](/cuisine.html)

[![Electro](https://www.wamia.tn/media/wysiwyg/cuisine270x450pxl_1_.png)](/electromenager-
tunisie.html)

[![tout-a-moins-20-dinar](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/tout_a_moins_20_dinar.png)](/tout-a-moins-20-dinar.html)

À Découvrir

[Spécial Aïd](javascript:void\(0\))

  * [Spécial Aïd](javascript:void\(0\))
  * [Zappeurs d'insectes](javascript:void\(0\))
  * [Appareil de massage](javascript:void\(0\))

[![bons-plans](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/bon_plan.png)](/bons-plans.html)

Offre du Moment

[A profiter](javascript:void\(0\))

  * [A profiter](javascript:void\(0\))

[![à ne pas rater](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/meilleur_vente_8.gif)](/meilleures-ventes.html)

[![meilleur-offre](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/meilleur-vente-new.jpg)](/meilleures-ventes.html)

[![service_client](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/Wamia_timing_.png)](/service-client)

[![mode de paiement](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/paiement.jpg)](/livraison)

[![politique_de_retour](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/politique_de_retour.jpg)](/politique-d-echange)

**Top vente**

* * *

  

  * [Coque, housse et étui](/high-tech/telephones-portables-et-accessoires/coque-housse-et-etui.html)
  * [Plateau](/cuisine/ustensile-de-cuisine/plateau.html)
  * [Épilateur](/hygiene-et-sante/rasage-et-epilation/epilateur.html)

Plateau et Présentoir gâteau

Épilateur

Coque, housse et étui

Nos derniers articles de blog

[![Zimota](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/Zitouma.png)](https://www.wamia.tn/brand/zimota
"Zimota")

[![X6](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/X6.png)](https://www.wamia.tn/brand/x6
"X6")

[![Winox](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/wamia/winox.png)](https://www.wamia.tn/brand/winox
"Winox")

[![Wayscral
](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/w.png)](https://www.wamia.tn/brand/wayscral
"Wayscral ")

[![Wahl](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/whl.png)](https://www.wamia.tn/brand/wahl
"Wahl")

[![Tem](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/wamia/Tem.png)](https://www.wamia.tn/brand/tem
"Tem")

[![Svr](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/svr_1.jpg)](https://www.wamia.tn/brand/svr
"Svr")

[![Sumex](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/Sumex.png)](https://www.wamia.tn/brand/sumex
"Sumex")

[](https://www.wamia.tn/brand/sokany "Sokany")

[](https://www.wamia.tn/brand/sifcol "Sifcol")

[](https://www.wamia.tn/brand/sandisk "Sandisk")

[](https://www.wamia.tn/brand/romoss "Romoss")

[](https://www.wamia.tn/brand/philips "Philips")

[](https://www.wamia.tn/brand/olina "Olina")

[](https://www.wamia.tn/brand/nova "Nova")

[](https://www.wamia.tn/brand/mustela "Mustela")

[](https://www.wamia.tn/brand/msi "MSI")

[](https://www.wamia.tn/brand/moulinex "Moulinex")

[](https://www.wamia.tn/brand/luminarc "Luminarc")

[](https://www.wamia.tn/brand/lenovo "Lenovo")

[](https://www.wamia.tn/brand/lavor "Lavor")

[](https://www.wamia.tn/brand/huawei "Huawei")

[](https://www.wamia.tn/brand/hp "Hp")

[](https://www.wamia.tn/brand/hascevher "Hascevher")

[](https://www.wamia.tn/brand/goldenwings "Goldenwings")

[](https://www.wamia.tn/brand/florence "Florence")

[](https://www.wamia.tn/brand/filorga "Filorga")

[](https://www.wamia.tn/brand/fasa "Fasa")

[](https://www.wamia.tn/brand/epson "Epson")

[](https://www.wamia.tn/brand/duxxa "DUXXA")

[](https://www.wamia.tn/brand/dsp "Dsp")

[](https://www.wamia.tn/brand/diager "Diager")

[](https://www.wamia.tn/brand/delonghi "Delonghi ")

[](https://www.wamia.tn/brand/dell "Dell")

[](https://www.wamia.tn/brand/bosch "Bosch")

[](https://www.wamia.tn/brand/bormioli-rocco "Bormioli Rocco")

[](https://www.wamia.tn/brand/beko "BEKO")

[](https://www.wamia.tn/brand/babyliss "Babyliss")

[](https://www.wamia.tn/brand/arcopal "Arcopal")

[](https://www.wamia.tn/brand/adidas "Adidas")

[](https://www.wamia.tn/brand/acem "Acem")

prev

next

#

# Achetez en ligne sur WAMIA :

Avec **Wamia** profitez d'un large choix de produits aux [**meilleur
prix**](/top-ventes). Nous vous proposons un catalogue diversifié de produits
de plusieurs marques aux meilleurs tarifs. Nous sommes une entreprise engagée,
notre objectif primordial est la satisfaction des besoins et envies de nos
clients. Alors bénéficiez de nos **offres** **promotionnelles** quotidiennes
ainsi que nos offres spéciales évènements tels que : les **soldes** , le
**Black Friday** , le mois du **Ramadan** , la fête de l'**Aïd** , ou encore
les **rentrées scolaires** … Les goûts… ça ne se discute pas ! À chacun son
**shopping** , ses préférences et avec Wamia, il y en a pour tous les goûts et
pour tous les budgets. Faites vos choix et nous vous offrons la garantie d'une
**livraison fiable** , rapide et sécurisée, à domicile ou dans l’un de nos 3
points de retrait.

Avec WAMIA, profitez également d’une offre de produits du quotidien, [**high-
tech**](/informatique.html), [électroménager](/electromenager-tunisie.html),
[**décoration**](/decoration-maison.html), [jouets](/sport-et-loisirs/jeux-
jouets.html), puériculture, [sport](/sport-et-loisirs.html), [hygiène et
beauté](https://www.wamia.tn/beaute-bien-etre.html), les **bonnes affaires**
sont sur **wamia.tn**. N’hésitez pas à consulter les avis ou questions des
internautes, ou à parcourir nos guides et tutos, pour vous assurer de faire le
meilleur choix ! Découvrez tous les [Services
WAMIA](https://www.wamia.tn/vendre-sur-wamia). Pour vous repérer, consultez le
plan du site. Retrouvez l'actualité de WAMIA sur **Youtube** et sur les
réseaux sociaux en suivant nos comptes **Facebook** & **Instagram**

#### 100% Sécurisé

Paiement

#### Service Clients

7/7J

#### Retour et échange gratuits

30 Jours

#### Garantie de la qualité

Satisfait ou remboursé

![cdz-alt](https://wamia.tn/media/wysiwyg/codazon/footer/app01.png)

[![cdz-
alt](https://wamia.tn/media/wysiwyg/codazon/footer/app02.png)](https://play.google.com/store/apps/details?id=tn.wamia&hl=en
"Retrouvez l'application sur Google Play")

  * [__](https://www.wamia.tn/) Home
  * [__](https://www.wamia.tn/marketplace/account/dashboard/) TB Vendeur
  * [__](javascript:void\(0\)) Cart
  * [__](https://www.wamia.tn/customer/account/) Account

  * [ __](https://www.wamia.tn/contact/) Contact
  * [__](https://www.wamia.tn/wishlist/) Wishlist
  * [__](https://www.wamia.tn/catalog/product_compare/) Compare
  * [__](javascript:void\(0\)) Menu

‹›

Plus

You have no items in your shopping cart

__

Back to Top

 __

Top

**Commander en tant que nouveau client**

La création d’un compte possède de nombreux avantages :

  * Voir le statut de la commande et de l’expédition
  * Suivi de la commande
  * Commandez plus rapidement

[ Créer un compte ](https://www.wamia.tn/customer/account/create/)

**Commander en utilisant votre compte**

Adresse email

Mot de passe

Connexion

[ Mot de passe oublié ?
](https://www.wamia.tn/customer/account/forgotpassword/)

