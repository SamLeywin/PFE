La boutique ne fonctionnera pas correctement dans le cas où les cookies sont
désactivés.

**Javascript est désactivé dans votre navigateur.** Pour une meilleure
expérience sur notre site, assurez-vous d’activer JavaScript dans votre
navigateur.

Menu

Compte

  * [Mon compte](https://www.wamia.tn/customer/account/)
  * [Ma liste d’envies ](https://www.wamia.tn/wishlist/)
  * [Connexion](https://www.wamia.tn/customer/account/login/referer/aHR0cHM6Ly93d3cud2FtaWEudG4v/)
  * Comparer 
  * Wamia La marketplace référente de confiance 
  * [Créer un compte](https://www.wamia.tn/customer/account/create/)
  * [Trouver nos magasins](https://www.wamia.tn/mw-store-locator/)

[![Special_aid](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/487x278.png)](/aid-al-adha.html)

[![Pare_soleil](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/pare_soleil.png)](/auto-moto/accessoires-auto/pare-
soleil.html)

[](/high-tech/telephones-portables-et-accessoires/coque-housse-et-etui.html)

[](/beaute-bien-etre.html)

[](/high-tech.html)

[![Livraison gratuite](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/livraison_gratuit.png)](/livraison-gratuite.html)

[](/decoration-maison/literie-et-linge-de-maison/oreiller-et-oreiller-de-
voyage.html)

[](/high-tech/photo-et-camescopes/autre-photo-et-camescopes.html)

[](/high-tech/telephones-portables-et-accessoires/coque-housse-et-etui.html)

[](/beaute-bien-etre.html)

[](/high-tech.html)

[![Livraison gratuite](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/livraison_gratuit.png)](/livraison-gratuite.html)

[](/decoration-maison/literie-et-linge-de-maison/oreiller-et-oreiller-de-
voyage.html)

[](/high-tech/photo-et-camescopes/autre-photo-et-camescopes.html)

prev

next

[![tunisie-promo](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/promo.png)](/tunisie-promo.html)

[![nouveauté](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/nouveaute.png)](/nouveaute.html)

Achetez par catégorie

[![Panneau mural](https://www.wamia.tn/media//wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/panneau.jpg)](/decoration-maison/decoration-
maison/panneau-mural.html) [Panneau mural](/decoration-maison/decoration-
maison/panneau-mural.html)

[![Bagagerie](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/bagagerie.jpg)](/mode/bagagerie.html)
[Bagagerie](/mode/bagagerie.html)

[![Appareils de cuisson](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/appareil-cuisson.jpg)](/electromenager-
tunisie/appareil-de-cuisson.html) [Appareils de cuisson](/electromenager-
tunisie/appareil-de-cuisson.html)

[![Vaisselle](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/vaisselle.jpg)](/cuisine/vaisselle.html)
[Vaisselle](/cuisine/vaisselle.html)

[![Maquillage](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/maquillage.jpg)](/beaute-bien-etre/maquillage.html)
[Maquillage](/beaute-bien-etre/maquillage.html)

[![Téléviseur](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/tv.jpg)](/high-tech/tv-video-et-home-
cinema/televiseur.html) [Téléviseur](/high-tech/tv-video-et-home-
cinema/televiseur.html)

[![Jeux de société](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/jeux-societe.jpg)](/jeux-et-jouets/jeux-de-
societe.html) [Jeux de société](/jeux-et-jouets/jeux-de-societe.html)

[![Vêtements Femme](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/vetements-femme.jpg)](/mode/vetements-femme.html)
[Vêtements Femme](/mode/vetements-femme.html)

[![Outillage à main](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/outillage-main.jpg)](/bricolage/outillage-a-
main.html) [Outillage à main](/bricolage/outillage-a-main.html)

[![Batterie de cuisine](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/batterie-cuisine.jpg)](/cuisine/casseroles-et-
poeles/batterie-de-cuisine.html) [Batterie de cuisine](/cuisine/casseroles-et-
poeles/batterie-de-cuisine.html)

prev

next

C'est à vous!

[Sélection du jour](javascript:void\(0\))

  * [Sélection du jour](javascript:void\(0\))
  * [Maison et Cuisine](javascript:void\(0\))
  * [Électroménager](javascript:void\(0\))

[![meilleur-vente](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/meilleur_vente.jpg)](/meilleures-ventes.html)

[![Maison et
Cuisine](https://www.wamia.tn/media/wysiwyg/562c1eca88bce444052c89c948fb9f9226837ac9736b7e6c1dad24917e78162d.png)](/cuisine.html)

[![Electro](https://www.wamia.tn/media/wysiwyg/cuisine270x450pxl_1_.png)](/electromenager-
tunisie.html)

[![tout-a-moins-20-dinar](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/tout_a_moins_20_dinar.png)](/tout-a-moins-20-dinar.html)

À Découvrir

[Spécial Aïd](javascript:void\(0\))

  * [Spécial Aïd](javascript:void\(0\))
  * [Zappeurs d'insectes](javascript:void\(0\))
  * [Appareil de massage](javascript:void\(0\))

[![bons-plans](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/bon_plan.png)](/bons-plans.html)

Offre du Moment

[A profiter](javascript:void\(0\))

  * [A profiter](javascript:void\(0\))

[![à ne pas rater](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/meilleur_vente_8.gif)](/meilleures-ventes.html)

[![meilleur-offre](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/meilleur-vente-new.jpg)](/meilleures-ventes.html)

[![service_client](https://www.wamia.tn/media/wysiwyg/wamia-page-d-
accueille/Avril_2025/Wamia_timing_.png)](/service-client)

[![mode de paiement](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/paiement.jpg)](/livraison)

[![politique_de_retour](https://wamia.tn/media/wysiwyg/wamia-page-d-
accueille/janvier-2024/fr/politique_de_retour.jpg)](/politique-d-echange)

**Top vente**

* * *

  

  * [Coque, housse et étui](/high-tech/telephones-portables-et-accessoires/coque-housse-et-etui.html)
  * [Plateau](/cuisine/ustensile-de-cuisine/plateau.html)
  * [Épilateur](/hygiene-et-sante/rasage-et-epilation/epilateur.html)

Plateau et Présentoir gâteau

[![Présentoir à Gâteau 3 Étages Forme Carré avec Support 41 cm
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0052_1_.jpg)![Présentoir
à Gâteau 3 Étages Forme Carré avec Support 41 cm
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0052_1_.jpg)](https://www.wamia.tn/support-
presentoir-a-gateau-3-etages-forme-carre.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Présentoir à Gâteau 3 Étages Forme Carré avec Support 41
cm](https://www.wamia.tn/support-presentoir-a-gateau-3-etages-forme-carre.html
"Présentoir à Gâteau 3 Étages Forme Carré avec Support 41 cm ")**

À partir de 79,900 DT Prix normal 100,000 DT

20% off

[![Présentoir à Gâteau 2 Étages Forme Ronde 42
cm](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0084_6.jpg)![Présentoir
à Gâteau 2 Étages Forme Ronde 42
cm](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0084_6.jpg)](https://www.wamia.tn/support-
presentoir-a-gateau-2-etages-forme-rond.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Présentoir à Gâteau 2 Étages Forme Ronde 42
cm](https://www.wamia.tn/support-presentoir-a-gateau-2-etages-forme-rond.html
"Présentoir à Gâteau 2 Étages Forme Ronde 42 cm")**

À partir de 69,900 DT Prix normal 90,000 DT

22% off

[![Présentoir à Gâteau 2 Étages Forme Carré avec Support 42
cm](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0064_1_.jpg)![Présentoir
à Gâteau 2 Étages Forme Carré avec Support 42
cm](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0064_1_.jpg)](https://www.wamia.tn/support-
presentoir-a-gateau-2-etages-forme-carre.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Présentoir à Gâteau 2 Étages Forme Carré avec Support 42
cm](https://www.wamia.tn/support-presentoir-a-gateau-2-etages-forme-carre.html
"Présentoir à Gâteau 2 Étages Forme Carré avec Support 42 cm")**

À partir de 69,900 DT Prix normal 90,000 DT

22% off

[![Présentoir à Gâteau 3 Étages Forme Ronde avec Support 41 cm
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0093_8.jpg)![Présentoir
à Gâteau 3 Étages Forme Ronde avec Support 41 cm
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0093_8.jpg)](https://www.wamia.tn/support-
presentoir-a-gateau-3-etages-forme-rond.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Présentoir à Gâteau 3 Étages Forme Ronde avec Support 41
cm](https://www.wamia.tn/support-presentoir-a-gateau-3-etages-forme-rond.html
"Présentoir à Gâteau 3 Étages Forme Ronde avec Support 41 cm ")**

À partir de 79,900 DT Prix normal 100,000 DT

20% off

[![Plateaux Présentoir deux étages Rectangulaire
Transparent](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0534_2.jpg)![Plateaux
Présentoir deux étages Rectangulaire
Transparent](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a0534_2.jpg)](https://www.wamia.tn/presentoir-
plateaux-deux-etages-rectangulaire-transparent.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Plateaux Présentoir deux étages Rectangulaire
Transparent](https://www.wamia.tn/presentoir-plateaux-deux-etages-
rectangulaire-transparent.html "Plateaux Présentoir deux étages Rectangulaire
Transparent")**

Prix Spécial 42,900 DT Prix normal 60,000 DT

29% off

[![Ensemble de 3 plateaux Ovales couleur
Verte](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/v/e/vert1_8.jpg)![Ensemble
de 3 plateaux Ovales couleur
Verte](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/v/e/vert1_8.jpg)](https://www.wamia.tn/ensemble-
de-3-plateaux-ovale-vert.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Ensemble de 3 plateaux Ovales couleur Verte](https://www.wamia.tn/ensemble-
de-3-plateaux-ovale-vert.html "Ensemble de 3 plateaux Ovales couleur Verte")**

À partir de 47,900 DT Prix normal 60,000 DT

20% off

[![Ensemble de 3 plateaux Ronds Noir avec poignées
dorées](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/s/w/sweet3.jpg)![Ensemble
de 3 plateaux Ronds Noir avec poignées
dorées](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/s/w/sweet3.jpg)](https://www.wamia.tn/ensemble-
de-3-plateaux-rond-noir.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Ensemble de 3 plateaux Ronds Noir avec poignées
dorées](https://www.wamia.tn/ensemble-de-3-plateaux-rond-noir.html "Ensemble
de 3 plateaux Ronds Noir avec poignées dorées")**

À partir de 47,900 DT Prix normal 60,000 DT

20% off

[![Plateau De Décoration Doré Motif Plume 47 X 22.5
Cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Plateau
De Décoration Doré Motif Plume 47 X 22.5
Cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/plm-2go.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Plateau De Décoration Doré Motif Plume 47 X 22.5
Cm](https://www.wamia.tn/plm-2go.html "Plateau De Décoration Doré Motif Plume
47 X 22.5 Cm")**

Prix Spécial 58,900 DT Prix normal 68,000 DT

13% off

[![Ensemble de 3 plateaux Ronds Verts Avec Poignées
Dorées](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Ensemble
de 3 plateaux Ronds Verts Avec Poignées
Dorées](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/ensemble-
de-3-plateaux-rond-vert.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Ensemble de 3 plateaux Ronds Verts Avec Poignées
Dorées](https://www.wamia.tn/ensemble-de-3-plateaux-rond-vert.html "Ensemble
de 3 plateaux Ronds Verts Avec Poignées Dorées")**

À partir de 47,900 DT Prix normal 70,000 DT

32% off

[![Plateau artisanal GM 41*30
cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Plateau
artisanal GM 41*30
cm](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/plateau-
gm.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Plateau artisanal GM 41*30 cm](https://www.wamia.tn/plateau-gm.html
"Plateau artisanal GM 41*30 cm")**

Prix Spécial 40,000 DT Prix normal 44,000 DT

9% off

prev

next

Épilateur

[![Système D'épilation Et De Rasage De Luxe 2 en 1 Kemei KM
2219](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/513APSQ1GXL._AC_SL1500__1.jpg)![Système
D'épilation Et De Rasage De Luxe 2 en 1 Kemei KM
2219](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/513APSQ1GXL._AC_SL1500__1.jpg)](https://www.wamia.tn/systeme-
d-epilation-et-de-rasage-de-luxe-2-en-1-kemei-km-2219.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Système D'épilation Et De Rasage De Luxe 2 en 1 Kemei KM
2219](https://www.wamia.tn/systeme-d-epilation-et-de-rasage-de-
luxe-2-en-1-kemei-km-2219.html "Système D'épilation Et De Rasage De Luxe 2 en
1 Kemei KM 2219")**

Prix Spécial 59,000 DT Prix normal 79,000 DT

25% off

[![Professional Double Wax Heater M-WN
608-3](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a8223_2.jpg)![Professional
Double Wax Heater M-WN
608-3](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/a/b/ab4a8223_2.jpg)](https://www.wamia.tn/professional-
double-wax-heater-m-wn-608-3.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Professional Double Wax Heater M-WN
608-3](https://www.wamia.tn/professional-double-wax-heater-m-wn-608-3.html
"Professional Double Wax Heater M-WN 608-3")**

95,000 DT

[![Pack Épilation Professionnel 3 en
1](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/MM_1.jpg)![Pack
Épilation Professionnel 3 en
1](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/MM_1.jpg)](https://www.wamia.tn/pack-
epilation-professionnel-3-en-1.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Pack Épilation Professionnel 3 en 1](https://www.wamia.tn/pack-epilation-
professionnel-3-en-1.html "Pack Épilation Professionnel 3 en 1")**

Prix Spécial 45,000 DT Prix normal 90,000 DT

50% off

[![Pack Épilation Professionnel 3 en 1
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/1/_/1_-_2024-10-19t181103.736.jpg)![Pack
Épilation Professionnel 3 en 1
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/1/_/1_-_2024-10-19t181103.736.jpg)](https://www.wamia.tn/catalog/product/view/id/53167/s/pack-
epilation-professionnel-3-en-1/)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Pack Épilation Professionnel 3 en
1](https://www.wamia.tn/catalog/product/view/id/53167/s/pack-epilation-
professionnel-3-en-1/ "Pack Épilation Professionnel 3 en 1 ")**

Prix Spécial 45,000 DT Prix normal 70,000 DT

36% off

[![Kit Epilation: 1 Appareil Cire & 2 Cartouches & 100 Bandes
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/88_1_1.jpg)![Kit
Epilation: 1 Appareil Cire & 2 Cartouches & 100 Bandes
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/88_1_1.jpg)](https://www.wamia.tn/kit-
epilation-1-appareil-cire-2-cartouches-100-bandes-31-900-dt.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Kit Epilation: 1 Appareil Cire& 2 Cartouches & 100
Bandes](https://www.wamia.tn/kit-epilation-1-appareil-
cire-2-cartouches-100-bandes-31-900-dt.html "Kit Epilation: 1 Appareil Cire &
2 Cartouches & 100 Bandes ")**

Prix Spécial 39,900 DT Prix normal 65,000 DT

39% off

[![Kit Épilation 1 Appareil Cire & 2 Cartouches Miel & 2 Paquets De
Bandes](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Kit
Épilation 1 Appareil Cire & 2 Cartouches Miel & 2 Paquets De
Bandes](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/kit-
epilation-1-appareil-cire-2-cartouches-miel-2-paquets-de-bande.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Kit Épilation 1 Appareil Cire& 2 Cartouches Miel & 2 Paquets De
Bandes](https://www.wamia.tn/kit-epilation-1-appareil-cire-2-cartouches-
miel-2-paquets-de-bande.html "Kit Épilation 1 Appareil Cire & 2 Cartouches
Miel & 2 Paquets De Bandes")**

Prix Spécial 45,000 DT Prix normal 70,000 DT

36% off

[![Kit Épilation 1 Appareil Cire & 2 Cartouches Miel & 2 Paquets De
Bandes](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Kit
Épilation 1 Appareil Cire & 2 Cartouches Miel & 2 Paquets De
Bandes](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/catalog/product/view/id/60975/s/kit-
epilation-1-appareil-cire-2-cartouches-miel-2-paquets-de-bandes/)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Kit Épilation 1 Appareil Cire& 2 Cartouches Miel & 2 Paquets De
Bandes](https://www.wamia.tn/catalog/product/view/id/60975/s/kit-
epilation-1-appareil-cire-2-cartouches-miel-2-paquets-de-bandes/ "Kit
Épilation 1 Appareil Cire & 2 Cartouches Miel & 2 Paquets De Bandes")**

Prix Spécial 50,000 DT Prix normal 60,000 DT

17% off

[![Kit Épilation 1 Appareil Cire & 2 Cartouches Miel & 100
Bandes](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Kit
Épilation 1 Appareil Cire & 2 Cartouches Miel & 100
Bandes](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/kit-
epilation-1-appareil-cire-2-cartouches-miel-100-bandes.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Kit Épilation 1 Appareil Cire& 2 Cartouches Miel & 100
Bandes](https://www.wamia.tn/kit-epilation-1-appareil-cire-2-cartouches-
miel-100-bandes.html "Kit Épilation 1 Appareil Cire & 2 Cartouches Miel & 100
Bandes")**

50,000 DT

[![HTC Rasoir Électrique
Rechargeable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![HTC
Rasoir Électrique
Rechargeable](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/htc-
tondeuse-electrique-rechargeable-pour-femme-pour-corp-et-zone-intime.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[HTC Rasoir Électrique Rechargeable](https://www.wamia.tn/htc-tondeuse-
electrique-rechargeable-pour-femme-pour-corp-et-zone-intime.html "HTC Rasoir
Électrique Rechargeable")**

59,000 DT

[![HTC Épilateur Rasoir Électrique Pour Femmes-Rechargeable-Épilateur Pour Le
Corps-
HL-020](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![HTC
Épilateur Rasoir Électrique Pour Femmes-Rechargeable-Épilateur Pour Le Corps-
HL-020](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/catalog/product/view/id/51333/s/htc-
epilateur-rasoir-electrique-pour-femmes-rechargeable-epilateur-pour-le-corps-
hl-020/)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[HTC Épilateur Rasoir Électrique Pour Femmes-Rechargeable-Épilateur Pour Le
Corps-HL-020](https://www.wamia.tn/catalog/product/view/id/51333/s/htc-
epilateur-rasoir-electrique-pour-femmes-rechargeable-epilateur-pour-le-corps-
hl-020/ "HTC Épilateur Rasoir Électrique Pour Femmes-Rechargeable-Épilateur
Pour Le Corps-HL-020")**

Prix Spécial 38,000 DT Prix normal 70,000 DT

46% off

[![HTC Épilateur Électrique Pour Femmes Rechargeable
HL-020](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![HTC
Épilateur Électrique Pour Femmes Rechargeable
HL-020](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/htc-
epilateur-rasoir-electrique-pour-femmes-rechargeable-epilateur-pour-le-corps-
hl-020.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[HTC Épilateur Électrique Pour Femmes Rechargeable
HL-020](https://www.wamia.tn/htc-epilateur-rasoir-electrique-pour-femmes-
rechargeable-epilateur-pour-le-corps-hl-020.html "HTC Épilateur Électrique
Pour Femmes Rechargeable HL-020")**

Prix Spécial 39,000 DT Prix normal 70,000 DT

44% off

[![Épilateur Visage 4 en 1 Pour Femme Rechargeable
](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Épilateur
Visage 4 en 1 Pour Femme Rechargeable
](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/epilateur-
visage-4-en-1-pour-femme-etanche-complet-du-corps-rechargeable.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Épilateur Visage 4 en 1 Pour Femme
Rechargeable](https://www.wamia.tn/epilateur-visage-4-en-1-pour-femme-etanche-
complet-du-corps-rechargeable.html "Épilateur Visage 4 en 1 Pour Femme
Rechargeable ")**

Prix Spécial 39,500 DT Prix normal 62,000 DT

36% off

[![Épilateur Sourcils et Visage Électrique & Hydrolat de
Néroli](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Épilateur
Sourcils et Visage Électrique & Hydrolat de
Néroli](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/epilateur-
sourcils-et-visage-electrique-hydrolat-de-neroli-soin-precis-et-naturel.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Épilateur Sourcils et Visage Électrique& Hydrolat de
Néroli](https://www.wamia.tn/epilateur-sourcils-et-visage-electrique-hydrolat-
de-neroli-soin-precis-et-naturel.html "Épilateur Sourcils et Visage Électrique
& Hydrolat de Néroli")**

Prix Spécial 30,000 DT Prix normal 37,000 DT

19% off

[![Épilateur Rechargeable À Sourcils 4 En
1](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Épilateur
Rechargeable À Sourcils 4 En
1](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/tondeuse-
a-sourcils-vocoste-pour-femme-epilation-du-visage-4-en-1.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Épilateur Rechargeable À Sourcils 4 En 1](https://www.wamia.tn/tondeuse-a-
sourcils-vocoste-pour-femme-epilation-du-visage-4-en-1.html "Épilateur
Rechargeable À Sourcils 4 En 1")**

Prix Spécial 26,000 DT Prix normal 49,000 DT

47% off

[![Épilateur Rechargeable À Sourcils 4 En
1](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Épilateur
Rechargeable À Sourcils 4 En
1](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/epilateur-
rechargeable-a-sourcils-4-en-1.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Épilateur Rechargeable À Sourcils 4 En 1](https://www.wamia.tn/epilateur-
rechargeable-a-sourcils-4-en-1.html "Épilateur Rechargeable À Sourcils 4 En
1")**

Prix Spécial 27,000 DT Prix normal 35,000 DT

23% off

prev

next

Coque, housse et étui

[![Etui Portefeuille Pour Redmi Note 12
4G](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/1/_/1_16__3_7_1_1_1.jpg)![Etui
Portefeuille Pour Redmi Note 12
4G](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/1/_/1_16__3_7_1_1_1.jpg)](https://www.wamia.tn/flip-
cover-pour-redmi-note-12-4g.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Etui Portefeuille Pour Redmi Note 12 4G](https://www.wamia.tn/flip-cover-
pour-redmi-note-12-4g.html "Etui Portefeuille Pour Redmi Note 12 4G")**

À partir de 25,000 DT Prix normal 49,000 DT

49% off

[![Coque Samsung Galaxy A35 Finition Dégradée Mate
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/c/q/cq_2.jpg)![Coque
Samsung Galaxy A35 Finition Dégradée Mate
](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/c/q/cq_2.jpg)](https://www.wamia.tn/coque-
de-luxe-pour-samsung-galaxy-a35-finition-degradee-mate.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Coque Samsung Galaxy A35 Finition Dégradée
Mate](https://www.wamia.tn/coque-de-luxe-pour-samsung-galaxy-a35-finition-
degradee-mate.html "Coque Samsung Galaxy A35 Finition Dégradée Mate ")**

À partir de 18,900 DT Prix normal 35,000 DT

46% off

[![Flip Cover Pour Redmi Note 13
4G](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/i/m/img-20241207-wa0021_4.jpg)![Flip
Cover Pour Redmi Note 13
4G](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/i/m/img-20241207-wa0021_4.jpg)](https://www.wamia.tn/flip-
cover-pour-redmi-note-13-4g.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Flip Cover Pour Redmi Note 13 4G](https://www.wamia.tn/flip-cover-pour-
redmi-note-13-4g.html "Flip Cover Pour Redmi Note 13 4G")**

À partir de 27,000 DT Prix normal 49,000 DT

45% off

[![Coque de Luxe pour Samsung Galaxy S23 Ultra en Silicone Mat
Dégradé](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/1/_/1_2__70_2.jpg)![Coque
de Luxe pour Samsung Galaxy S23 Ultra en Silicone Mat
Dégradé](https://www.wamia.tn/media/catalog/product/cache/c44a7f0f9ecde59e6d816d0acd046e10/1/_/1_2__70_2.jpg)](https://www.wamia.tn/coque-
de-luxe-pour-samsung-galaxy-s23-ultra-en-silicone-mat-degrade.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Coque de Luxe pour Samsung Galaxy S23 Ultra en Silicone Mat
Dégradé](https://www.wamia.tn/coque-de-luxe-pour-samsung-galaxy-s23-ultra-en-
silicone-mat-degrade.html "Coque de Luxe pour Samsung Galaxy S23 Ultra en
Silicone Mat Dégradé")**

Plus

À partir de 20,000 DT Prix normal 35,000 DT

43% off

[![Etui Silicone pour Z Fold 4
](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Etui
Silicone pour Z Fold 4
](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/etui-
silicone-z-fold-4.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Etui Silicone pour Z Fold 4](https://www.wamia.tn/etui-silicone-z-
fold-4.html "Etui Silicone pour Z Fold 4 ")**

À partir de 29,000 DT Prix normal 49,000 DT

41% off

[![Etui Portefeuille Pour Honor X7C 4G &
5G](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Etui
Portefeuille Pour Honor X7C 4G &
5G](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/etui-
flip-cover-pour-honor-x7c.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Etui Portefeuille Pour Honor X7C 4G& 5G](https://www.wamia.tn/etui-flip-
cover-pour-honor-x7c.html "Etui Portefeuille Pour Honor X7C 4G & 5G")**

Plus

À partir de 29,000 DT Prix normal 49,000 DT

41% off

[![Etui Flip Cover Pour Realme Note
50](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Etui
Flip Cover Pour Realme Note
50](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/etui-
flip-cover-pour-realme-note-50.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Etui Flip Cover Pour Realme Note 50](https://www.wamia.tn/etui-flip-cover-
pour-realme-note-50.html "Etui Flip Cover Pour Realme Note 50")**

Plus

À partir de 29,000 DT Prix normal 49,000 DT

41% off

[![Coque de Luxe pour Infinix Note 40 pro plus Finition Dégradée Mate
](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Coque
de Luxe pour Infinix Note 40 pro plus Finition Dégradée Mate
](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/coque-
de-luxe-pour-infinix-note-40-pro-plus-finition-degradee-mate.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Coque de Luxe pour Infinix Note 40 pro plus Finition Dégradée
Mate](https://www.wamia.tn/coque-de-luxe-pour-infinix-note-40-pro-plus-
finition-degradee-mate.html "Coque de Luxe pour Infinix Note 40 pro plus
Finition Dégradée Mate ")**

À partir de 19,800 DT Prix normal 30,000 DT

34% off

[![Coque pour Redmi Note 13 4G Finition Dégradée
Mate](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Coque
pour Redmi Note 13 4G Finition Dégradée
Mate](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/coque-
pour-redmi-note-13-4g-finition-degradee-mate.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Coque pour Redmi Note 13 4G Finition Dégradée
Mate](https://www.wamia.tn/coque-pour-redmi-note-13-4g-finition-degradee-
mate.html "Coque pour Redmi Note 13 4G Finition Dégradée Mate")**

Plus

À partir de 19,800 DT Prix normal 30,000 DT

34% off

[![Coque pour Redmi Note 13 Pro Plus  Finition Dégradée
Mate](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Coque
pour Redmi Note 13 Pro Plus  Finition Dégradée
Mate](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/coque-
pour-redmi-note-13-pro-plus-finition-degradee-mate.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Coque pour Redmi Note 13 Pro Plus Finition Dégradée
Mate](https://www.wamia.tn/coque-pour-redmi-note-13-pro-plus-finition-
degradee-mate.html "Coque pour Redmi Note 13 Pro Plus Finition Dégradée
Mate")**

À partir de 19,800 DT Prix normal 30,000 DT

34% off

[![Etui Portefeuille Pour Samsung
A54](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Etui
Portefeuille Pour Samsung
A54](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/flip-
cover-pour-samsung-a54.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Etui Portefeuille Pour Samsung A54](https://www.wamia.tn/flip-cover-pour-
samsung-a54.html "Etui Portefeuille Pour Samsung A54")**

À partir de 24,900 DT Prix normal 39,900 DT

38% off

[![Coque MagSafe pour iPhone 16 Pro Max & Protecteurs
Caméra](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Coque
MagSafe pour iPhone 16 Pro Max & Protecteurs
Caméra](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/coque-
magsafe-pour-iphone-16-pro-max-avec-protecteurs-d-objectif-d-appareil-
photo.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Coque MagSafe pour iPhone 16 Pro Max& Protecteurs
Caméra](https://www.wamia.tn/coque-magsafe-pour-iphone-16-pro-max-avec-
protecteurs-d-objectif-d-appareil-photo.html "Coque MagSafe pour iPhone 16 Pro
Max & Protecteurs Caméra")**

À partir de 29,800 DT Prix normal 49,000 DT

39% off

[![Coque MagSafe pour iPhone 16 Pro Avec Protecteurs
D'objectifs](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Coque
MagSafe pour iPhone 16 Pro Avec Protecteurs
D'objectifs](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/coque-
magsafe-pour-iphone-16-pro-avec-protecteurs-d-objectif-d-appareil-photo.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Coque MagSafe pour iPhone 16 Pro Avec Protecteurs
D'objectifs](https://www.wamia.tn/coque-magsafe-pour-iphone-16-pro-avec-
protecteurs-d-objectif-d-appareil-photo.html "Coque MagSafe pour iPhone 16 Pro
Avec Protecteurs D'objectifs")**

À partir de 29,800 DT Prix normal 49,000 DT

39% off

[![Protection Camera 15 Pro Max & 15
Pro](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Protection
Camera 15 Pro Max & 15
Pro](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/protection-
camera-15-pro-max-15-pro.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Protection Camera 15 Pro Max& 15 Pro](https://www.wamia.tn/protection-
camera-15-pro-max-15-pro.html "Protection Camera 15 Pro Max & 15 Pro")**

À partir de 19,900 DT Prix normal 29,000 DT

31% off

[![Protections Caméra Samsung Galaxy S25
Ultra](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)![Protections
Caméra Samsung Galaxy S25
Ultra](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgDTD2qgAAAAASUVORK5CYII=)](https://www.wamia.tn/protections-
camera-samsung-galaxy-s25-ultra.html)

Ajouter au panier [Aperçu Rapide](javascript:void\(0\) "Aperçu Rapide")

Ajouter à ma liste d’envie

**[Protections Caméra Samsung Galaxy S25
Ultra](https://www.wamia.tn/protections-camera-samsung-galaxy-s25-ultra.html
"Protections Caméra Samsung Galaxy S25 Ultra")**

À partir de 24,900 DT Prix normal 39,000 DT

36% off

prev

next

Nos derniers articles de blog

[![Zimota](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/Zitouma.png)](https://www.wamia.tn/brand/zimota
"Zimota")

[![X6](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/X6.png)](https://www.wamia.tn/brand/x6
"X6")

[![Winox](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/wamia/winox.png)](https://www.wamia.tn/brand/winox
"Winox")

[![Wayscral
](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/w.png)](https://www.wamia.tn/brand/wayscral
"Wayscral ")

[![Wahl](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/whl.png)](https://www.wamia.tn/brand/wahl
"Wahl")

[![Tem](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/wamia/Tem.png)](https://www.wamia.tn/brand/tem
"Tem")

[![Svr](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/svr_1.jpg)](https://www.wamia.tn/brand/svr
"Svr")

[![Sumex](https://www.wamia.tn/media/codazon_cache/brand/200x150/wysiwyg/Sumex.png)](https://www.wamia.tn/brand/sumex
"Sumex")

[](https://www.wamia.tn/brand/sokany "Sokany")

[](https://www.wamia.tn/brand/sifcol "Sifcol")

[](https://www.wamia.tn/brand/sandisk "Sandisk")

[](https://www.wamia.tn/brand/romoss "Romoss")

[](https://www.wamia.tn/brand/philips "Philips")

[](https://www.wamia.tn/brand/olina "Olina")

[](https://www.wamia.tn/brand/nova "Nova")

[](https://www.wamia.tn/brand/mustela "Mustela")

[](https://www.wamia.tn/brand/msi "MSI")

[](https://www.wamia.tn/brand/moulinex "Moulinex")

[](https://www.wamia.tn/brand/luminarc "Luminarc")

[](https://www.wamia.tn/brand/lenovo "Lenovo")

[](https://www.wamia.tn/brand/lavor "Lavor")

[](https://www.wamia.tn/brand/huawei "Huawei")

[](https://www.wamia.tn/brand/hp "Hp")

[](https://www.wamia.tn/brand/hascevher "Hascevher")

[](https://www.wamia.tn/brand/goldenwings "Goldenwings")

[](https://www.wamia.tn/brand/florence "Florence")

[](https://www.wamia.tn/brand/filorga "Filorga")

[](https://www.wamia.tn/brand/fasa "Fasa")

[](https://www.wamia.tn/brand/epson "Epson")

[](https://www.wamia.tn/brand/duxxa "DUXXA")

[](https://www.wamia.tn/brand/dsp "Dsp")

[](https://www.wamia.tn/brand/diager "Diager")

[](https://www.wamia.tn/brand/delonghi "Delonghi ")

[](https://www.wamia.tn/brand/dell "Dell")

[](https://www.wamia.tn/brand/bosch "Bosch")

[](https://www.wamia.tn/brand/bormioli-rocco "Bormioli Rocco")

[](https://www.wamia.tn/brand/beko "BEKO")

[](https://www.wamia.tn/brand/babyliss "Babyliss")

[](https://www.wamia.tn/brand/arcopal "Arcopal")

[](https://www.wamia.tn/brand/adidas "Adidas")

[](https://www.wamia.tn/brand/acem "Acem")

prev

next

#

# Achetez en ligne sur WAMIA :

Avec **Wamia** profitez d'un large choix de produits aux [**meilleur
prix**](/top-ventes). Nous vous proposons un catalogue diversifié de produits
de plusieurs marques aux meilleurs tarifs. Nous sommes une entreprise engagée,
notre objectif primordial est la satisfaction des besoins et envies de nos
clients. Alors bénéficiez de nos **offres** **promotionnelles** quotidiennes
ainsi que nos offres spéciales évènements tels que : les **soldes** , le
**Black Friday** , le mois du **Ramadan** , la fête de l'**Aïd** , ou encore
les **rentrées scolaires** … Les goûts… ça ne se discute pas ! À chacun son
**shopping** , ses préférences et avec Wamia, il y en a pour tous les goûts et
pour tous les budgets. Faites vos choix et nous vous offrons la garantie d'une
**livraison fiable** , rapide et sécurisée, à domicile ou dans l’un de nos 3
points de retrait.

Avec WAMIA, profitez également d’une offre de produits du quotidien, [**high-
tech**](/informatique.html), [électroménager](/electromenager-tunisie.html),
[**décoration**](/decoration-maison.html), [jouets](/sport-et-loisirs/jeux-
jouets.html), puériculture, [sport](/sport-et-loisirs.html), [hygiène et
beauté](https://www.wamia.tn/beaute-bien-etre.html), les **bonnes affaires**
sont sur **wamia.tn**. N’hésitez pas à consulter les avis ou questions des
internautes, ou à parcourir nos guides et tutos, pour vous assurer de faire le
meilleur choix ! Découvrez tous les [Services
WAMIA](https://www.wamia.tn/vendre-sur-wamia). Pour vous repérer, consultez le
plan du site. Retrouvez l'actualité de WAMIA sur **Youtube** et sur les
réseaux sociaux en suivant nos comptes **Facebook** & **Instagram**

#### 100% Sécurisé

Paiement

#### Service Clients

7/7J

#### Retour et échange gratuits

30 Jours

#### Garantie de la qualité

Satisfait ou remboursé

![cdz-alt](https://wamia.tn/media/wysiwyg/codazon/footer/app01.png)

[![cdz-
alt](https://wamia.tn/media/wysiwyg/codazon/footer/app02.png)](https://play.google.com/store/apps/details?id=tn.wamia&hl=en
"Retrouvez l'application sur Google Play")

  * [__](https://www.wamia.tn/) Home
  * [__](https://www.wamia.tn/marketplace/account/dashboard/) TB Vendeur
  * [__](javascript:void\(0\)) Cart
  * [__](https://www.wamia.tn/customer/account/) Account

  * [ __](https://www.wamia.tn/contact/) Contact
  * [__](https://www.wamia.tn/wishlist/) Wishlist
  * [__](https://www.wamia.tn/catalog/product_compare/) Compare
  * [__](javascript:void\(0\)) Menu

‹›

Plus

You have no items in your shopping cart

__

Back to Top

 __

Top

**Commander en tant que nouveau client**

La création d’un compte possède de nombreux avantages :

  * Voir le statut de la commande et de l’expédition
  * Suivi de la commande
  * Commandez plus rapidement

[ Créer un compte ](https://www.wamia.tn/customer/account/create/)

**Commander en utilisant votre compte**

Adresse email

Mot de passe

Connexion

[ Mot de passe oublié ?
](https://www.wamia.tn/customer/account/forgotpassword/)

