
import streamlit as st
import os
import requests
import json
from typing import List, Dict, Optional, Any


def send_scrape_request(urls, fields, model_selection, use_pagination=True, 
                       pagination_details=None, max_pages=3, product_filter=None,
                       max_products=None, product_ids=None, search_query=None):
    """Send a scrape request to the API."""
    
    request_data = {
        "urls": urls,
        "fields": fields,
        "model_selection": model_selection,
        "use_pagination": use_pagination,
        "pagination_details": pagination_details,
        "max_pages": max_pages,
        "product_filter": product_filter,
        "max_products": max_products,
        "product_ids": product_ids,
        "search_query": search_query  # Ajout du paramètre de recherche
    }

def get_api_key(api_key_name):
    # Check if the API key from the sidebar is present, else fallback to the .env file
    if api_key_name == 'OPENAI_API_KEY':
        return st.session_state['openai_api_key'] or os.getenv(api_key_name)
    elif api_key_name == 'GOOGLE_API_KEY':
        return st.session_state['gemini_api_key'] or os.getenv(api_key_name)
    elif api_key_name == 'GROQ_API_KEY':
        return  os.getenv(api_key_name)
    else:
        return os.getenv(api_key_name)
        